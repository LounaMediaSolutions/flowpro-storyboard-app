import { v4 as uuidv4 } from 'uuid';

export interface ParsedScript {
  title?: string;
  scenes: ParsedScene[];
  characters: ParsedCharacter[];
  locations: ParsedLocation[];
  metadata: ScriptMetadata;
}

export interface ParsedScene {
  id: string;
  sceneNumber: number;
  heading: string;
  location: string;
  timeOfDay: 'day' | 'night' | 'dawn' | 'dusk' | 'morning' | 'afternoon' | 'evening' | 'continuous' | 'later' | 'same_time';
  isInterior: boolean;
  description: string;
  elements: ScriptElement[];
  estimatedDuration: number;
  characters: string[];
}

export interface ParsedCharacter {
  id: string;
  name: string;
  description?: string;
  appearances: number;
  firstAppearance: number; // scene number
  dialogue: string[];
}

export interface ParsedLocation {
  id: string;
  name: string;
  type: 'interior' | 'exterior';
  appearances: number;
  scenes: number[];
}

export interface ScriptElement {
  id: string;
  type: 'scene_heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition' | 'shot' | 'note' | 'general';
  content: string;
  characterName?: string;
  lineNumber: number;
}

export interface ScriptMetadata {
  totalPages: number;
  totalScenes: number;
  totalCharacters: number;
  totalLocations: number;
  estimatedDuration: number;
  dialoguePercentage: number;
  actionPercentage: number;
  pacing: 'fast' | 'normal' | 'slow';
}

export class IntelligentScriptParser {
  private static readonly SCENE_HEADING_REGEX = /^(INT\.|EXT\.|FADE IN:|FADE OUT:|CUT TO:)?\s*([A-Z\s\-\.\,\'\"\(\)]+)\s*\-\s*(DAY|NIGHT|DAWN|DUSK|MORNING|AFTERNOON|EVENING|CONTINUOUS|LATER|SAME TIME|SAME|MOMENTS LATER)/i;
  private static readonly CHARACTER_REGEX = /^[A-Z\s\.\'\-]{2,}(?:\s*\([^\)]*\))?$/;
  private static readonly PARENTHETICAL_REGEX = /^\([^\)]*\)$/;
  private static readonly TRANSITION_REGEX = /^(FADE IN:|FADE OUT:|CUT TO:|DISSOLVE TO:|MATCH CUT:|JUMP CUT:|SMASH CUT:|MONTAGE|END MONTAGE).*$/i;
  private static readonly ACTION_CAPS_REGEX = /^[A-Z][A-Z\s\.\,\!\?\-\:\;]*$/;
  
  public static parseScript(scriptText: string, format: 'fountain' | 'fdx' | 'text' = 'text'): ParsedScript {
    const lines = scriptText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    
    const scenes: ParsedScene[] = [];
    const characters: Map<string, ParsedCharacter> = new Map();
    const locations: Map<string, ParsedLocation> = new Map();
    
    let currentScene: ParsedScene | null = null;
    let sceneNumber = 0;
    let lineNumber = 0;
    
    for (const line of lines) {
      lineNumber++;
      
      // Skip empty lines and page numbers
      if (!line || /^[\d\s\.]*$/.test(line)) continue;
      
      const element = this.parseElement(line, lineNumber);
      
      if (element.type === 'scene_heading') {
        // Save previous scene
        if (currentScene) {
          this.finalizeScene(currentScene);
          scenes.push(currentScene);
        }
        
        // Start new scene
        sceneNumber++;
        currentScene = this.createNewScene(sceneNumber, line, element);
        
        // Extract and register location
        this.extractLocation(line, locations, sceneNumber);
        
      } else if (currentScene) {
        // Add element to current scene
        currentScene.elements.push(element);
        
        // Extract character information
        if (element.type === 'character' && element.characterName) {
          this.extractCharacter(element.characterName, sceneNumber, characters);
          if (!currentScene.characters.includes(element.characterName)) {
            currentScene.characters.push(element.characterName);
          }
        }
        
        // Add dialogue to character
        if (element.type === 'dialogue' && currentScene.elements.length > 1) {
          const prevElement = currentScene.elements[currentScene.elements.length - 2];
          if (prevElement.type === 'character' && prevElement.characterName) {
            const character = characters.get(prevElement.characterName);
            if (character) {
              character.dialogue.push(element.content);
            }
          }
        }
        
        // Build scene description from action elements
        if (element.type === 'action') {
          currentScene.description += element.content + ' ';
        }
      }
    }
    
    // Finalize last scene
    if (currentScene) {
      this.finalizeScene(currentScene);
      scenes.push(currentScene);
    }
    
    // Convert maps to arrays
    const characterArray = Array.from(characters.values());
    const locationArray = Array.from(locations.values());
    
    // Generate metadata
    const metadata = this.generateMetadata(scenes, characterArray, locationArray, scriptText);
    
    return {
      scenes,
      characters: characterArray,
      locations: locationArray,
      metadata
    };
  }
  
  private static parseElement(line: string, lineNumber: number): ScriptElement {
    const element: ScriptElement = {
      id: uuidv4(),
      content: line,
      type: 'general',
      lineNumber
    };
    
    // Scene heading detection
    if (this.SCENE_HEADING_REGEX.test(line)) {
      element.type = 'scene_heading';
    }
    // Transition detection
    else if (this.TRANSITION_REGEX.test(line)) {
      element.type = 'transition';
    }
    // Parenthetical detection
    else if (this.PARENTHETICAL_REGEX.test(line)) {
      element.type = 'parenthetical';
    }
    // Character name detection (must be ALL CAPS, potentially with extensions)
    else if (this.CHARACTER_REGEX.test(line) && !this.ACTION_CAPS_REGEX.test(line)) {
      element.type = 'character';
      element.characterName = line.replace(/\s*\([^\)]*\)$/, '').trim();
    }
    // Action/Description (mixed case or narrative text)
    else if (!line.match(/^[A-Z\s\.\,\!\?\-\:\;]*$/) || line.length > 50) {
      element.type = 'action';
    }
    // Dialogue (follows character name)
    else {
      element.type = 'dialogue';
    }
    
    return element;
  }
  
  private static createNewScene(sceneNumber: number, heading: string, element: ScriptElement): ParsedScene {
    const match = heading.match(this.SCENE_HEADING_REGEX);
    let location = 'Unknown Location';
    let timeOfDay: ParsedScene['timeOfDay'] = 'day';
    let isInterior = false;
    
    if (match) {
      const prefix = match[1]?.toUpperCase() || '';
      location = match[2]?.trim() || 'Unknown Location';
      const time = match[3]?.toLowerCase() || 'day';
      
      isInterior = prefix.includes('INT') || heading.toUpperCase().includes('INT.');
      
      // Map time variants
      const timeMap: Record<string, ParsedScene['timeOfDay']> = {
        'day': 'day',
        'night': 'night',
        'dawn': 'dawn',
        'dusk': 'dusk',
        'morning': 'morning',
        'afternoon': 'afternoon',
        'evening': 'evening',
        'continuous': 'continuous',
        'later': 'later',
        'same time': 'same_time',
        'same': 'same_time',
        'moments later': 'continuous'
      };
      
      timeOfDay = timeMap[time] || 'day';
    }
    
    return {
      id: uuidv4(),
      sceneNumber,
      heading,
      location,
      timeOfDay,
      isInterior,
      description: '',
      elements: [element],
      estimatedDuration: 0,
      characters: []
    };
  }
  
  private static extractLocation(heading: string, locations: Map<string, ParsedLocation>, sceneNumber: number): void {
    const match = heading.match(this.SCENE_HEADING_REGEX);
    if (match) {
      const prefix = match[1]?.toUpperCase() || '';
      const locationName = match[2]?.trim() || 'Unknown Location';
      const isInterior = prefix.includes('INT') || heading.toUpperCase().includes('INT.');
      
      if (!locations.has(locationName)) {
        locations.set(locationName, {
          id: uuidv4(),
          name: locationName,
          type: isInterior ? 'interior' : 'exterior',
          appearances: 1,
          scenes: [sceneNumber]
        });
      } else {
        const location = locations.get(locationName)!;
        location.appearances++;
        location.scenes.push(sceneNumber);
      }
    }
  }
  
  private static extractCharacter(characterName: string, sceneNumber: number, characters: Map<string, ParsedCharacter>): void {
    if (!characters.has(characterName)) {
      characters.set(characterName, {
        id: uuidv4(),
        name: characterName,
        appearances: 1,
        firstAppearance: sceneNumber,
        dialogue: []
      });
    } else {
      const character = characters.get(characterName)!;
      character.appearances++;
    }
  }
  
  private static finalizeScene(scene: ParsedScene): void {
    // Calculate estimated duration (1 page ≈ 1 minute, roughly 250 words per page)
    const wordCount = scene.elements.reduce((count, element) => {
      return count + element.content.split(' ').length;
    }, 0);
    
    scene.estimatedDuration = Math.max(1, Math.round(wordCount / 250)); // minimum 1 minute
    scene.description = scene.description.trim();
  }
  
  private static generateMetadata(scenes: ParsedScene[], characters: ParsedCharacter[], locations: ParsedLocation[], scriptText: string): ScriptMetadata {
    const totalPages = Math.ceil(scriptText.length / 2500); // Rough estimate
    const totalWords = scriptText.split(' ').length;
    const dialogueWords = scenes.reduce((count, scene) => {
      return count + scene.elements
        .filter(e => e.type === 'dialogue')
        .reduce((dCount, e) => dCount + e.content.split(' ').length, 0);
    }, 0);
    
    const actionWords = scenes.reduce((count, scene) => {
      return count + scene.elements
        .filter(e => e.type === 'action')
        .reduce((aCount, e) => aCount + e.content.split(' ').length, 0);
    }, 0);
    
    const dialoguePercentage = Math.round((dialogueWords / totalWords) * 100);
    const actionPercentage = Math.round((actionWords / totalWords) * 100);
    const estimatedDuration = scenes.reduce((total, scene) => total + scene.estimatedDuration, 0);
    
    // Determine pacing based on action/dialogue ratio
    let pacing: 'fast' | 'normal' | 'slow' = 'normal';
    if (actionPercentage > 60) pacing = 'fast';
    else if (dialoguePercentage > 70) pacing = 'slow';
    
    return {
      totalPages,
      totalScenes: scenes.length,
      totalCharacters: characters.length,
      totalLocations: locations.length,
      estimatedDuration,
      dialoguePercentage,
      actionPercentage,
      pacing
    };
  }
  
  // Fountain format specific parsing
  public static parseFountain(fountainText: string): ParsedScript {
    // Handle Fountain markup
    const processedText = fountainText
      .replace(/^===.*$/gm, '') // Remove page breaks
      .replace(/^\[\[.*\]\]$/gm, '') // Remove notes
      .replace(/^\/\*[\s\S]*?\*\/$/gm, '') // Remove boneyard
      .replace(/^\*\*(.*?)\*\*$/gm, '$1') // Remove bold
      .replace(/^\*(.*?)\*$/gm, '$1') // Remove italic
      .replace(/^_(.*?)_$/gm, '$1'); // Remove underline
    
    return this.parseScript(processedText, 'fountain');
  }
  
  // Final Draft XML parsing helper
  public static parseFDX(fdxContent: string): ParsedScript {
    // Basic FDX XML structure parsing
    // This would need more sophisticated XML parsing for full FDX support
    const textContent = fdxContent
      .replace(/<[^>]*>/g, ' ') // Remove XML tags
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
    
    return this.parseScript(textContent, 'fdx');
  }
}

// Export utility functions
export const parseScriptText = (text: string, format?: 'fountain' | 'fdx' | 'text') => {
  return IntelligentScriptParser.parseScript(text, format);
};

export const parseFountainScript = (text: string) => {
  return IntelligentScriptParser.parseFountain(text);
};

export const parseFDXScript = (text: string) => {
  return IntelligentScriptParser.parseFDX(text);
};
