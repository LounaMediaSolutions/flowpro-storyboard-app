// FlowPro API Prompt Library
// Ready-to-use prompts for different AI services

export interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  service: 'google' | 'minimax' | 'deepseek' | 'openai';
  category: 'script_analysis' | 'character_creation' | 'scene_description' | 'image_generation' | 'video_generation' | 'audio_generation' | 'reasoning' | 'content_generation' | 'production_planning' | 'market_analysis';
  prompt: string;
  variables?: string[];
  example?: string;
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  estimatedTime?: string;
  tags?: string[];
}

export const PROMPT_LIBRARY: PromptTemplate[] = [
  // =================== GOOGLE AI STUDIO PROMPTS ===================
  // Script Analysis & Planning
  {
    id: 'script_analysis_comprehensive',
    name: 'Comprehensive Script Analysis',
    description: 'Complete script breakdown with production insights and recommendations',
    service: 'google',
    category: 'script_analysis',
    prompt: `Perform comprehensive analysis of this screenplay:

SCREENPLAY:
{script_text}

ANALYSIS REQUIREMENTS:
Budget Level: {budget_level}
Target Audience: {target_audience}
Production Timeline: {timeline}

Provide detailed analysis in JSON format:

{
  "script_overview": {
    "title": "",
    "genre": "",
    "logline": "",
    "page_count": 0,
    "estimated_runtime": ""
  },
  "characters": [
    {
      "name": "",
      "role": "protagonist/antagonist/supporting",
      "screen_time": "major/minor",
      "description": "",
      "character_arc": "",
      "casting_notes": ""
    }
  ],
  "scenes": [
    {
      "number": 1,
      "location": "",
      "time": "",
      "description": "",
      "page_length": 0,
      "complexity": "simple/medium/complex",
      "special_requirements": []
    }
  ],
  "production_analysis": {
    "locations_needed": [],
    "special_effects": [],
    "equipment_requirements": [],
    "crew_size_estimate": "",
    "shooting_days_estimate": 0,
    "budget_category": "micro/low/medium/high"
  },
  "story_structure": {
    "act_one_end": 0,
    "midpoint": 0,
    "act_two_end": 0,
    "plot_points": [],
    "pacing_notes": ""
  }
}`,
    variables: ['script_text', 'budget_level', 'target_audience', 'timeline'],
    example: 'Full feature screenplay, Budget: indie, Audience: 18-34, Timeline: 6 months',
    difficulty: 'advanced',
    estimatedTime: '15-30 minutes',
    tags: ['comprehensive', 'production', 'analysis']
  },

  {
    id: 'location_analysis',
    name: 'Location & Set Analysis',
    description: 'Analyze script for location requirements and production logistics',
    service: 'google',
    category: 'script_analysis',
    prompt: `Analyze location and set requirements from this script:

SCRIPT CONTENT:
{script_content}

PRODUCTION CONTEXT:
Budget: {budget}
Filming Region: {region}
Season/Weather: {season}

Provide detailed location breakdown:

{
  "locations": [
    {
      "name": "",
      "type": "interior/exterior",
      "scenes_count": 0,
      "total_pages": 0,
      "description": "",
      "requirements": {
        "space_size": "",
        "special_features": [],
        "equipment_access": "",
        "power_requirements": "",
        "sound_considerations": ""
      },
      "logistics": {
        "availability": "",
        "permits_needed": [],
        "cost_estimate": "",
        "travel_distance": "",
        "backup_options": []
      },
      "creative_notes": {
        "mood": "",
        "lighting_style": "",
        "set_decoration": "",
        "props_needed": []
      }
    }
  ],
  "summary": {
    "total_locations": 0,
    "studio_vs_location": "",
    "most_complex_location": "",
    "budget_impact": "",
    "scheduling_priority": []
  }
}`,
    variables: ['script_content', 'budget', 'region', 'season'],
    example: 'Urban thriller script, Budget: $500K, Region: Los Angeles, Season: Winter'
  },

  {
    id: 'character_casting_profile',
    name: 'Character Casting Profiles',
    description: 'Create detailed casting profiles with physical and performance requirements',
    service: 'google',
    category: 'character_creation',
    prompt: `Create comprehensive casting profiles for characters in this {genre} project:

PROJECT INFO:
Script Excerpts: {script_excerpts}
Character Focus: {character_names}
Budget Level: {budget}
Target Market: {market}

Generate detailed casting profiles:

{
  "characters": [
    {
      "name": "",
      "importance": "lead/supporting/featured/background",
      "physical_requirements": {
        "age_range": "",
        "gender": "",
        "ethnicity": "open/specific",
        "height": "",
        "build": "",
        "distinctive_features": "",
        "special_skills": []
      },
      "performance_requirements": {
        "acting_experience": "professional/experienced/newcomer",
        "accent_needed": "",
        "languages": [],
        "physical_demands": [],
        "emotional_range": "",
        "chemistry_with": []
      },
      "character_details": {
        "personality": "",
        "background": "",
        "motivation": "",
        "character_arc": "",
        "key_scenes": [],
        "wardrobe_notes": ""
      },
      "casting_strategy": {
        "name_value": "required/preferred/unnecessary",
        "audition_requirements": [],
        "chemistry_reads": [],
        "reference_actors": [],
        "red_flags": []
      }
    }
  ]
}`,
    variables: ['genre', 'script_excerpts', 'character_names', 'budget', 'market'],
    example: 'Drama, Key dialogue scenes, Sarah and Michael, Indie budget, Film festival circuit'
  },

  {
    id: 'scene_technical_breakdown',
    name: 'Technical Scene Breakdown',
    description: 'Detailed technical analysis for production planning',
    service: 'google',
    category: 'scene_description',
    prompt: `Create technical breakdown for this scene:

SCENE CONTENT:
{scene_text}

PRODUCTION PARAMETERS:
Shooting Format: {format}
Budget Tier: {budget}
Crew Size: {crew_size}
Equipment Available: {equipment}

Provide comprehensive technical breakdown:

{
  "scene_overview": {
    "scene_number": "",
    "location": "",
    "time": "",
    "page_count": 0,
    "estimated_screen_time": ""
  },
  "shot_list": [
    {
      "shot_number": "",
      "shot_type": "",
      "lens": "",
      "camera_movement": "",
      "subjects": "",
      "action": "",
      "duration": "",
      "special_notes": ""
    }
  ],
  "technical_requirements": {
    "cameras": [],
    "lenses": [],
    "lighting_setup": {
      "key_light": "",
      "fill_light": "",
      "back_light": "",
      "practical_lights": [],
      "special_lighting": []
    },
    "audio": {
      "microphones": [],
      "recording_format": "",
      "playback_needs": [],
      "sync_requirements": ""
    },
    "special_equipment": [],
    "crew_positions": []
  },
  "logistics": {
    "setup_time": "",
    "shooting_time": "",
    "strike_time": "",
    "total_time": "",
    "crew_call_time": "",
    "special_considerations": []
  }
}`,
    variables: ['scene_text', 'format', 'budget', 'crew_size', 'equipment'],
    example: 'Dialogue scene in car, Digital 4K, Micro budget, 5 person crew, Basic lighting kit'
  },

  {
    id: 'storyboard_frame_detailed',
    name: 'Detailed Storyboard Frame Description',
    description: 'Generate comprehensive visual descriptions for precise storyboard creation',
    service: 'google',
    category: 'scene_description',
    prompt: `Create detailed storyboard frame description:

SHOT SPECIFICATIONS:
Scene Context: {scene_context}
Shot Number: {shot_number}
Shot Type: {shot_type}
Characters: {characters}
Action/Dialogue: {action}
Mood/Tone: {mood}
Visual Style: {visual_style}

Generate comprehensive frame description:

{
  "frame_details": {
    "shot_type": "",
    "camera_angle": "",
    "lens_choice": "",
    "depth_of_field": "",
    "composition_rule": ""
  },
  "subjects": [
    {
      "character": "",
      "position": "",
      "expression": "",
      "gesture": "",
      "eye_line": "",
      "costume_notes": ""
    }
  ],
  "environment": {
    "location": "",
    "background_elements": [],
    "foreground_elements": [],
    "props": [],
    "atmosphere": ""
  },
  "lighting": {
    "time_of_day": "",
    "light_source": "",
    "contrast": "high/medium/low",
    "shadows": "",
    "color_temperature": ""
  },
  "visual_description": "",
  "technical_notes": {
    "camera_movement": "",
    "focus_changes": "",
    "special_effects": [],
    "post_production_notes": ""
  }
}`,
    variables: ['scene_context', 'shot_number', 'shot_type', 'characters', 'action', 'mood', 'visual_style'],
    example: 'Coffee shop confrontation, Shot 15, Close-up, Detective Sarah, Reveals evidence, Tense, Film noir'
  },

  // =================== MINIMAX PROMPTS ===================
  // Image Generation
  {
    id: 'professional_storyboard_image',
    name: 'Professional Storyboard Image',
    description: 'Generate high-quality cinematic storyboard frames',
    service: 'minimax',
    category: 'image_generation',
    prompt: `Professional storyboard frame: {shot_description}

Style: {visual_style}
Composition: {shot_type} shot, {camera_angle} angle
Subject: {characters}
Setting: {location}
Mood: {mood}
Lighting: {lighting_style}

Cinematic quality, storyboard illustration style, clean composition, professional film production, detailed character expressions, {aspect_ratio} aspect ratio`,
    variables: ['shot_description', 'visual_style', 'shot_type', 'camera_angle', 'characters', 'location', 'mood', 'lighting_style', 'aspect_ratio'],
    example: 'Detective examining evidence, Film noir, Medium, Low angle, Sarah Mitchell, Police station, Dramatic, Hard shadows, 16:9',
    difficulty: 'beginner',
    estimatedTime: '2-5 minutes',
    tags: ['storyboard', 'cinematic', 'professional']
  },

  {
    id: 'concept_art_generation',
    name: 'Concept Art Generation',
    description: 'Create visual concept art for locations, characters, and scenes',
    service: 'minimax',
    category: 'image_generation',
    prompt: `Concept art illustration: {concept_description}

Art Style: {art_style}
Medium: {medium}
Color Palette: {color_palette}
Mood: {mood}
Level of Detail: {detail_level}

Professional concept art, film pre-production style, detailed environment, atmospheric lighting, {aspect_ratio} aspect ratio`,
    variables: ['concept_description', 'art_style', 'medium', 'color_palette', 'mood', 'detail_level', 'aspect_ratio'],
    example: 'Futuristic police station interior, Sci-fi realism, Digital painting, Cool blues and whites, Clinical, High detail, 21:9'
  },

  {
    id: 'character_reference_sheet',
    name: 'Character Reference Sheet',
    description: 'Generate character reference images for casting and costume design',
    service: 'minimax',
    category: 'image_generation',
    prompt: `Character reference sheet: {character_description}

Physical Details: {physical_details}
Costume/Style: {costume_description}
Pose: {pose_type}
Expression: {expression}
Background: {background_type}

Professional character design, film production reference, multiple angles, detailed costume and styling, neutral background for reference, {aspect_ratio} aspect ratio`,
    variables: ['character_description', 'physical_details', 'costume_description', 'pose_type', 'expression', 'background_type', 'aspect_ratio'],
    example: 'Detective Sarah Mitchell, 35, professional woman, Dark suit and badge, Standing confident, Determined, Plain studio, 4:3'
  },

  {
    id: 'location_establishing_shot',
    name: 'Location Establishing Shot',
    description: 'Create establishing shots for key locations in your story',
    service: 'minimax',
    category: 'image_generation',
    prompt: `Establishing shot: {location_description}

Time of Day: {time_of_day}
Weather: {weather}
Season: {season}
Architectural Style: {architecture}
Atmosphere: {atmosphere}

Cinematic establishing shot, wide angle perspective, environmental storytelling, professional cinematography, detailed architecture and environment, {aspect_ratio} aspect ratio`,
    variables: ['location_description', 'time_of_day', 'weather', 'season', 'architecture', 'atmosphere', 'aspect_ratio'],
    example: 'Modern police station exterior, Early morning, Light rain, Autumn, Glass and concrete, Official and imposing, 21:9'
  },

  // Video Generation
  {
    id: 'animatic_sequence',
    name: 'Animatic Sequence',
    description: 'Create animated sequences from storyboard frames',
    service: 'minimax',
    category: 'video_generation',
    prompt: `Animatic sequence: {sequence_description}

Duration: {duration} seconds
Camera Movement: {camera_movement}
Character Actions: {character_actions}
Transitions: {transition_style}
Timing: {timing_notes}

Smooth cinematic animation, storyboard-to-film style, professional timing and pacing, clear character movement and expressions`,
    variables: ['sequence_description', 'duration', 'camera_movement', 'character_actions', 'transition_style', 'timing_notes'],
    example: 'Detective walks through office to desk, 6, Slow push-in, Confident stride then pause, Smooth cuts, Emphasize revelation moment',
    difficulty: 'intermediate',
    estimatedTime: '5-10 minutes',
    tags: ['animation', 'preview', 'motion']
  },

  {
    id: 'motion_test_video',
    name: 'Motion Test Video',
    description: 'Generate motion tests for complex camera movements and actions',
    service: 'minimax',
    category: 'video_generation',
    prompt: `Motion test: {motion_description}

Scene Context: {scene_context}
Camera Work: {camera_work}
Performance: {performance_notes}
Duration: {duration} seconds
Focus: {focus_element}

Professional motion study, film production test, detailed movement analysis, clear timing and rhythm, cinematic quality`,
    variables: ['motion_description', 'scene_context', 'camera_work', 'performance_notes', 'duration', 'focus_element'],
    example: 'Character revelation moment, Intense dialogue scene, Slow zoom to close-up, Subtle facial expression changes, 8, Eyes and emotion',
    difficulty: 'advanced',
    estimatedTime: '3-8 minutes',
    tags: ['camera movement', 'test', 'performance']
  },

  {
    id: 'scene_preview_video',
    name: 'Scene Preview Video',
    description: 'Create full scene previews combining multiple shots',
    service: 'minimax',
    category: 'video_generation',
    prompt: `Scene preview video: {scene_description}

Story Context: {story_context}
Shot Sequence: {shot_breakdown}
Duration: {total_duration} seconds
Music Style: {music_mood}
Dialogue: {dialogue_text}

Complete scene visualization, professional film preview quality, cohesive storytelling, appropriate pacing and rhythm`,
    variables: ['scene_description', 'story_context', 'shot_breakdown', 'total_duration', 'music_mood', 'dialogue_text'],
    example: 'Police interrogation climax, Crime thriller third act, Wide-Medium-Close-Up sequence, 45, Tense minimalist, Confrontation about evidence',
    difficulty: 'advanced',
    estimatedTime: '10-15 minutes',
    tags: ['scene', 'preview', 'complete']
  },

  // Audio Generation
  {
    id: 'voice_over_narration',
    name: 'Voice-Over Narration',
    description: 'Generate professional voice-over for storyboard presentations',
    service: 'minimax',
    category: 'audio_generation',
    prompt: `Voice-over narration: {narration_text}

Voice Character: {voice_type}
Tone: {tone}
Pace: {pace}
Emotion: {emotion}
Context: {context}

Professional narration quality, clear articulation, appropriate emotional delivery, film presentation style`,
    variables: ['narration_text', 'voice_type', 'tone', 'pace', 'emotion', 'context'],
    example: 'Detective Sarah Chen investigates a series of cyber crimes, Professional female, Serious, Moderate, Determined, Crime thriller intro',
    difficulty: 'beginner',
    estimatedTime: '2-5 minutes',
    tags: ['narration', 'voice-over', 'presentation']
  },

  {
    id: 'character_dialogue_audio',
    name: 'Character Dialogue Audio',
    description: 'Generate character dialogue for storyboard scene testing',
    service: 'minimax',
    category: 'audio_generation',
    prompt: `Character dialogue: {dialogue_text}

Character: {character_name}
Character Voice: {voice_description}
Emotion: {emotion_state}
Scene Context: {scene_context}
Delivery Style: {delivery_style}

Authentic character voice, emotional authenticity, clear dialogue delivery, film-quality performance`,
    variables: ['dialogue_text', 'character_name', 'voice_description', 'emotion_state', 'scene_context', 'delivery_style'],
    example: 'I know what you did last night, Detective Sarah Chen, Confident professional woman, Threatening, Confrontation scene, Cold and calculating',
    difficulty: 'intermediate',
    estimatedTime: '3-7 minutes',
    tags: ['dialogue', 'character', 'performance']
  },

  {
    id: 'ambient_sound_design',
    name: 'Ambient Sound Design',
    description: 'Create atmospheric audio for scene enhancement',
    service: 'minimax',
    category: 'audio_generation',
    prompt: `Ambient sound design: {environment_description}

Location: {location_type}
Time: {time_of_day}
Weather: {weather_conditions}
Mood: {atmospheric_mood}
Intensity: {sound_intensity}

Immersive environmental audio, realistic atmosphere, mood-enhancing soundscape, professional film quality`,
    variables: ['environment_description', 'location_type', 'time_of_day', 'weather_conditions', 'atmospheric_mood', 'sound_intensity'],
    example: 'Police station at night during storm, Urban interior, Late night, Heavy rain, Tense and foreboding, Medium intensity',
    difficulty: 'intermediate',
    estimatedTime: '5-10 minutes',
    tags: ['ambient', 'atmosphere', 'environment']
  },

  // =================== DEEPSEEK PROMPTS ===================
  // Advanced Script Analysis
  {
    id: 'narrative_logic_analysis',
    name: 'Narrative Logic & Structure Analysis',
    description: 'Deep logical analysis of story structure, plot consistency, and narrative flow',
    service: 'deepseek',
    category: 'reasoning',
    prompt: `Perform comprehensive narrative logic analysis:

SCRIPT CONTENT:
{script_content}

ANALYSIS PARAMETERS:
Genre: {genre}
Target Audience: {audience}
Runtime Goal: {runtime}
Budget Constraints: {budget_notes}

Conduct systematic analysis using logical reasoning:

1. STRUCTURAL INTEGRITY:
   - Three-act structure compliance and effectiveness
   - Plot point placement and dramatic timing
   - Subplot integration and resolution
   - Pacing rhythm and momentum maintenance

2. LOGICAL CONSISTENCY:
   - Character motivation alignment with actions
   - Plot progression logical flow
   - World-building rules consistency
   - Timeline and continuity accuracy

3. CAUSAL RELATIONSHIPS:
   - Cause-and-effect chain strength
   - Character decisions consequence logic
   - Plot device necessity and believability
   - Conflict escalation logical progression

4. NARRATIVE EFFICIENCY:
   - Scene necessity and function analysis
   - Dialogue purposefulness evaluation
   - Exposition integration effectiveness
   - Redundancy identification and elimination

5. AUDIENCE ENGAGEMENT FACTORS:
   - Emotional beats placement and intensity
   - Suspense and tension management
   - Character empathy and investment potential
   - Payoff setup and delivery effectiveness

Provide detailed findings with specific examples, logical reasoning for each conclusion, and prioritized improvement recommendations.`,
    variables: ['script_content', 'genre', 'audience', 'runtime', 'budget_notes'],
    example: 'Thriller screenplay, Adult mainstream, 120 minutes, Mid-budget studio production',
    difficulty: 'advanced',
    estimatedTime: '20-45 minutes',
    tags: ['logic', 'structure', 'analysis', 'reasoning']
  },

  {
    id: 'character_psychology_analysis',
    name: 'Character Psychology & Motivation Analysis',
    description: 'Deep psychological analysis of character development and behavioral consistency',
    service: 'deepseek',
    category: 'reasoning',
    prompt: `Analyze character psychology and motivational logic:

CHARACTER DATA:
Script Excerpts: {character_scenes}
Character Background: {background_info}
Story Arc: {character_arc}
Relationships: {relationship_dynamics}

ANALYSIS FRAMEWORK:
Genre Psychology: {genre_psychology}
Audience Expectations: {audience_expectations}

Conduct systematic character analysis:

1. PSYCHOLOGICAL FOUNDATION:
   - Core personality traits consistency
   - Backstory influence on present behavior
   - Internal conflict structure and resolution
   - Character growth catalyst identification

2. MOTIVATIONAL COHERENCE:
   - Primary goal clarity and believability
   - Secondary motivation consistency
   - Obstacle response logical patterns
   - Decision-making process authenticity

3. BEHAVIORAL CONSISTENCY:
   - Action-to-motivation alignment
   - Dialogue voice authenticity
   - Emotional response appropriateness
   - Character arc progression logic

4. RELATIONSHIP DYNAMICS:
   - Interpersonal chemistry believability
   - Conflict source legitimacy
   - Emotional investment justification
   - Character influence mutual impact

5. DEVELOPMENT OPPORTUNITIES:
   - Underutilized character potential
   - Missing psychological depth areas
   - Inconsistency resolution strategies
   - Arc enhancement possibilities

Provide character-specific insights with psychological reasoning, behavioral pattern analysis, and development recommendations.`,
    variables: ['character_scenes', 'background_info', 'character_arc', 'relationship_dynamics', 'genre_psychology', 'audience_expectations'],
    example: 'Detective Sarah key scenes, Military background with PTSD, Journey from isolation to trust, Partner relationships, Crime thriller psychology, Adult drama expectations'
  },

  {
    id: 'production_feasibility_analysis',
    name: 'Production Feasibility & Optimization Analysis',
    description: 'Logical analysis of production challenges and optimization strategies',
    service: 'deepseek',
    category: 'reasoning',
    prompt: `Analyze production feasibility and optimization opportunities:

PROJECT PARAMETERS:
Script Content: {script_summary}
Budget Range: {budget_range}
Timeline: {production_timeline}
Resources: {available_resources}
Team Experience: {team_experience}
Distribution Goals: {distribution_goals}

CONSTRAINT ANALYSIS:
Location Limitations: {location_constraints}
Casting Constraints: {casting_constraints}
Technical Limitations: {technical_constraints}

Conduct comprehensive feasibility analysis:

1. BUDGET OPTIMIZATION LOGIC:
   - Scene complexity vs. budget allocation analysis
   - Cost-benefit analysis for each major sequence
   - Resource allocation efficiency opportunities
   - Alternative approach cost comparisons

2. SCHEDULING LOGIC:
   - Location availability constraint mapping
   - Cast availability optimization strategies
   - Crew efficiency workflow analysis
   - Weather and seasonal factor integration

3. TECHNICAL FEASIBILITY:
   - Equipment requirement vs. capability analysis
   - Special effects complexity assessment
   - Post-production demand evaluation
   - Quality standard achievability analysis

4. RISK ASSESSMENT:
   - Production challenge probability analysis
   - Mitigation strategy effectiveness evaluation
   - Contingency plan necessity identification
   - Budget overrun risk factor analysis

5. OPTIMIZATION STRATEGIES:
   - Script modification for efficiency gains
   - Production method alternative evaluation
   - Resource sharing and partnership opportunities
   - Quality vs. speed vs. cost optimization

Provide logical reasoning for all conclusions, quantified risk assessments, and prioritized optimization recommendations.`,
    variables: ['script_summary', 'budget_range', 'production_timeline', 'available_resources', 'team_experience', 'distribution_goals', 'location_constraints', 'casting_constraints', 'technical_constraints'],
    example: 'Urban thriller, $500K-750K, 6 months, Independent crew, First-time director, Film festival then streaming, Limited to local area, Non-union actors, Basic equipment package'
  },

  {
    id: 'market_positioning_analysis',
    name: 'Market Positioning & Commercial Viability Analysis',
    description: 'Strategic analysis of market positioning and commercial potential',
    service: 'deepseek',
    category: 'reasoning',
    prompt: `Analyze market positioning and commercial viability:

PROJECT PROFILE:
Genre: {genre}
Target Audience: {target_demographics}
Unique Elements: {unique_selling_points}
Comparable Films: {comparable_titles}
Budget Tier: {budget_tier}
Distribution Strategy: {distribution_plan}

MARKET CONTEXT:
Current Trends: {market_trends}
Competition: {competitive_landscape}
Platform Preferences: {platform_data}

Conduct strategic market analysis:

1. COMPETITIVE POSITIONING:
   - Market gap identification and exploitation potential
   - Competitive advantage sustainability analysis
   - Differentiation factor strength evaluation
   - Market saturation risk assessment

2. AUDIENCE TARGETING LOGIC:
   - Primary audience engagement probability
   - Secondary audience expansion opportunities
   - Demographic preference alignment analysis
   - Cultural relevance and accessibility evaluation

3. COMMERCIAL VIABILITY:
   - Revenue potential across distribution channels
   - Break-even analysis and profitability projections
   - Investment return probability assessment
   - Market timing optimization strategies

4. PLATFORM STRATEGY:
   - Distribution channel effectiveness comparison
   - Platform audience alignment analysis
   - Release strategy optimization recommendations
   - Cross-platform synergy opportunities

5. RISK MITIGATION:
   - Market rejection probability factors
   - Competition response anticipation
   - Trend shift adaptation strategies
   - Financial protection mechanisms

Provide data-driven reasoning, market positioning recommendations, and strategic decision frameworks.`,
    variables: ['genre', 'target_demographics', 'unique_selling_points', 'comparable_titles', 'budget_tier', 'distribution_plan', 'market_trends', 'competitive_landscape', 'platform_data'],
    example: 'Psychological thriller, 25-45 urban professionals, Female-driven narrative, Gone Girl meets Black Mirror, Mid-budget indie, Festival-to-streaming, Elevated genre trend, Crowded market, Netflix/Hulu preference'
  },

  // =================== OPENAI PROMPTS ===================
  // Creative Writing & Development
  {
    id: 'script_polish_professional',
    name: 'Professional Script Polish',
    description: 'Comprehensive script enhancement for professional quality and marketability',
    service: 'openai',
    category: 'content_generation',
    prompt: `Polish this script to professional industry standards:

SCRIPT CONTENT:
{script_text}

ENHANCEMENT PARAMETERS:
Target Market: {target_market}
Genre Expectations: {genre_conventions}
Audience Demographics: {audience_demographics}
Production Level: {budget_tier}

Provide comprehensive polish including:

1. STRUCTURE REFINEMENT:
   - Pacing optimization for engagement
   - Scene transition smoothness
   - Act break placement and impact
   - Subplot integration elegance

2. CHARACTER VOICE ENHANCEMENT:
   - Distinctive dialogue for each character
   - Subtext and emotional layering
   - Voice consistency throughout
   - Authentic speech patterns

3. VISUAL STORYTELLING:
   - Show vs. tell balance optimization
   - Cinematic writing techniques
   - Action line efficiency and clarity
   - Visual metaphor integration

4. EMOTIONAL IMPACT:
   - Tension building and release
   - Character moment amplification
   - Emotional beat placement
   - Cathartic payoff enhancement

5. PROFESSIONAL FORMATTING:
   - Industry standard formatting
   - Scene header optimization
   - Action line clarity and brevity
   - Dialogue presentation polish

6. MARKETABILITY ENHANCEMENT:
   - Hook strengthening
   - Commercial appeal amplification
   - Genre compliance with originality
   - Memorable moment creation

Deliver the enhanced script with detailed change explanations and industry reasoning.`,
    variables: ['script_text', 'target_market', 'genre_conventions', 'audience_demographics', 'budget_tier'],
    example: 'Thriller opening sequence, Studio/streaming, Psychological thriller expectations, 18-54 mainstream, Mid-budget',
    difficulty: 'advanced',
    estimatedTime: '30-60 minutes',
    tags: ['professional', 'polish', 'industry', 'enhancement']
  },

  {
    id: 'dialogue_mastery',
    name: 'Dialogue Mastery Enhancement',
    description: 'Transform dialogue for authenticity, character voice, and dramatic impact',
    service: 'openai',
    category: 'content_generation',
    prompt: `Transform dialogue to master-level quality:

SCENE CONTEXT:
Original Dialogue: {original_dialogue}
Character Profiles: {character_details}
Scene Purpose: {scene_objective}
Emotional Stakes: {emotional_context}
Genre Style: {genre_style}
Subtext Needs: {subtext_requirements}

Enhancement approach:

1. AUTHENTIC VOICE CREATION:
   - Character-specific speech patterns
   - Background-influenced vocabulary
   - Age and education appropriate language
   - Regional or cultural authenticity

2. SUBTEXT LAYERING:
   - Hidden meanings and motivations
   - Emotional undercurrents
   - Power dynamics revelation
   - Relationship tension articulation

3. DRAMATIC EFFICIENCY:
   - Information delivery elegance
   - Conflict escalation through words
   - Emotional beat precision
   - Memorable line creation

4. NATURAL FLOW:
   - Interruption and overlap realism
   - Pause and silence utilization
   - Rhythm and pacing variation
   - Breathing space integration

5. GENRE MASTERY:
   - Style-appropriate delivery
   - Expectation fulfillment with surprise
   - Tone consistency maintenance
   - Commercial appeal balance

Provide the enhanced dialogue with character voice notes, subtext explanations, and performance guidance.`,
    variables: ['original_dialogue', 'character_details', 'scene_objective', 'emotional_context', 'genre_style', 'subtext_requirements'],
    example: 'Police interrogation scene, Experienced detective vs. suspect, Truth revelation, High tension, Crime drama, Power struggle and hidden guilt'
  },

  {
    id: 'creative_problem_solving',
    name: 'Creative Problem Solving',
    description: 'Generate innovative solutions for story, character, and production challenges',
    service: 'openai',
    category: 'content_generation',
    prompt: `Solve creative challenges with innovative approaches:

CHALLENGE DETAILS:
Primary Problem: {main_challenge}
Story Context: {story_context}
Character Constraints: {character_limitations}
Production Constraints: {production_limitations}
Genre Requirements: {genre_expectations}
Audience Expectations: {audience_needs}

CREATIVE PARAMETERS:
Budget Level: {budget_level}
Timeline: {time_constraints}
Available Resources: {available_resources}

Generate comprehensive solutions:

1. MULTIPLE CREATIVE APPROACHES:
   - Traditional solution with fresh twist
   - Unconventional but effective alternative
   - Budget-conscious creative workaround
   - High-impact innovative solution
   - Collaborative audience-engaging approach

2. STORY SOLUTIONS:
   - Plot hole resolution strategies
   - Character motivation clarification
   - Pacing improvement techniques
   - Theme reinforcement methods
   - Emotional impact amplification

3. PRODUCTION SOLUTIONS:
   - Location constraint workarounds
   - Budget limitation creative solutions
   - Technical challenge innovations
   - Schedule optimization strategies
   - Resource maximization techniques

4. IMPLEMENTATION STRATEGIES:
   - Step-by-step execution plans
   - Risk assessment and mitigation
   - Success measurement criteria
   - Alternative backup plans
   - Stakeholder buy-in approaches

Provide detailed explanations, creative reasoning, practical implementation steps, and expected outcomes for each solution.`,
    variables: ['main_challenge', 'story_context', 'character_limitations', 'production_limitations', 'genre_expectations', 'audience_needs', 'budget_level', 'time_constraints', 'available_resources'],
    example: 'Protagonist motivation unclear, Mystery thriller, Introverted character, Single location constraint, Audience needs clear stakes, Adult mystery readers, Micro budget, 30-day shoot, One experienced actor'
  },

  {
    id: 'pitch_development_mastery',
    name: 'Pitch Development Mastery',
    description: 'Create compelling pitches, loglines, and marketing materials for industry professionals',
    service: 'openai',
    category: 'content_generation',
    prompt: `Develop master-level pitch materials:

PROJECT FOUNDATION:
Title: {project_title}
Genre: {genre}
Logline Draft: {current_logline}
Story Summary: {story_overview}
Unique Elements: {unique_selling_points}
Target Audience: {target_demographics}
Comparable Films: {comparables}
Budget Range: {budget_estimate}

PITCH CONTEXT:
Audience: {pitch_audience}
Objective: {pitch_goal}
Format: {presentation_format}
Time Limit: {time_constraint}

Create comprehensive pitch package:

1. PERFECTED LOGLINE (25 words maximum):
   - Immediate hook that demands attention
   - Clear protagonist with relatable stakes
   - Conflict and urgency indication
   - Genre and tone suggestion
   - Commercial appeal integration

2. ELEVATOR PITCH (30-60 seconds):
   - Memorable opening hook
   - Concise story setup
   - Character and conflict introduction
   - Unique angle emphasis
   - Call to action conclusion

3. SHORT SYNOPSIS (1 paragraph):
   - Engaging story overview
   - Key character journey
   - Major plot points
   - Emotional core revelation
   - Market appeal factors

4. DETAILED TREATMENT (1-2 pages):
   - Complete story progression
   - Character development arcs
   - Thematic exploration
   - Visual storytelling highlights
   - Production value indicators

5. MARKETING POSITIONING:
   - Target audience definition
   - Competition differentiation
   - Platform strategy alignment
   - Revenue potential indicators
   - Festival and awards potential

Include presentation strategies, anticipated questions with answers, and stakeholder-specific customization options.`,
    variables: ['project_title', 'genre', 'current_logline', 'story_overview', 'unique_selling_points', 'target_demographics', 'comparables', 'budget_estimate', 'pitch_audience', 'pitch_goal', 'presentation_format', 'time_constraint'],
    example: 'Silent Witness, Psychological thriller, Woman with selective mutism solves crimes through observation, Complex female protagonist in male-dominated genre, 25-45 educated adults, Sicario meets A Quiet Place, $3-5M, Studio executives, Greenlight, In-person meeting, 15 minutes'
  },

  {
    id: 'scene_rewrite_mastery',
    name: 'Scene Rewrite Mastery',
    description: 'Transform scenes for maximum dramatic impact and professional quality',
    service: 'openai',
    category: 'content_generation',
    prompt: `Rewrite scene for professional mastery:

ORIGINAL SCENE:
{original_scene}

REWRITE PARAMETERS:
Scene Objective: {scene_purpose}
Character Goals: {character_objectives}
Emotional Journey: {emotional_arc}
Conflict Level: {conflict_intensity}
Information Delivery: {exposition_needs}
Visual Opportunities: {visual_potential}
Genre Requirements: {genre_expectations}

ENHANCEMENT GOALS:
Primary Focus: {main_improvement}
Secondary Focus: {secondary_improvement}
Budget Consideration: {budget_factor}

Comprehensive scene rewrite including:

1. STRUCTURAL OPTIMIZATION:
   - Scene opening hook enhancement
   - Conflict escalation management
   - Information delivery elegance
   - Scene conclusion impact
   - Transition setup effectiveness

2. CHARACTER DEVELOPMENT:
   - Goal clarity and pursuit
   - Obstacle response authenticity
   - Relationship dynamic evolution
   - Voice distinctiveness
   - Growth moment integration

3. DIALOGUE MASTERY:
   - Subtext layering
   - Conflict through conversation
   - Information weaving
   - Emotional authenticity
   - Memorable moment creation

4. VISUAL STORYTELLING:
   - Show vs. tell optimization
   - Action line efficiency
   - Cinematic potential maximization
   - Production feasibility
   - Visual metaphor integration

5. EMOTIONAL IMPACT:
   - Stakes clarification
   - Tension building
   - Character moment amplification
   - Audience engagement maintenance
   - Payoff preparation

Provide the rewritten scene with change explanations, performance notes, and production considerations.`,
    variables: ['original_scene', 'scene_purpose', 'character_objectives', 'emotional_arc', 'conflict_intensity', 'exposition_needs', 'visual_potential', 'genre_expectations', 'main_improvement', 'secondary_improvement', 'budget_factor'],
    example: 'Police station confrontation, Reveal partnership betrayal, Detective seeks truth vs. partner protects secret, Shock to anger to determination, High intensity, Past case connection, Visual tension through space, Crime thriller, Dialogue impact, Character revelation, Single location'
  }
];

// Advanced helper functions for prompt management
export const getPromptsByService = (service: string): PromptTemplate[] => {
  return PROMPT_LIBRARY.filter(prompt => prompt.service === service);
};

export const getPromptsByCategory = (category: string): PromptTemplate[] => {
  return PROMPT_LIBRARY.filter(prompt => prompt.category === category);
};

export const getPromptsByDifficulty = (difficulty: 'beginner' | 'intermediate' | 'advanced'): PromptTemplate[] => {
  return PROMPT_LIBRARY.filter(prompt => prompt.difficulty === difficulty);
};

export const getPromptsByTag = (tag: string): PromptTemplate[] => {
  return PROMPT_LIBRARY.filter(prompt => prompt.tags?.includes(tag));
};

export const getPromptById = (id: string): PromptTemplate | undefined => {
  return PROMPT_LIBRARY.find(prompt => prompt.id === id);
};

export const searchPrompts = (searchTerm: string): PromptTemplate[] => {
  const term = searchTerm.toLowerCase();
  return PROMPT_LIBRARY.filter(prompt => 
    prompt.name.toLowerCase().includes(term) ||
    prompt.description.toLowerCase().includes(term) ||
    prompt.tags?.some(tag => tag.toLowerCase().includes(term))
  );
};

export const getRecommendedPrompts = (service: string, userLevel: 'beginner' | 'intermediate' | 'advanced'): PromptTemplate[] => {
  const servicePrompts = getPromptsByService(service);
  const difficultyPrompts = servicePrompts.filter(p => p.difficulty === userLevel || !p.difficulty);
  return difficultyPrompts.slice(0, 3); // Return top 3 recommended
};

export const replaceVariables = (prompt: string, variables: Record<string, string>): string => {
  let result = prompt;
  Object.entries(variables).forEach(([key, value]) => {
    result = result.replace(new RegExp(`{${key}}`, 'g'), value);
  });
  return result;
};

export const validatePromptVariables = (prompt: PromptTemplate, variables: Record<string, string>): string[] => {
  const missing: string[] = [];
  const requiredVars = prompt.variables || [];
  
  requiredVars.forEach(variable => {
    if (!variables[variable] || variables[variable].trim() === '') {
      missing.push(variable);
    }
  });
  
  return missing;
};

export const getPromptTemplate = (promptId: string, variables: Record<string, string>): string => {
  const prompt = getPromptById(promptId);
  if (!prompt) throw new Error(`Prompt with ID "${promptId}" not found`);
  
  const missingVars = validatePromptVariables(prompt, variables);
  if (missingVars.length > 0) {
    throw new Error(`Missing required variables: ${missingVars.join(', ')}`);
  }
  
  return replaceVariables(prompt.prompt, variables);
};

// Prompt statistics and analytics
export const getPromptStats = () => {
  const stats = {
    total: PROMPT_LIBRARY.length,
    byService: {} as Record<string, number>,
    byCategory: {} as Record<string, number>,
    byDifficulty: {} as Record<string, number>
  };
  
  PROMPT_LIBRARY.forEach(prompt => {
    // Count by service
    stats.byService[prompt.service] = (stats.byService[prompt.service] || 0) + 1;
    
    // Count by category
    stats.byCategory[prompt.category] = (stats.byCategory[prompt.category] || 0) + 1;
    
    // Count by difficulty
    if (prompt.difficulty) {
      stats.byDifficulty[prompt.difficulty] = (stats.byDifficulty[prompt.difficulty] || 0) + 1;
    }
  });
  
  return stats;
};

// Quick start prompts for testing each service
export const QUICK_TEST_PROMPTS = {
  google: {
    basic: "Analyze this script: 'FADE IN: INT. COFFEE SHOP - DAY. JOHN (30s) sits writing. SARAH (20s) enters.' Extract characters and setting.",
    advanced: "Break down this scene into shots: INT. POLICE STATION - NIGHT. Detective SARAH (35) interrogates SUSPECT (40s) across metal table. Tension rises as evidence is revealed.",
    character: "Create a character profile for: ALEX CHEN, lead detective in cybercrime thriller, age 30-35, tech-savvy but struggles with personal relationships."
  },
  minimax: {
    image: "Professional cinematic shot: detective in film noir office, dramatic lighting, wide angle, 16:9 aspect ratio",
    video: "Animatic sequence: detective walking into interrogation room, 6 seconds, slow push-in, confident stride, smooth transition",
    audio: "Voice-over narration: 'The case that would change everything began on a Tuesday morning', Professional female, Serious, Moderate, Determined, Crime thriller intro",
    concept: "Concept art: futuristic police station lobby, glass and steel architecture, blue and white color palette, high detail, 21:9"
  },
  deepseek: {
    logic: "Analyze the story logic: A detective discovers evidence that implicates their partner in a crime. What are the logical plot developments and potential plot holes?",
    structure: "Evaluate this story structure: Act 1 - Setup (25%), Act 2A - Rising action (25%), Act 2B - Complications (25%), Act 3 - Resolution (25%). Is this effective for a thriller?",
    production: "Assess production feasibility: Urban thriller, 20 locations, $500K budget, 30-day shoot, 5-person crew. What are the major challenges and solutions?"
  },
  openai: {
    dialogue: "Enhance this dialogue to make it more natural and add subtext: 'Hello there. How are you doing today? I am fine, thank you.'",
    creative: "Solve this story problem: My protagonist needs to discover the villain's identity, but I've written them as too isolated to get information naturally. Give me 3 creative solutions.",
    pitch: "Create a compelling logline for: A mute forensic analyst solves crimes through observation while hiding her ability to hear everything."
  }
};

export default PROMPT_LIBRARY;
