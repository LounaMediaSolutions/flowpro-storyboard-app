// API Connection Testing Utilities

export interface ConnectionTest {
  service: string;
  status: 'connected' | 'error' | 'missing_key';
  message: string;
  responseTime?: number;
}

export class APITester {
  // Test Supabase connection
  static async testSupabase(): Promise<ConnectionTest> {
    const startTime = Date.now();
    
    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseKey || supabaseUrl === 'https://your-project.supabase.co') {
        return {
          service: 'Supabase',
          status: 'missing_key',
          message: 'Supabase credentials not configured. Please add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to your .env file.'
        };
      }
      
      // Test connection by checking the health endpoint
      const response = await fetch(`${supabaseUrl}/rest/v1/`, {
        headers: {
          'apikey': supabaseKey,
          'Authorization': `Bearer ${supabaseKey}`
        }
      });
      
      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        return {
          service: 'Supabase',
          status: 'connected',
          message: 'Successfully connected to Supabase database',
          responseTime
        };
      } else {
        return {
          service: 'Supabase',
          status: 'error',
          message: `Connection failed: ${response.status} ${response.statusText}`,
          responseTime
        };
      }
    } catch (error) {
      return {
        service: 'Supabase',
        status: 'error',
        message: `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        responseTime: Date.now() - startTime
      };
    }
  }

  // Test Google AI Studio connection
  static async testGoogleAI(): Promise<ConnectionTest> {
    const startTime = Date.now();
    
    try {
      const apiKey = import.meta.env.VITE_GOOGLE_AI_KEY;
      
      if (!apiKey || apiKey === 'demo-key') {
        return {
          service: 'Google AI Studio',
          status: 'missing_key',
          message: 'Google AI API key not configured. Please add VITE_GOOGLE_AI_KEY to your .env file.'
        };
      }
      
      // Test with a simple generation request
      const response = await fetch(
        `https://generativeai.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: "Hello, respond with just 'OK' if you're working."
              }]
            }]
          })
        }
      );
      
      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        const data = await response.json();
        return {
          service: 'Google AI Studio',
          status: 'connected',
          message: 'Successfully connected to Google AI Studio',
          responseTime
        };
      } else {
        const errorData = await response.text();
        return {
          service: 'Google AI Studio',
          status: 'error',
          message: `API error: ${response.status} - ${errorData}`,
          responseTime
        };
      }
    } catch (error) {
      return {
        service: 'Google AI Studio',
        status: 'error',
        message: `Connection error: ${error instanceof Error ? error.message : 'Unknown error'}`,
        responseTime: Date.now() - startTime
      };
    }
  }

  // Test MiniMax connection
  static async testMiniMax(): Promise<ConnectionTest> {
    const apiKey = import.meta.env.VITE_MINIMAX_API_KEY;
    
    if (!apiKey) {
      return {
        service: 'MiniMax',
        status: 'missing_key',
        message: 'MiniMax API key not configured. This is optional for advanced features.'
      };
    }
    
    // Note: Actual MiniMax API testing would go here
    // For now, just check if key is provided
    return {
      service: 'MiniMax',
      status: 'connected',
      message: 'MiniMax API key configured (connection not tested)',
    };
  }

  // Test Bubble.io connection
  static async testBubble(): Promise<ConnectionTest> {
    const apiKey = import.meta.env.VITE_BUBBLE_API_KEY;
    const appId = import.meta.env.VITE_BUBBLE_APP_ID;
    
    if (!apiKey || !appId) {
      return {
        service: 'Bubble.io',
        status: 'missing_key',
        message: 'Bubble.io credentials not configured. This is optional for workflow automation.'
      };
    }
    
    // Note: Actual Bubble API testing would go here
    return {
      service: 'Bubble.io',
      status: 'connected',
      message: 'Bubble.io credentials configured (connection not tested)',
    };
  }

  // Test Lovable.ai connection
  static async testLovable(): Promise<ConnectionTest> {
    const apiKey = import.meta.env.VITE_LOVABLE_API_KEY;
    
    if (!apiKey) {
      return {
        service: 'Lovable.ai',
        status: 'missing_key',
        message: 'Lovable.ai API key not configured. This is optional for code generation features.'
      };
    }
    
    return {
      service: 'Lovable.ai',
      status: 'connected',
      message: 'Lovable.ai API key configured (connection not tested)',
    };
  }

  // Test all connections
  static async testAllConnections(): Promise<ConnectionTest[]> {
    const tests = await Promise.all([
      this.testSupabase(),
      this.testGoogleAI(),
      this.testMiniMax(),
      this.testBubble(),
      this.testLovable()
    ]);
    
    return tests;
  }

  // Get connection status summary
  static getConnectionSummary(tests: ConnectionTest[]): {
    total: number;
    connected: number;
    missing: number;
    errors: number;
  } {
    return {
      total: tests.length,
      connected: tests.filter(t => t.status === 'connected').length,
      missing: tests.filter(t => t.status === 'missing_key').length,
      errors: tests.filter(t => t.status === 'error').length
    };
  }
}

export default APITester;
