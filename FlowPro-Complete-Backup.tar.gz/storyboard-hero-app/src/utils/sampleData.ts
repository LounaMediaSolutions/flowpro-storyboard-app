import { v4 as uuidv4 } from 'uuid';
import { Project, Episode } from '../types';

export const createSampleProject = (): Project => {
  const projectId = uuidv4();
  const episodeId = uuidv4();
  const sceneId1 = uuidv4();
  const sceneId2 = uuidv4();
  const sceneId3 = uuidv4();

  return {
    id: projectId,
    title: "FlowPro Commercial Series",
    description: "A professional commercial series showcasing FlowPro's revolutionary film production management platform.",
    projectType: 'series',
    thumbnail: "/images/flowpro-logo.png",
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    visualStyle: 'cinematic',
    characters: [
      {
        id: uuidv4(),
        projectId,
        name: "Director Maya",
        description: "Experienced film director, protagonist",
        appearance: "Professional woman in her 30s, confident, wearing director's attire with headset",
        traits: ["professional", "creative", "detail-oriented"]
      },
      {
        id: uuidv4(),
        projectId,
        name: "Production Team",
        description: "Professional film crew",
        appearance: "Diverse group of film professionals, cameras, equipment, collaborative atmosphere",
        traits: ["professional", "efficient", "collaborative"]
      }
    ],
    locations: [
      {
        id: uuidv4(),
        projectId,
        name: "Modern Film Studio",
        type: 'studio',
        description: "State-of-the-art film studio with professional lighting and equipment",
        availability: ["Mon-Fri 8AM-6PM"],
        cost: 500,
        contact: "studio@example.com"
      },
      {
        id: uuidv4(),
        projectId,
        name: "Corporate Office",
        type: 'location',
        description: "Modern corporate office space for business scenes",
        availability: ["Weekends"],
        cost: 200,
        contact: "locations@example.com"
      }
    ],
    episodes: [
      {
        id: episodeId,
        projectId,
        episodeNumber: 1,
        title: "The Revolution",
        description: "Introducing FlowPro as the game-changing film production platform",
        status: 'production',
        createdAt: new Date(),
        updatedAt: new Date(),
        scenes: [
          {
            id: sceneId1,
            episodeId,
            sceneNumber: 1,
            title: "Opening Hook",
            description: "Establish the challenge of traditional film production",
            location: "Modern Film Studio",
            timeOfDay: 'day',
            characters: [],
            isInterior: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            shots: [
              {
                id: uuidv4(),
                sceneId: sceneId1,
                shotNumber: 1,
                description: "Wide shot of chaotic film set with scattered papers and frustrated crew",
                voiceOver: "Film production doesn't have to be chaos.",
                characters: [],
                cameraAngle: 'wide_shot',
                cameraMovement: 'static',
                transition: 'fade_in',
                imageUrl: "/images/creative-team.webp",
                imagePrompt: "chaotic film set scattered papers frustrated crew, cinematic style",
                duration: 3,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "35mm",
                  aperture: "f/2.8",
                  iso: "400",
                  colorProfile: "Rec.709"
                },
                vfxNotes: [
                  {
                    id: uuidv4(),
                    shotId: '',
                    type: 'color_grading',
                    description: 'Enhance the contrast and add cinematic color grading',
                    complexity: 'simple',
                    status: 'pending',
                    estimatedCost: 150,
                    createdAt: new Date()
                  }
                ],
                audioNotes: [
                  {
                    id: uuidv4(),
                    shotId: '',
                    type: 'ambient',
                    description: 'Studio ambient sound with subtle equipment noise',
                    volume: 0.3,
                    fadeIn: 1
                  }
                ],
                createdAt: new Date(),
                updatedAt: new Date()
              },
              {
                id: uuidv4(),
                sceneId: sceneId1,
                shotNumber: 2,
                description: "Close-up of Director Maya looking determined",
                voiceOver: "Meet the future of film production management.",
                characters: [],
                cameraAngle: 'close_up',
                cameraMovement: 'zoom_in',
                transition: 'cut',
                imageUrl: "/images/director.jpg",
                imagePrompt: "determined film director close-up professional lighting, cinematic style",
                duration: 2.5,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "85mm",
                  aperture: "f/1.8",
                  iso: "200",
                  colorProfile: "Rec.709"
                },
                createdAt: new Date(),
                updatedAt: new Date()
              }
            ]
          },
          {
            id: sceneId2,
            episodeId,
            sceneNumber: 2,
            title: "FlowPro Solution",
            description: "Showcase FlowPro interface and capabilities",
            location: "Corporate Office",
            timeOfDay: 'day',
            characters: [],
            isInterior: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            shots: [
              {
                id: uuidv4(),
                sceneId: sceneId2,
                shotNumber: 1,
                description: "Screen recording of FlowPro interface with smooth animations",
                voiceOver: "FlowPro - where creativity meets efficiency",
                characters: [],
                cameraAngle: 'medium_shot',
                cameraMovement: 'dolly_in',
                transition: 'dissolve',
                imageUrl: "/images/digital-storyboard.jpg",
                imagePrompt: "professional software interface on large monitor, cinematic style",
                duration: 4,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "50mm",
                  aperture: "f/2.4",
                  iso: "320",
                  colorProfile: "Rec.709"
                },
                vfxNotes: [
                  {
                    id: uuidv4(),
                    shotId: '',
                    type: 'motion_graphics',
                    description: 'Add subtle UI animation highlights and callouts',
                    complexity: 'medium',
                    status: 'pending',
                    estimatedCost: 300,
                    createdAt: new Date()
                  }
                ],
                createdAt: new Date(),
                updatedAt: new Date()
              },
              {
                id: uuidv4(),
                sceneId: sceneId2,
                shotNumber: 2,
                description: "Director Maya using FlowPro, looking satisfied and in control",
                voiceOver: "Streamline your entire production workflow",
                characters: [],
                cameraAngle: 'over_shoulder',
                cameraMovement: 'pan_right',
                transition: 'cut',
                imageUrl: "/images/camera-production.jpg",
                imagePrompt: "professional director using film production software, satisfied expression, cinematic style",
                duration: 3.5,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "35mm",
                  aperture: "f/2.0",
                  iso: "250",
                  colorProfile: "Rec.709"
                },
                createdAt: new Date(),
                updatedAt: new Date()
              }
            ]
          },
          {
            id: sceneId3,
            episodeId,
            sceneNumber: 3,
            title: "Call to Action",
            description: "Strong call to action with FlowPro branding",
            location: "Modern Film Studio",
            timeOfDay: 'golden_hour',
            characters: [],
            isInterior: true,
            createdAt: new Date(),
            updatedAt: new Date(),
            shots: [
              {
                id: uuidv4(),
                sceneId: sceneId3,
                shotNumber: 1,
                description: "Montage of successful film production using FlowPro",
                voiceOver: "Join the revolution in film production management",
                characters: [],
                cameraAngle: 'wide_shot',
                cameraMovement: 'tracking',
                transition: 'wipe',
                duration: 3,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "24mm",
                  aperture: "f/2.8",
                  iso: "160",
                  colorProfile: "Rec.709"
                },
                createdAt: new Date(),
                updatedAt: new Date()
              },
              {
                id: uuidv4(),
                sceneId: sceneId3,
                shotNumber: 2,
                description: "FlowPro logo with tagline overlay",
                voiceOver: "FlowPro - Professional Film Production Made Simple",
                characters: [],
                cameraAngle: 'medium_shot',
                cameraMovement: 'zoom_out',
                transition: 'fade_out',
                duration: 4,
                technicalSpecs: {
                  frameRate: 24,
                  resolution: "4K",
                  focalLength: "50mm",
                  aperture: "f/4.0",
                  iso: "100",
                  colorProfile: "Rec.709"
                },
                createdAt: new Date(),
                updatedAt: new Date()
              }
            ]
          }
        ]
      }
    ],
    budget: {
      totalBudget: 50000,
      spent: 12500,
      remaining: 37500,
      categories: [
        {
          id: uuidv4(),
          name: 'Pre-Production',
          allocated: 10000,
          spent: 7500,
          items: []
        },
        {
          id: uuidv4(),
          name: 'Production',
          allocated: 25000,
          spent: 5000,
          items: []
        },
        {
          id: uuidv4(),
          name: 'Post-Production',
          allocated: 15000,
          spent: 0,
          items: []
        }
      ]
    },
    productionSettings: {
      defaultFrameRate: 24,
      defaultResolution: '4K',
      workingColorSpace: 'Rec.709',
      deliverySpecs: {
        formats: ['MP4', 'MOV', 'ProRes'],
        resolutions: ['1920x1080', '3840x2160'],
        frameRates: [24, 25, 30, 60],
        colorSpaces: ['Rec.709', 'Rec.2020'],
        audioSpecs: {
          sampleRate: 48000,
          bitDepth: 24,
          channels: 2,
          format: 'WAV'
        }
      },
      workflow: {
        backupEnabled: true,
        versionControl: true,
        collaborationMode: true,
        autoSave: true,
        notifications: true
      }
    }
  };
};

export const createEmptyProject = (title: string, description: string): Project => {
  return {
    id: uuidv4(),
    title,
    description,
    projectType: 'series',
    createdAt: new Date(),
    updatedAt: new Date(),
    episodes: [],
    characters: [],
    locations: [],
    visualStyle: 'cinematic',
    productionSettings: {
      defaultFrameRate: 24,
      defaultResolution: '1920x1080',
      workingColorSpace: 'Rec.709',
      deliverySpecs: {
        formats: ['MP4', 'MOV'],
        resolutions: ['1920x1080', '3840x2160'],
        frameRates: [24, 25, 30, 60],
        colorSpaces: ['Rec.709', 'Rec.2020'],
        audioSpecs: {
          sampleRate: 48000,
          bitDepth: 24,
          channels: 2,
          format: 'WAV'
        }
      },
      workflow: {
        backupEnabled: true,
        versionControl: false,
        collaborationMode: false,
        autoSave: true,
        notifications: true
      }
    }
  };
};
