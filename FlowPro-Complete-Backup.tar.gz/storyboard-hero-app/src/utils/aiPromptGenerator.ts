import { 
  TechnicalPromptBuilder, 
  AIServiceType, 
  CameraSpecifications, 
  LightingSpecifications,
  DetailedVisualStyle,
  LocationSpecifications,
  CharacterSpecifications
} from '../types';

export class AIPromptGenerator {
  /**
   * Generate comprehensive technical prompt for AI image generation
   */
  static generateTechnicalPrompt(builder: TechnicalPromptBuilder, serviceType: AIServiceType): string {
    const {
      baseDescription,
      cameraSpecs,
      lightingSpecs,
      locationSpecs,
      characterSpecs,
      visualStyle,
      additionalNotes
    } = builder;

    let prompt = baseDescription;

    // Add character descriptions
    if (characterSpecs.length > 0) {
      const characterDescriptions = characterSpecs.map(char => 
        this.generateCharacterPrompt(char)
      ).join(', ');
      prompt += `, featuring ${characterDescriptions}`;
    }

    // Add location/setting details
    prompt += `, ${this.generateLocationPrompt(locationSpecs)}`;

    // Add camera technical details
    prompt += `, ${this.generateCameraPrompt(cameraSpecs, serviceType)}`;

    // Add lighting specifications
    prompt += `, ${this.generateLightingPrompt(lightingSpecs, serviceType)}`;

    // Add visual style
    prompt += `, ${this.generateStylePrompt(visualStyle, serviceType)}`;

    // Add service-specific optimizations
    prompt = this.optimizeForService(prompt, serviceType);

    // Add additional notes if provided
    if (additionalNotes) {
      prompt += `, ${additionalNotes}`;
    }

    // Final service-specific formatting
    return this.formatForService(prompt, serviceType);
  }

  /**
   * Generate camera-specific prompt section
   */
  static generateCameraPrompt(specs: CameraSpecifications, serviceType: AIServiceType): string {
    const parts = [];

    // Camera angle and shot type
    parts.push(`${specs.distance} ${specs.cameraType.toLowerCase()}`);
    
    // Lens information
    if (specs.lens) {
      parts.push(`shot with ${specs.lens}`);
    }

    // Technical camera settings
    if (specs.aperture) {
      parts.push(`aperture ${specs.aperture}`);
    }

    if (specs.focalLength) {
      parts.push(`${specs.focalLength} focal length`);
    }

    // Camera movement
    if (specs.movement !== 'static') {
      parts.push(`${specs.movement} camera movement`);
    }

    // Camera height and angle
    if (specs.height !== 'eye level') {
      parts.push(`${specs.height} angle`);
    }

    // Mount type for specific look
    if (specs.mountType && specs.mountType !== 'tripod') {
      parts.push(`${specs.mountType} stabilization`);
    }

    // Filters for specific effects
    if (specs.filterUsed) {
      parts.push(`${specs.filterUsed} effect`);
    }

    // Service-specific camera terms
    if (serviceType === 'midjourney') {
      parts.push('professional cinematography');
    } else if (serviceType === 'openart') {
      parts.push('high-end camera equipment');
    }

    return parts.join(', ');
  }

  /**
   * Generate lighting-specific prompt section
   */
  static generateLightingPrompt(specs: LightingSpecifications, serviceType: AIServiceType): string {
    const parts = [];

    // Time of day and ambient lighting
    parts.push(`${specs.timeOfDay.replace('_', ' ')} lighting`);

    // Primary lighting setup
    if (specs.primaryLight) {
      parts.push(`${specs.primaryLight.type} as key light`);
      parts.push(`${specs.primaryLight.intensity} ${specs.primaryLight.direction} lighting`);
    }

    // Color temperature
    if (specs.colorTemperature) {
      parts.push(`${specs.colorTemperature} color temperature`);
    }

    // Lighting mood
    parts.push(`${specs.mood} lighting mood`);

    // Weather effects on lighting
    if (specs.weather && specs.weather !== 'clear') {
      parts.push(`${specs.weather} weather lighting conditions`);
    }

    // Fill and back lights
    if (specs.fillLight) {
      parts.push(`subtle fill lighting`);
    }

    if (specs.backLight) {
      parts.push(`rim lighting`);
    }

    // Practical lights in scene
    if (specs.practicalLights && specs.practicalLights.length > 0) {
      const practicals = specs.practicalLights.map(light => light.type).join(' and ');
      parts.push(`practical lighting from ${practicals}`);
    }

    // Service-specific lighting terms
    if (serviceType === 'midjourney') {
      parts.push('cinematic lighting');
    } else if (serviceType === 'openart') {
      parts.push('professional studio lighting');
    }

    return parts.join(', ');
  }

  /**
   * Generate location-specific prompt section
   */
  static generateLocationPrompt(specs: LocationSpecifications): string {
    const parts = [];

    // Main setting
    parts.push(`in a ${specs.setting}`);

    // Architecture style
    if (specs.architecture) {
      parts.push(`with ${specs.architecture} architecture`);
    }

    // Interior style
    if (specs.interiorStyle) {
      parts.push(`${specs.interiorStyle} interior design`);
    }

    // Materials and textures
    if (specs.materials.length > 0) {
      parts.push(`featuring ${specs.materials.join(', ')} materials`);
    }

    // Color palette
    if (specs.colors.length > 0) {
      parts.push(`with ${specs.colors.join(', ')} color scheme`);
    }

    // Textures
    if (specs.textures.length > 0) {
      parts.push(`${specs.textures.join(', ')} textures`);
    }

    // Props and set dressing
    if (specs.props && specs.props.length > 0) {
      parts.push(`including ${specs.props.join(', ')}`);
    }

    // Overall atmosphere
    parts.push(`${specs.atmosphere} atmosphere`);

    return parts.join(', ');
  }

  /**
   * Generate character-specific prompt section
   */
  static generateCharacterPrompt(specs: CharacterSpecifications): string {
    const parts = [];

    // Basic description
    parts.push(specs.description);

    // Wardrobe
    if (specs.wardrobe) {
      parts.push(`wearing ${specs.wardrobe.outfit}`);
      
      if (specs.wardrobe.colors.length > 0) {
        parts.push(`in ${specs.wardrobe.colors.join(' and ')}`);
      }

      if (specs.wardrobe.style) {
        parts.push(`${specs.wardrobe.style} style`);
      }

      if (specs.wardrobe.accessories && specs.wardrobe.accessories.length > 0) {
        parts.push(`with ${specs.wardrobe.accessories.join(', ')}`);
      }
    }

    // Pose and expression
    if (specs.pose) {
      parts.push(`in ${specs.pose} pose`);
    }

    if (specs.expression) {
      parts.push(`${specs.expression} expression`);
    }

    // Eye line direction
    if (specs.eyeline) {
      parts.push(`looking ${specs.eyeline}`);
    }

    // Position in frame
    if (specs.position) {
      parts.push(`positioned ${specs.position}`);
    }

    return parts.join(', ');
  }

  /**
   * Generate visual style prompt section
   */
  static generateStylePrompt(style: DetailedVisualStyle, serviceType: AIServiceType): string {
    const parts = [];

    // Overall mood
    parts.push(`${style.overallMood} mood`);

    // Color palette
    if (style.colorPalette.length > 0) {
      parts.push(`${style.colorPalette.join(', ')} color palette`);
    }

    // Visual references
    if (style.visualReferences && style.visualReferences.length > 0) {
      parts.push(`in the style of ${style.visualReferences.join(', ')}`);
    }

    // Color grading
    if (style.grading) {
      parts.push(`${style.grading.overall} color grading`);
      parts.push(`${style.grading.highlights} highlights`);
      parts.push(`${style.grading.shadows} shadows`);
    }

    // Composition
    if (style.composition) {
      if (style.composition.ruleOfThirds) {
        parts.push('rule of thirds composition');
      }
      
      if (style.composition.depth) {
        parts.push(`${style.composition.depth} depth of field`);
      }

      if (style.composition.symmetry) {
        parts.push(`${style.composition.symmetry} symmetry`);
      }
    }

    // Visual characteristics
    parts.push(`${style.contrast} contrast`);
    parts.push(`${style.saturation} saturation`);

    if (style.texture) {
      parts.push(`${style.texture} texture`);
    }

    return parts.join(', ');
  }

  /**
   * Optimize prompt for specific AI service
   */
  static optimizeForService(prompt: string, serviceType: AIServiceType): string {
    switch (serviceType) {
      case 'midjourney':
        return this.optimizeForMidjourney(prompt);
      case 'openart':
        return this.optimizeForOpenArt(prompt);
      case 'dalle':
        return this.optimizeForDALLE(prompt);
      case 'stable_diffusion':
        return this.optimizeForStableDiffusion(prompt);
      default:
        return prompt;
    }
  }

  /**
   * Midjourney-specific optimizations
   */
  private static optimizeForMidjourney(prompt: string): string {
    // Add Midjourney-specific quality and style parameters
    const mjOptimizations = [
      'hyperrealistic',
      'highly detailed',
      'professional photography',
      '8k resolution',
      'award-winning cinematography'
    ];

    return `${prompt}, ${mjOptimizations.join(', ')}`;
  }

  /**
   * OpenArt-specific optimizations
   */
  private static optimizeForOpenArt(prompt: string): string {
    const oaOptimizations = [
      'photorealistic',
      'studio quality',
      'professional lighting',
      'high resolution',
      'commercial photography'
    ];

    return `${prompt}, ${oaOptimizations.join(', ')}`;
  }

  /**
   * DALL-E-specific optimizations
   */
  private static optimizeForDALLE(prompt: string): string {
    // DALL-E responds well to clear, descriptive language
    return prompt.replace(/,\s+/g, ', ').trim();
  }

  /**
   * Stable Diffusion-specific optimizations
   */
  private static optimizeForStableDiffusion(prompt: string): string {
    const sdOptimizations = [
      'masterpiece',
      'best quality',
      'highly detailed',
      'professional',
      'realistic'
    ];

    return `${prompt}, ${sdOptimizations.join(', ')}`;
  }

  /**
   * Format prompt for specific service requirements
   */
  static formatForService(prompt: string, serviceType: AIServiceType): string {
    switch (serviceType) {
      case 'midjourney':
        // Midjourney prefers shorter, punchy prompts
        return this.condenseMidjourneyPrompt(prompt);
      case 'openart':
        // OpenArt handles longer, detailed prompts well
        return prompt;
      case 'dalle':
        // DALL-E has character limits
        return this.truncateForDALLE(prompt);
      default:
        return prompt;
    }
  }

  /**
   * Condense prompt for Midjourney's optimal length
   */
  private static condenseMidjourneyPrompt(prompt: string): string {
    // Remove redundant words and keep essential descriptors
    return prompt
      .replace(/\b(very|extremely|highly|really)\s+/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Truncate prompt for DALL-E's character limit
   */
  private static truncateForDALLE(prompt: string): string {
    const maxLength = 400; // DALL-E character limit
    if (prompt.length <= maxLength) return prompt;

    // Truncate at word boundary
    return prompt.substring(0, maxLength).replace(/\s+\S*$/, '') + '...';
  }

  /**
   * Generate negative prompt for services that support it
   */
  static generateNegativePrompt(serviceType: AIServiceType, customNegatives?: string[]): string {
    const commonNegatives = [
      'blurry',
      'low quality',
      'distorted',
      'artifacts',
      'pixelated',
      'amateur'
    ];

    const serviceNegatives = {
      stable_diffusion: [
        ...commonNegatives,
        'mutation',
        'deformed',
        'ugly',
        'bad anatomy'
      ],
      openart: [
        ...commonNegatives,
        'overexposed',
        'underexposed',
        'noise'
      ]
    };

    const negatives = serviceNegatives[serviceType as keyof typeof serviceNegatives] || commonNegatives;
    
    if (customNegatives) {
      negatives.push(...customNegatives);
    }

    return negatives.join(', ');
  }

  /**
   * Generate variations of a prompt for A/B testing
   */
  static generatePromptVariations(basePrompt: string, count: number = 3): string[] {
    const variations = [basePrompt];
    
    const styleVariations = [
      'cinematic',
      'documentary style',
      'commercial photography',
      'artistic composition',
      'editorial style'
    ];

    const qualityVariations = [
      'hyperrealistic, 8k',
      'photorealistic, studio quality',
      'professional photography',
      'award-winning composition',
      'masterpiece quality'
    ];

    for (let i = 1; i < count; i++) {
      const styleVar = styleVariations[i % styleVariations.length];
      const qualityVar = qualityVariations[i % qualityVariations.length];
      
      variations.push(`${basePrompt}, ${styleVar}, ${qualityVar}`);
    }

    return variations;
  }
}

export default AIPromptGenerator;
