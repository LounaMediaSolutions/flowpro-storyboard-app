import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'sonner';
import { ThemeProvider } from './components/theme/ThemeProvider';
import { AuthProvider, useAuth } from './components/auth/AuthProvider';
import LoginForm from './components/auth/LoginForm';
import MainLayout from './components/layout/MainLayout';
import Dashboard from './components/dashboard/Dashboard';
import ProfessionalDashboard from './components/dashboard/ProfessionalDashboard';
import EpisodesManager from './components/episodes/EpisodesManager';
import ScriptEditor from './components/script/ScriptEditor';
import EnhancedScriptEditor from './components/script/EnhancedScriptEditor';
import ProfessionalScriptEditor from './components/script/ProfessionalScriptEditor';
import ScriptImporter from './components/script/ScriptImporter';
import StoryboardEditor from './components/storyboard/StoryboardEditor';
import ProductionManager from './components/production/ProductionManager';
import BudgetManager from './components/budget/BudgetManager';
import ExportPage from './components/export/ExportPage';
import ProductionReports from './components/reports/ProductionReports';
import UserManagement from './components/auth/UserManagement';
import AIServiceManager from './components/ai/AIServiceManager';
import EnhancedAIServiceManager from './components/ai/EnhancedAIServiceManager';
import SettingsPage from './components/settings/SettingsPage';
import { ErrorBoundary } from './components/ErrorBoundary';
import { useStoryboardStore } from './store/storyboardStore';
import './App.css';

// Main Application Component (wrapped with auth)
function AppContent() {
  const { user, loading } = useAuth();
  const currentView = useStoryboardStore(state => state.currentView);

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
        <div className="text-center">
          <img 
            src="/images/flowpro-logo.png" 
            alt="FlowPro" 
            className="h-16 mx-auto mb-4 animate-pulse"
          />
          <p className="text-muted-foreground">Loading FlowPro...</p>
        </div>
      </div>
    );
  }

  // Show login form if not authenticated
  if (!user) {
    return <LoginForm />;
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'dashboard':
        return <ProfessionalDashboard />;
      case 'episodes':
        return <EpisodesManager />;
      case 'script':
        return <ProfessionalScriptEditor />;
      case 'script-import':
        return <ScriptImporter />;
      case 'storyboard':
        return <StoryboardEditor />;
      case 'ai-services':
        return <EnhancedAIServiceManager />;
      case 'settings':
        return <SettingsPage />;
      case 'production':
        return <ProductionManager />;
      case 'budget':
        return <BudgetManager />;
      case 'reports':
        return <ProductionReports />;
      case 'users':
        return <UserManagement />;
      case 'export':
        return <ExportPage />;
      default:
        return <ProfessionalDashboard />;
    }
  };

  return (
    <Router>
      <div className="min-h-screen bg-background transition-colors duration-300">
        <MainLayout>
          {renderCurrentView()}
        </MainLayout>
        <Toaster position="top-right" richColors />
      </div>
    </Router>
  );
}

// Root App Component
function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="system" storageKey="flowpro-theme">
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
