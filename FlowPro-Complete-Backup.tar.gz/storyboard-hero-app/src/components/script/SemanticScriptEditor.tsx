import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '../ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Badge } from '../ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { ScrollArea } from '../ui/scroll-area';
import { Separator } from '../ui/separator';
import { 
  Film, FileText, Users, MapPin, Clock, Play, 
  Bold, Italic, Underline, Save, Download, Upload,
  Plus, Trash2, Eye, Settings, Palette, Moon, Sun
} from 'lucide-react';
import { toast } from 'sonner';

// Screenplay Element Types (exactly like Celtx/Final Draft)
export type ScriptElementType = 
  | 'scene_heading' 
  | 'action' 
  | 'character' 
  | 'dialogue' 
  | 'parenthetical' 
  | 'transition' 
  | 'shot' 
  | 'general';

export interface ScriptElement {
  id: string;
  type: ScriptElementType;
  content: string;
  characterName?: string;
  location?: string;
  timeOfDay?: string;
  isInterior?: boolean;
  formatting?: {
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
  };
}

export interface ScriptMetadata {
  title: string;
  characters: string[];
  locations: string[];
  scenes: number;
  pages: number;
  estimatedDuration: number;
}

interface SemanticScriptEditorProps {
  onScriptChange?: (elements: ScriptElement[], metadata: ScriptMetadata) => void;
  initialScript?: ScriptElement[];
}

const SemanticScriptEditor: React.FC<SemanticScriptEditorProps> = ({ 
  onScriptChange,
  initialScript = []
}) => {
  const [elements, setElements] = useState<ScriptElement[]>(initialScript);
  const [currentElementIndex, setCurrentElementIndex] = useState(0);
  const [currentElementType, setCurrentElementType] = useState<ScriptElementType>('action');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(true);
  const [metadata, setMetadata] = useState<ScriptMetadata>({
    title: 'Untitled Script',
    characters: [],
    locations: [],
    scenes: 0,
    pages: 1,
    estimatedDuration: 0
  });

  const editorRef = useRef<HTMLDivElement>(null);
  const currentInputRef = useRef<HTMLDivElement>(null);

  // Element formatting rules (like Celtx/Final Draft)
  const elementStyles = {
    scene_heading: 'font-bold uppercase text-left w-full',
    action: 'text-left w-full leading-relaxed',
    character: 'font-bold uppercase text-center w-full mt-4',
    dialogue: 'text-left mx-auto max-w-md leading-relaxed',
    parenthetical: 'text-left mx-auto max-w-sm italic text-muted-foreground',
    transition: 'font-bold uppercase text-right w-full mt-4',
    shot: 'font-bold uppercase text-left w-full',
    general: 'text-left w-full'
  };

  // Element suggestions (Element Assist feature like Celtx)
  const elementSuggestions = {
    scene_heading: {
      prefixes: ['INT.', 'EXT.', 'FADE IN:', 'FADE OUT:'],
      times: ['DAY', 'NIGHT', 'DAWN', 'DUSK', 'MORNING', 'AFTERNOON', 'EVENING', 'CONTINUOUS', 'LATER']
    },
    character: {
      extensions: ['(V.O.)', '(O.S.)', '(O.C.)', '(CONT\'D)']
    },
    transition: ['CUT TO:', 'FADE TO:', 'DISSOLVE TO:', 'SMASH CUT:', 'MATCH CUT:', 'JUMP CUT:']
  };

  // Intelligent element prediction (like Celtx)
  const predictNextElement = useCallback((currentType: ScriptElementType, content: string): ScriptElementType => {
    switch (currentType) {
      case 'scene_heading':
        return 'action';
      case 'action':
        // If content looks like a character name (ALL CAPS)
        if (/^[A-Z\s]{2,}$/.test(content.trim())) {
          return 'character';
        }
        return 'action';
      case 'character':
        return 'dialogue';
      case 'dialogue':
        return 'character'; // Could be another character or action
      case 'parenthetical':
        return 'dialogue';
      default:
        return 'action';
    }
  }, []);

  // Auto-complete suggestions
  const getSuggestions = useCallback((type: ScriptElementType, content: string): string[] => {
    switch (type) {
      case 'scene_heading':
        if (content.length < 4) {
          return elementSuggestions.scene_heading.prefixes.filter(p => 
            p.toLowerCase().startsWith(content.toLowerCase())
          );
        }
        if (content.includes(' - ')) {
          return elementSuggestions.scene_heading.times.filter(t => 
            t.toLowerCase().startsWith(content.split(' - ')[1]?.toLowerCase() || '')
          );
        }
        return [];
      case 'character':
        if (content.includes('(')) {
          return elementSuggestions.character.extensions.filter(e => 
            e.toLowerCase().startsWith(`(${content.split('(')[1]?.toLowerCase() || ''}`)
          );
        }
        return metadata.characters.filter(c => 
          c.toLowerCase().startsWith(content.toLowerCase())
        );
      case 'transition':
        return elementSuggestions.transition.filter(t => 
          t.toLowerCase().startsWith(content.toLowerCase())
        );
      default:
        return [];
    }
  }, [metadata.characters]);

  // Add new element
  const addElement = useCallback((type: ScriptElementType = 'action', content: string = '') => {
    const newElement: ScriptElement = {
      id: `element_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      content,
      formatting: {}
    };

    // Extract semantic information
    if (type === 'scene_heading') {
      const match = content.match(/^(INT\.|EXT\.)\s*(.+?)\s*-\s*(.+)$/i);
      if (match) {
        newElement.isInterior = match[1].toUpperCase().includes('INT');
        newElement.location = match[2].trim();
        newElement.timeOfDay = match[3].trim();
      }
    } else if (type === 'character') {
      newElement.characterName = content.replace(/\s*\([^)]*\)$/, '').trim();
    }

    setElements(prev => [...prev, newElement]);
    setCurrentElementIndex(elements.length);
    
    // Update metadata
    updateMetadata([...elements, newElement]);
    
    return newElement;
  }, [elements]);

  // Update metadata from elements
  const updateMetadata = useCallback((elementList: ScriptElement[]) => {
    const characters = new Set<string>();
    const locations = new Set<string>();
    let scenes = 0;

    elementList.forEach(element => {
      if (element.type === 'scene_heading') {
        scenes++;
        if (element.location) locations.add(element.location);
      } else if (element.type === 'character' && element.characterName) {
        characters.add(element.characterName);
      }
    });

    // Estimate pages (roughly 1 page per minute, 250 words per page)
    const wordCount = elementList.reduce((count, el) => count + el.content.split(' ').length, 0);
    const pages = Math.max(1, Math.ceil(wordCount / 250));
    const estimatedDuration = pages; // 1 page ≈ 1 minute

    const newMetadata: ScriptMetadata = {
      title: metadata.title,
      characters: Array.from(characters),
      locations: Array.from(locations),
      scenes,
      pages,
      estimatedDuration
    };

    setMetadata(newMetadata);
    
    if (onScriptChange) {
      onScriptChange(elementList, newMetadata);
    }
  }, [metadata.title, onScriptChange]);

  // Handle keyboard shortcuts and Tab switching
  const handleKeyDown = useCallback((e: React.KeyboardEvent, elementIndex: number) => {
    const element = elements[elementIndex];
    
    if (e.key === 'Tab') {
      e.preventDefault();
      // Cycle through element types
      const types: ScriptElementType[] = ['scene_heading', 'action', 'character', 'dialogue', 'parenthetical', 'transition'];
      const currentIndex = types.indexOf(element.type);
      const nextType = types[(currentIndex + 1) % types.length];
      
      updateElement(elementIndex, { type: nextType });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      // Create new element based on prediction
      const nextType = predictNextElement(element.type, element.content);
      addElement(nextType);
    } else if (e.ctrlKey || e.metaKey) {
      // Shortcuts like Final Draft
      switch (e.key) {
        case '1':
          e.preventDefault();
          updateElement(elementIndex, { type: 'scene_heading' });
          break;
        case '2':
          e.preventDefault();
          updateElement(elementIndex, { type: 'action' });
          break;
        case '3':
          e.preventDefault();
          updateElement(elementIndex, { type: 'character' });
          break;
        case '5':
          e.preventDefault();
          updateElement(elementIndex, { type: 'dialogue' });
          break;
        case 'b':
          e.preventDefault();
          toggleFormatting(elementIndex, 'bold');
          break;
        case 'i':
          e.preventDefault();
          toggleFormatting(elementIndex, 'italic');
          break;
        case 'u':
          e.preventDefault();
          toggleFormatting(elementIndex, 'underline');
          break;
      }
    }
  }, [elements, predictNextElement, addElement]);

  // Update element
  const updateElement = useCallback((index: number, updates: Partial<ScriptElement>) => {
    setElements(prev => {
      const newElements = [...prev];
      newElements[index] = { ...newElements[index], ...updates };
      updateMetadata(newElements);
      return newElements;
    });
  }, [updateMetadata]);

  // Toggle formatting
  const toggleFormatting = useCallback((index: number, format: 'bold' | 'italic' | 'underline') => {
    updateElement(index, {
      formatting: {
        ...elements[index].formatting,
        [format]: !elements[index].formatting?.[format]
      }
    });
  }, [elements, updateElement]);

  // Delete element
  const deleteElement = useCallback((index: number) => {
    if (elements.length > 1) {
      setElements(prev => {
        const newElements = prev.filter((_, i) => i !== index);
        updateMetadata(newElements);
        return newElements;
      });
      setCurrentElementIndex(Math.max(0, index - 1));
    }
  }, [elements.length, updateMetadata]);

  return (
    <div className={`h-full flex flex-col ${isDarkMode ? 'dark' : ''}`}>
      {/* Toolbar */}
      <div className="flex items-center justify-between p-4 border-b bg-background">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Film className="h-5 w-5" />
            {metadata.title}
          </h2>
          <Badge variant="outline">{metadata.pages} pages</Badge>
          <Badge variant="outline">{metadata.estimatedDuration}min</Badge>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Element Type Selector */}
          <Select 
            value={currentElementType} 
            onValueChange={(value: ScriptElementType) => setCurrentElementType(value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="scene_heading">Scene Heading</SelectItem>
              <SelectItem value="action">Action</SelectItem>
              <SelectItem value="character">Character</SelectItem>
              <SelectItem value="dialogue">Dialogue</SelectItem>
              <SelectItem value="parenthetical">Parenthetical</SelectItem>
              <SelectItem value="transition">Transition</SelectItem>
              <SelectItem value="shot">Shot</SelectItem>
            </SelectContent>
          </Select>

          {/* Formatting Tools */}
          <div className="flex border rounded">
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => toggleFormatting(currentElementIndex, 'bold')}
            >
              <Bold className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => toggleFormatting(currentElementIndex, 'italic')}
            >
              <Italic className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => toggleFormatting(currentElementIndex, 'underline')}
            >
              <Underline className="h-4 w-4" />
            </Button>
          </div>

          <Separator orientation="vertical" className="h-6" />

          {/* View Controls */}
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowBreakdown(!showBreakdown)}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setIsDarkMode(!isDarkMode)}
          >
            {isDarkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>

          <Separator orientation="vertical" className="h-6" />

          {/* File Operations */}
          <Button variant="ghost" size="sm">
            <Upload className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Save className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Download className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Main Script Editor */}
        <div className="flex-1 flex flex-col">
          <ScrollArea className="flex-1 p-8">
            <div 
              ref={editorRef}
              className="max-w-4xl mx-auto bg-white dark:bg-gray-900 min-h-[11in] p-16 shadow-lg"
              style={{ 
                fontFamily: 'Courier New, monospace',
                fontSize: '12pt',
                lineHeight: '1.2',
                width: '8.5in'
              }}
            >
              {/* Script Title */}
              <div className="text-center mb-16">
                <h1 className="text-2xl font-bold uppercase">{metadata.title}</h1>
                <div className="text-sm text-muted-foreground mt-4">
                  Written by<br />
                  [Author Name]
                </div>
              </div>

              {/* Script Elements */}
              <div className="space-y-1">
                {elements.length === 0 && (
                  <div 
                    className="text-muted-foreground cursor-text p-2"
                    onClick={() => addElement('scene_heading', '')}
                  >
                    Click here to start writing your screenplay...
                  </div>
                )}
                
                {elements.map((element, index) => (
                  <ScriptElementEditor
                    key={element.id}
                    element={element}
                    index={index}
                    isActive={index === currentElementIndex}
                    onUpdate={(updates) => updateElement(index, updates)}
                    onDelete={() => deleteElement(index)}
                    onKeyDown={(e) => handleKeyDown(e, index)}
                    onFocus={() => setCurrentElementIndex(index)}
                    suggestions={getSuggestions(element.type, element.content)}
                    className={elementStyles[element.type]}
                  />
                ))}
              </div>

              {/* Add Element Button */}
              <div className="mt-8 text-center">
                <Button 
                  variant="ghost" 
                  onClick={() => addElement(currentElementType)}
                  className="text-muted-foreground"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add {currentElementType.replace('_', ' ')}
                </Button>
              </div>
            </div>
          </ScrollArea>

          {/* Status Bar */}
          <div className="border-t p-2 text-sm text-muted-foreground flex justify-between items-center">
            <div>
              Page {Math.ceil((currentElementIndex + 1) / 25)} of {metadata.pages}
            </div>
            <div className="flex space-x-4">
              <span>{elements.length} elements</span>
              <span>{metadata.scenes} scenes</span>
              <span>{metadata.characters.length} characters</span>
              <span>Last saved: just now</span>
            </div>
          </div>
        </div>

        {/* Breakdown Sidebar */}
        {showBreakdown && (
          <div className="w-80 border-l bg-muted/30">
            <div className="p-4">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Script Breakdown
              </h3>
              
              <div className="space-y-4">
                {/* Characters */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Characters ({metadata.characters.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1">
                    {metadata.characters.map(character => (
                      <Badge key={character} variant="secondary" className="text-xs">
                        {character}
                      </Badge>
                    ))}
                  </CardContent>
                </Card>

                {/* Locations */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      Locations ({metadata.locations.length})
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-1">
                    {metadata.locations.map(location => (
                      <Badge key={location} variant="outline" className="text-xs">
                        {location}
                      </Badge>
                    ))}
                  </CardContent>
                </Card>

                {/* Script Stats */}
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Pages:</span>
                      <span>{metadata.pages}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Scenes:</span>
                      <span>{metadata.scenes}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Est. Duration:</span>
                      <span>{metadata.estimatedDuration}min</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Individual Script Element Editor Component
interface ScriptElementEditorProps {
  element: ScriptElement;
  index: number;
  isActive: boolean;
  onUpdate: (updates: Partial<ScriptElement>) => void;
  onDelete: () => void;
  onKeyDown: (e: React.KeyboardEvent) => void;
  onFocus: () => void;
  suggestions: string[];
  className: string;
}

const ScriptElementEditor: React.FC<ScriptElementEditorProps> = ({
  element,
  index,
  isActive,
  onUpdate,
  onDelete,
  onKeyDown,
  onFocus,
  suggestions,
  className
}) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLDivElement>(null);

  const handleContentChange = (content: string) => {
    onUpdate({ content });
    setShowSuggestions(suggestions.length > 0 && content.length > 0);
  };

  const applySuggestion = (suggestion: string) => {
    onUpdate({ content: suggestion });
    setShowSuggestions(false);
    inputRef.current?.focus();
  };

  const getPlaceholder = () => {
    switch (element.type) {
      case 'scene_heading':
        return 'INT./EXT. LOCATION - TIME';
      case 'action':
        return 'Describe what happens...';
      case 'character':
        return 'CHARACTER NAME';
      case 'dialogue':
        return 'What the character says...';
      case 'parenthetical':
        return '(how it\'s said)';
      case 'transition':
        return 'CUT TO:';
      default:
        return 'Type here...';
    }
  };

  const formatStyle = {
    fontWeight: element.formatting?.bold ? 'bold' : 'normal',
    fontStyle: element.formatting?.italic ? 'italic' : 'normal',
    textDecoration: element.formatting?.underline ? 'underline' : 'none'
  };

  return (
    <div className="relative group">
      {/* Element Type Indicator */}
      {isActive && (
        <div className="absolute -left-24 top-0 text-xs text-muted-foreground uppercase">
          {element.type.replace('_', ' ')}
        </div>
      )}

      {/* Main Input */}
      <div
        ref={inputRef}
        contentEditable
        className={`
          ${className} 
          min-h-[1.5em] p-1 rounded outline-none focus:bg-blue-50 dark:focus:bg-blue-950/30
          ${isActive ? 'ring-2 ring-blue-500' : ''}
          ${!element.content ? 'text-muted-foreground' : ''}
        `}
        style={formatStyle}
        onInput={(e) => handleContentChange(e.currentTarget.textContent || '')}
        onKeyDown={onKeyDown}
        onFocus={onFocus}
        suppressContentEditableWarning={true}
      >
        {element.content || getPlaceholder()}
      </div>

      {/* Suggestions Dropdown */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 z-50 bg-white dark:bg-gray-800 border rounded-md shadow-lg max-w-xs">
          {suggestions.slice(0, 5).map((suggestion, i) => (
            <div
              key={i}
              className="px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
              onClick={() => applySuggestion(suggestion)}
            >
              {suggestion}
            </div>
          ))}
        </div>
      )}

      {/* Delete Button */}
      {isActive && (
        <Button
          variant="ghost"
          size="sm"
          className="absolute -right-8 top-0 opacity-0 group-hover:opacity-100"
          onClick={onDelete}
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      )}
    </div>
  );
};

export default SemanticScriptEditor;
