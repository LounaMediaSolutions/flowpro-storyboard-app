import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Wand2, Plus, Upload, FileText, Loader2, Edit3, Trash2, 
  Film, Users, MapPin, Clock, Download, Share, Settings, Eye,
  Bold, Italic, Underline, Play, Camera, Mic, Lightbulb, Palette,
  Save, Import, Type, PlusCircle, MinusCircle
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Textarea } from '../ui/textarea';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { useStoryboardStore } from '../../store/storyboardStore';
import { toast } from 'sonner';

// Professional Screenplay Element Types (like Celtx/Final Draft)
export type ScriptElementType = 
  | 'scene_heading' 
  | 'action' 
  | 'character' 
  | 'dialogue' 
  | 'parenthetical' 
  | 'transition' 
  | 'shot' 
  | 'general';

export interface ScriptElement {
  id: string;
  type: ScriptElementType;
  content: string;
  characterName?: string;
  location?: string;
  timeOfDay?: string;
  isInterior?: boolean;
  shotDetails?: ShotDetails;
  formatting?: {
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
  };
}

export interface ShotDetails {
  shotType?: 'wide_shot' | 'medium_shot' | 'close_up' | 'extreme_close_up' | 'over_shoulder' | 'two_shot';
  movement?: 'static' | 'pan_left' | 'pan_right' | 'tilt_up' | 'tilt_down' | 'zoom_in' | 'zoom_out' | 'dolly_in' | 'dolly_out' | 'tracking';
  perspective?: 'eye_level' | 'high_angle' | 'low_angle' | 'birds_eye' | 'worms_eye';
  focus?: 'shallow_focus' | 'deep_focus' | 'rack_focus';
  lighting?: 'soft_light' | 'hard_light' | 'backlight' | 'side_light' | 'key_light' | 'fill_light';
  focalLength?: '14mm' | '24mm' | '35mm' | '50mm' | '85mm' | '135mm' | '200mm';
  characters?: string[];
  costumes?: string;
  accessories?: string[];
  voiceOver?: {
    needed: boolean;
    text?: string;
    gender?: 'male' | 'female';
    language?: string;
    style?: 'tense' | 'calm' | 'dramatic' | 'narrative';
  };
  musicCue?: string;
  equipment?: {
    camera?: string;
    audio?: string;
    lighting?: string;
    props?: string[];
  };
}

interface ScriptMetadata {
  title: string;
  characters: string[];
  locations: string[];
  scenes: number;
  pages: number;
  estimatedDuration: number;
  shotTypes: Record<string, number>;
}

const EnhancedScriptEditor: React.FC = () => {
  const {
    currentProject,
    currentEpisode,
    isGenerating,
    generateScript,
    addScene,
    updateScene,
    deleteScene,
    setCurrentView
  } = useStoryboardStore();

  const [elements, setElements] = useState<ScriptElement[]>([]);
  const [currentElementIndex, setCurrentElementIndex] = useState(0);
  const [currentElementType, setCurrentElementType] = useState<ScriptElementType>('action');
  const [showBreakdown, setShowBreakdown] = useState(true);
  const [showShotDetails, setShowShotDetails] = useState(false);
  const [isSemanticMode, setIsSemanticMode] = useState(true);
  const [scriptBrief, setScriptBrief] = useState('');
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [metadata, setMetadata] = useState<ScriptMetadata>({
    title: currentProject?.title || 'Untitled Script',
    characters: [],
    locations: [],
    scenes: 0,
    pages: 1,
    estimatedDuration: 0,
    shotTypes: {}
  });

  const editorRef = useRef<HTMLDivElement>(null);

  // Element formatting rules (like Celtx/Final Draft)
  const elementStyles = {
    scene_heading: 'font-bold uppercase text-left w-full text-sm leading-relaxed',
    action: 'text-left w-full leading-relaxed text-sm',
    character: 'font-bold uppercase text-center w-full mt-3 text-sm',
    dialogue: 'text-left mx-auto max-w-md leading-relaxed text-sm px-16',
    parenthetical: 'text-left mx-auto max-w-sm italic text-muted-foreground text-sm px-20',
    transition: 'font-bold uppercase text-right w-full mt-3 text-sm',
    shot: 'font-bold uppercase text-left w-full text-sm',
    general: 'text-left w-full text-sm'
  };

  // Element suggestions (Element Assist feature like Celtx)
  const elementSuggestions = {
    scene_heading: {
      prefixes: ['INT.', 'EXT.', 'FADE IN:', 'FADE OUT:'],
      times: ['DAY', 'NIGHT', 'DAWN', 'DUSK', 'MORNING', 'AFTERNOON', 'EVENING', 'CONTINUOUS', 'LATER']
    },
    character: {
      extensions: ['(V.O.)', '(O.S.)', '(O.C.)', '(CONT\'D)']
    },
    transition: ['CUT TO:', 'FADE TO:', 'DISSOLVE TO:', 'SMASH CUT:', 'MATCH CUT:', 'JUMP CUT:']
  };

  // Intelligent element prediction (like Celtx)
  const predictNextElement = useCallback((currentType: ScriptElementType, content: string): ScriptElementType => {
    switch (currentType) {
      case 'scene_heading':
        return 'action';
      case 'action':
        if (/^[A-Z\s]{2,}$/.test(content.trim()) && content.length < 30) {
          return 'character';
        }
        return 'action';
      case 'character':
        return 'dialogue';
      case 'dialogue':
        return 'character';
      case 'parenthetical':
        return 'dialogue';
      default:
        return 'action';
    }
  }, []);

  // Auto-complete suggestions
  const getSuggestions = useCallback((type: ScriptElementType, content: string): string[] => {
    switch (type) {
      case 'scene_heading':
        if (content.length < 4) {
          return elementSuggestions.scene_heading.prefixes.filter(p => 
            p.toLowerCase().startsWith(content.toLowerCase())
          );
        }
        if (content.includes(' - ')) {
          return elementSuggestions.scene_heading.times.filter(t => 
            t.toLowerCase().startsWith(content.split(' - ')[1]?.toLowerCase() || '')
          );
        }
        return [];
      case 'character':
        if (content.includes('(')) {
          return elementSuggestions.character.extensions.filter(e => 
            e.toLowerCase().startsWith(`(${content.split('(')[1]?.toLowerCase() || ''}`)
          );
        }
        return metadata.characters.filter(c => 
          c.toLowerCase().startsWith(content.toLowerCase())
        );
      case 'transition':
        return elementSuggestions.transition.filter(t => 
          t.toLowerCase().startsWith(content.toLowerCase())
        );
      default:
        return [];
    }
  }, [metadata.characters]);

  // Add new element
  const addElement = useCallback((type: ScriptElementType = 'action', content: string = '') => {
    const newElement: ScriptElement = {
      id: `element_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      content,
      formatting: {},
      shotDetails: type === 'shot' ? {
        shotType: 'medium_shot',
        movement: 'static',
        perspective: 'eye_level',
        focus: 'shallow_focus',
        lighting: 'soft_light',
        focalLength: '50mm',
        characters: [],
        accessories: [],
        voiceOver: { needed: false }
      } : undefined
    };

    // Extract semantic information
    if (type === 'scene_heading') {
      const match = content.match(/^(INT\.|EXT\.)\s*(.+?)\s*-\s*(.+)$/i);
      if (match) {
        newElement.isInterior = match[1].toUpperCase().includes('INT');
        newElement.location = match[2].trim();
        newElement.timeOfDay = match[3].trim();
      }
    } else if (type === 'character') {
      newElement.characterName = content.replace(/\s*\([^)]*\)$/, '').trim();
    }

    setElements(prev => [...prev, newElement]);
    setCurrentElementIndex(elements.length);
    
    // Update metadata
    updateMetadata([...elements, newElement]);
    
    return newElement;
  }, [elements]);

  // Update metadata from elements
  const updateMetadata = useCallback((elementList: ScriptElement[]) => {
    const characters = new Set<string>();
    const locations = new Set<string>();
    const shotTypes: Record<string, number> = {};
    let scenes = 0;

    elementList.forEach(element => {
      if (element.type === 'scene_heading') {
        scenes++;
        if (element.location) locations.add(element.location);
      } else if (element.type === 'character' && element.characterName) {
        characters.add(element.characterName);
      } else if (element.type === 'shot' && element.shotDetails?.shotType) {
        shotTypes[element.shotDetails.shotType] = (shotTypes[element.shotDetails.shotType] || 0) + 1;
      }
    });

    // Estimate pages (roughly 1 page per minute, 250 words per page)
    const wordCount = elementList.reduce((count, el) => count + el.content.split(' ').length, 0);
    const pages = Math.max(1, Math.ceil(wordCount / 250));
    const estimatedDuration = pages; // 1 page ≈ 1 minute

    setMetadata({
      title: currentProject?.title || 'Untitled Script',
      characters: Array.from(characters),
      locations: Array.from(locations),
      scenes,
      pages,
      estimatedDuration,
      shotTypes
    });
  }, [currentProject?.title]);

  // Handle AI script generation
  const handleGenerateScript = async () => {
    if (!scriptBrief.trim()) {
      toast.error('Please enter a script brief');
      return;
    }

    try {
      if (currentProject && currentEpisode) {
        await generateScript(currentEpisode.id, scriptBrief);
        
        // Convert generated scenes to script elements
        if (currentEpisode.scenes.length > 0) {
          const newElements: ScriptElement[] = [];
          
          currentEpisode.scenes.forEach((scene, sceneIndex) => {
            // Add scene heading
            newElements.push({
              id: `scene_${scene.id}`,
              type: 'scene_heading',
              content: `${scene.location ? `INT. ${scene.location.toUpperCase()}` : 'INT. UNKNOWN LOCATION'} - ${scene.timeOfDay?.toUpperCase() || 'DAY'}`,
              location: scene.location,
              timeOfDay: scene.timeOfDay,
              isInterior: true
            });

            // Add scene description
            newElements.push({
              id: `action_${scene.id}`,
              type: 'action',
              content: scene.description || 'Scene description...'
            });

            // Add shots as dialogue/action elements
            scene.shots.forEach((shot, shotIndex) => {
              newElements.push({
                id: `shot_${shot.id}`,
                type: 'shot',
                content: `SHOT ${shotIndex + 1}: ${shot.description}`,
                shotDetails: {
                  shotType: shot.cameraAngle as any,
                  movement: shot.cameraMovement as any,
                  characters: shot.characters || [],
                  voiceOver: shot.voiceOver ? {
                    needed: true,
                    text: shot.voiceOver
                  } : { needed: false }
                }
              });
            });
          });

          setElements(newElements);
          updateMetadata(newElements);
        }

        setIsGenerateDialogOpen(false);
        setScriptBrief('');
        toast.success('Script generated successfully!');
      }
    } catch (error) {
      toast.error('Failed to generate script');
    }
  };

  // File upload handler
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      // Parse uploaded script based on file type
      parseUploadedScript(content, file.name);
    };
    reader.readAsText(file);
  }, []);

  // Parse uploaded script
  const parseUploadedScript = useCallback((content: string, filename: string) => {
    const lines = content.split('\n').filter(line => line.trim());
    const newElements: ScriptElement[] = [];

    lines.forEach((line, index) => {
      const trimmedLine = line.trim();
      if (!trimmedLine) return;

      let elementType: ScriptElementType = 'action';
      
      // Detect element type based on formatting
      if (/^(INT\.|EXT\.)/.test(trimmedLine.toUpperCase())) {
        elementType = 'scene_heading';
      } else if (/^[A-Z\s]{2,}(\s*\([^)]*\))?$/.test(trimmedLine) && trimmedLine.length < 30) {
        elementType = 'character';
      } else if (/^\([^)]+\)$/.test(trimmedLine)) {
        elementType = 'parenthetical';
      } else if (/^(CUT TO:|FADE TO:|DISSOLVE TO:)/.test(trimmedLine.toUpperCase())) {
        elementType = 'transition';
      }

      const element: ScriptElement = {
        id: `imported_${index}_${Date.now()}`,
        type: elementType,
        content: trimmedLine
      };

      // Extract semantic data
      if (elementType === 'scene_heading') {
        const match = trimmedLine.match(/^(INT\.|EXT\.)\s*(.+?)\s*-\s*(.+)$/i);
        if (match) {
          element.isInterior = match[1].toUpperCase().includes('INT');
          element.location = match[2].trim();
          element.timeOfDay = match[3].trim();
        }
      } else if (elementType === 'character') {
        element.characterName = trimmedLine.replace(/\s*\([^)]*\)$/, '').trim();
      }

      newElements.push(element);
    });

    setElements(newElements);
    updateMetadata(newElements);
    toast.success(`Script imported from ${filename}`);
  }, []);

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <FileText className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-600">No Project Selected</h3>
            <p className="text-gray-500">Please select a project to start writing your script.</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Enhanced Toolbar */}
      <div className="flex items-center justify-between p-4 border-b bg-background">
        <div className="flex items-center space-x-4">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Film className="h-5 w-5" />
            {metadata.title}
          </h2>
          <Badge variant="outline">{metadata.pages} pages</Badge>
          <Badge variant="outline">{metadata.estimatedDuration}min</Badge>
          <Badge variant="outline">{metadata.scenes} scenes</Badge>
          <Badge variant="outline">{metadata.characters.length} characters</Badge>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Mode Toggle */}
          <Button
            variant={isSemanticMode ? 'default' : 'outline'}
            size="sm"
            onClick={() => setIsSemanticMode(!isSemanticMode)}
          >
            <Type className="h-4 w-4 mr-1" />
            {isSemanticMode ? 'Semantic' : 'Traditional'}
          </Button>

          {/* Element Type Selector */}
          {isSemanticMode && (
            <Select 
              value={currentElementType} 
              onValueChange={(value: ScriptElementType) => setCurrentElementType(value)}
            >
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="scene_heading">Scene Heading</SelectItem>
                <SelectItem value="action">Action</SelectItem>
                <SelectItem value="character">Character</SelectItem>
                <SelectItem value="dialogue">Dialogue</SelectItem>
                <SelectItem value="parenthetical">Parenthetical</SelectItem>
                <SelectItem value="transition">Transition</SelectItem>
                <SelectItem value="shot">Shot</SelectItem>
              </SelectContent>
            </Select>
          )}

          <Separator orientation="vertical" className="h-6" />

          {/* File Operations */}
          <input
            type="file"
            id="script-upload"
            accept=".fdx,.celtx,.pdf,.docx,.txt"
            onChange={handleFileUpload}
            style={{ display: 'none' }}
          />
          <Button variant="ghost" size="sm" onClick={() => document.getElementById('script-upload')?.click()}>
            <Upload className="h-4 w-4" />
          </Button>

          {/* AI Generate */}
          <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm">
                <Wand2 className="h-4 w-4 mr-1" />
                AI Generate
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Generate Script with AI</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="script-brief">Script Brief</Label>
                  <Textarea
                    id="script-brief"
                    value={scriptBrief}
                    onChange={(e) => setScriptBrief(e.target.value)}
                    placeholder="Describe what you want to happen in this script..."
                    rows={6}
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsGenerateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleGenerateScript} disabled={isGenerating}>
                    {isGenerating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Generate Script
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* View Controls */}
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowBreakdown(!showBreakdown)}
          >
            <Eye className="h-4 w-4" />
          </Button>
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => setShowShotDetails(!showShotDetails)}
          >
            <Camera className="h-4 w-4" />
          </Button>

          <Separator orientation="vertical" className="h-6" />

          <Button variant="ghost" size="sm">
            <Save className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Download className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Share className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Main Script Editor */}
        <div className="flex-1 flex flex-col">
          {isSemanticMode ? (
            <SemanticScriptView 
              elements={elements}
              onElementsChange={setElements}
              metadata={metadata}
              onAddElement={addElement}
              currentElementType={currentElementType}
              elementStyles={elementStyles}
              getSuggestions={getSuggestions}
              predictNextElement={predictNextElement}
            />
          ) : (
            <TraditionalScriptView />
          )}

          {/* Status Bar */}
          <div className="border-t p-2 text-sm text-muted-foreground flex justify-between items-center">
            <div>
              Page 1 of {metadata.pages}
            </div>
            <div className="flex space-x-4">
              <span>{elements.length} elements</span>
              <span>{metadata.scenes} scenes</span>
              <span>{metadata.characters.length} characters</span>
              <span>Last saved: just now</span>
            </div>
          </div>
        </div>

        {/* Enhanced Sidebar */}
        {(showBreakdown || showShotDetails) && (
          <div className="w-80 border-l bg-muted/30">
            <Tabs defaultValue="breakdown" className="h-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="breakdown">Breakdown</TabsTrigger>
                <TabsTrigger value="shots">Shot Details</TabsTrigger>
              </TabsList>
              
              <TabsContent value="breakdown" className="p-4 space-y-4">
                <ScriptBreakdown metadata={metadata} elements={elements} />
              </TabsContent>
              
              <TabsContent value="shots" className="p-4 space-y-4">
                <ShotDetailsPanel elements={elements} onElementsChange={setElements} />
              </TabsContent>
            </Tabs>
          </div>
        )}
      </div>
    </div>
  );
};

// Components for different views and panels
const SemanticScriptView: React.FC<{
  elements: ScriptElement[];
  onElementsChange: (elements: ScriptElement[]) => void;
  metadata: ScriptMetadata;
  onAddElement: (type: ScriptElementType, content?: string) => ScriptElement;
  currentElementType: ScriptElementType;
  elementStyles: Record<ScriptElementType, string>;
  getSuggestions: (type: ScriptElementType, content: string) => string[];
  predictNextElement: (currentType: ScriptElementType, content: string) => ScriptElementType;
}> = ({ 
  elements, 
  onElementsChange, 
  metadata, 
  onAddElement, 
  currentElementType, 
  elementStyles,
  getSuggestions,
  predictNextElement 
}) => {
  return (
    <ScrollArea className="flex-1 p-8">
      <div 
        className="max-w-4xl mx-auto bg-white dark:bg-gray-900 min-h-[11in] p-16 shadow-lg"
        style={{ 
          fontFamily: 'Courier New, monospace',
          fontSize: '12pt',
          lineHeight: '1.2',
          width: '8.5in'
        }}
      >
        {/* Script Title */}
        <div className="text-center mb-16">
          <h1 className="text-2xl font-bold uppercase">{metadata.title}</h1>
          <div className="text-sm text-muted-foreground mt-4">
            Written by<br />
            MiniMax Agent
          </div>
        </div>

        {/* Script Elements */}
        <div className="space-y-1">
          {elements.length === 0 && (
            <div 
              className="text-muted-foreground cursor-text p-2"
              onClick={() => onAddElement('scene_heading', '')}
            >
              Click here to start writing your screenplay...
            </div>
          )}
          
          {elements.map((element, index) => (
            <ScriptElementRow
              key={element.id}
              element={element}
              index={index}
              style={elementStyles[element.type]}
              getSuggestions={getSuggestions}
              predictNextElement={predictNextElement}
              onUpdate={(updates) => {
                const newElements = [...elements];
                newElements[index] = { ...newElements[index], ...updates };
                onElementsChange(newElements);
              }}
              onDelete={() => {
                const newElements = elements.filter((_, i) => i !== index);
                onElementsChange(newElements);
              }}
              onAddNext={(type) => onAddElement(type)}
            />
          ))}
        </div>

        {/* Add Element Button */}
        <div className="mt-8 text-center">
          <Button 
            variant="ghost" 
            onClick={() => onAddElement(currentElementType)}
            className="text-muted-foreground"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add {currentElementType.replace('_', ' ')}
          </Button>
        </div>
      </div>
    </ScrollArea>
  );
};

const TraditionalScriptView: React.FC = () => {
  const [scriptText, setScriptText] = useState('');

  return (
    <div className="flex-1 p-4">
      <Textarea
        value={scriptText}
        onChange={(e) => setScriptText(e.target.value)}
        placeholder="Start writing your script here..."
        className="w-full h-full resize-none font-mono text-sm"
        style={{ fontFamily: 'Courier New, monospace' }}
      />
    </div>
  );
};

const ScriptElementRow: React.FC<{
  element: ScriptElement;
  index: number;
  style: string;
  getSuggestions: (type: ScriptElementType, content: string) => string[];
  predictNextElement: (currentType: ScriptElementType, content: string) => ScriptElementType;
  onUpdate: (updates: Partial<ScriptElement>) => void;
  onDelete: () => void;
  onAddNext: (type: ScriptElementType) => void;
}> = ({ 
  element, 
  index, 
  style, 
  getSuggestions, 
  predictNextElement, 
  onUpdate, 
  onDelete, 
  onAddNext 
}) => {
  const [content, setContent] = useState(element.content);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isActive, setIsActive] = useState(false);

  const suggestions = getSuggestions(element.type, content);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const nextType = predictNextElement(element.type, content);
      onAddNext(nextType);
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Cycle element type
      const types: ScriptElementType[] = ['scene_heading', 'action', 'character', 'dialogue', 'parenthetical', 'transition'];
      const currentIndex = types.indexOf(element.type);
      const nextType = types[(currentIndex + 1) % types.length];
      onUpdate({ type: nextType });
    }
  };

  const handleContentChange = (newContent: string) => {
    setContent(newContent);
    onUpdate({ content: newContent });
    setShowSuggestions(suggestions.length > 0 && newContent.length > 0);
  };

  return (
    <div className="relative group">
      {isActive && (
        <div className="absolute -left-24 top-0 text-xs text-muted-foreground uppercase">
          {element.type.replace('_', ' ')}
        </div>
      )}

      <div
        contentEditable
        className={`${style} min-h-[1.5em] p-1 rounded outline-none focus:bg-blue-50 dark:focus:bg-blue-950/30 ${isActive ? 'ring-2 ring-blue-500' : ''}`}
        onInput={(e) => handleContentChange(e.currentTarget.textContent || '')}
        onKeyDown={handleKeyDown}
        onFocus={() => setIsActive(true)}
        onBlur={() => setIsActive(false)}
        suppressContentEditableWarning={true}
      >
        {content}
      </div>

      {/* Suggestions */}
      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 z-50 bg-white dark:bg-gray-800 border rounded-md shadow-lg max-w-xs">
          {suggestions.slice(0, 5).map((suggestion, i) => (
            <div
              key={i}
              className="px-3 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 text-sm"
              onClick={() => {
                handleContentChange(suggestion);
                setShowSuggestions(false);
              }}
            >
              {suggestion}
            </div>
          ))}
        </div>
      )}

      {/* Delete Button */}
      {isActive && (
        <Button
          variant="ghost"
          size="sm"
          className="absolute -right-8 top-0 opacity-0 group-hover:opacity-100"
          onClick={onDelete}
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      )}
    </div>
  );
};

const ScriptBreakdown: React.FC<{ metadata: ScriptMetadata; elements: ScriptElement[] }> = ({ metadata, elements }) => {
  return (
    <div className="space-y-4">
      {/* Characters */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Users className="h-4 w-4" />
            Characters ({metadata.characters.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {metadata.characters.map(character => (
            <Badge key={character} variant="secondary" className="text-xs">
              {character}
            </Badge>
          ))}
        </CardContent>
      </Card>

      {/* Locations */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            Locations ({metadata.locations.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {metadata.locations.map(location => (
            <Badge key={location} variant="outline" className="text-xs">
              {location}
            </Badge>
          ))}
        </CardContent>
      </Card>

      {/* Shot Types */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Camera className="h-4 w-4" />
            Shot Types
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {Object.entries(metadata.shotTypes).map(([type, count]) => (
            <div key={type} className="flex justify-between">
              <span className="capitalize">{type.replace('_', ' ')}:</span>
              <span>{count}</span>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Statistics */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Clock className="h-4 w-4" />
            Statistics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span>Pages:</span>
            <span>{metadata.pages}</span>
          </div>
          <div className="flex justify-between">
            <span>Scenes:</span>
            <span>{metadata.scenes}</span>
          </div>
          <div className="flex justify-between">
            <span>Duration:</span>
            <span>{metadata.estimatedDuration}min</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const ShotDetailsPanel: React.FC<{
  elements: ScriptElement[];
  onElementsChange: (elements: ScriptElement[]) => void;
}> = ({ elements, onElementsChange }) => {
  const shotElements = elements.filter(el => el.type === 'shot');

  return (
    <div className="space-y-4">
      <h3 className="font-semibold text-sm">Shot Details</h3>
      {shotElements.length === 0 ? (
        <p className="text-sm text-muted-foreground">No shots defined yet</p>
      ) : (
        shotElements.map((element, index) => (
          <Card key={element.id}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Shot {index + 1}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Shot Type */}
              <div>
                <Label className="text-xs">Type</Label>
                <Select
                  value={element.shotDetails?.shotType}
                  onValueChange={(value) => {
                    const newElements = [...elements];
                    const elementIndex = elements.findIndex(el => el.id === element.id);
                    if (elementIndex !== -1) {
                      newElements[elementIndex] = {
                        ...newElements[elementIndex],
                        shotDetails: {
                          ...newElements[elementIndex].shotDetails,
                          shotType: value as any
                        }
                      };
                      onElementsChange(newElements);
                    }
                  }}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="wide_shot">Wide Shot</SelectItem>
                    <SelectItem value="medium_shot">Medium Shot</SelectItem>
                    <SelectItem value="close_up">Close-up</SelectItem>
                    <SelectItem value="extreme_close_up">Extreme Close-up</SelectItem>
                    <SelectItem value="over_shoulder">Over Shoulder</SelectItem>
                    <SelectItem value="two_shot">Two Shot</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Movement */}
              <div>
                <Label className="text-xs">Movement</Label>
                <Select
                  value={element.shotDetails?.movement}
                  onValueChange={(value) => {
                    const newElements = [...elements];
                    const elementIndex = elements.findIndex(el => el.id === element.id);
                    if (elementIndex !== -1) {
                      newElements[elementIndex] = {
                        ...newElements[elementIndex],
                        shotDetails: {
                          ...newElements[elementIndex].shotDetails,
                          movement: value as any
                        }
                      };
                      onElementsChange(newElements);
                    }
                  }}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="static">Static</SelectItem>
                    <SelectItem value="pan_left">Pan Left</SelectItem>
                    <SelectItem value="pan_right">Pan Right</SelectItem>
                    <SelectItem value="tilt_up">Tilt Up</SelectItem>
                    <SelectItem value="tilt_down">Tilt Down</SelectItem>
                    <SelectItem value="zoom_in">Zoom In</SelectItem>
                    <SelectItem value="zoom_out">Zoom Out</SelectItem>
                    <SelectItem value="dolly_in">Dolly In</SelectItem>
                    <SelectItem value="dolly_out">Dolly Out</SelectItem>
                    <SelectItem value="tracking">Tracking</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Voice Over */}
              <div>
                <Label className="text-xs flex items-center gap-1">
                  <Mic className="h-3 w-3" />
                  Voice Over
                </Label>
                <Textarea
                  value={element.shotDetails?.voiceOver?.text || ''}
                  onChange={(e) => {
                    const newElements = [...elements];
                    const elementIndex = elements.findIndex(el => el.id === element.id);
                    if (elementIndex !== -1) {
                      newElements[elementIndex] = {
                        ...newElements[elementIndex],
                        shotDetails: {
                          ...newElements[elementIndex].shotDetails,
                          voiceOver: {
                            ...newElements[elementIndex].shotDetails?.voiceOver,
                            needed: e.target.value.length > 0,
                            text: e.target.value
                          }
                        }
                      };
                      onElementsChange(newElements);
                    }
                  }}
                  placeholder="Voice over text..."
                  className="h-16 text-xs"
                />
              </div>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
};

export default EnhancedScriptEditor;
