import React, { useState } from 'react';
import { Wand2, Plus, Upload, FileText, Loader2, Edit3, Trash2, GripVertical } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Textarea } from '../ui/textarea';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useStoryboardStore } from '../../store/storyboardStore';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Scene } from '../../types';
import { toast } from 'sonner';

const ScriptEditor: React.FC = () => {
  const {
    currentProject,
    currentEpisode,
    isGenerating,
    generateScript,
    addScene,
    updateScene,
    deleteScene,
    reorderScenes,
    setCurrentView
  } = useStoryboardStore();

  const [scriptBrief, setScriptBrief] = useState('');
  const [isGenerateDialogOpen, setIsGenerateDialogOpen] = useState(false);
  const [newSceneTitle, setNewSceneTitle] = useState('');
  const [newSceneDescription, setNewSceneDescription] = useState('');
  const [isAddSceneDialogOpen, setIsAddSceneDialogOpen] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <FileText className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const handleGenerateScript = async () => {
    if (!scriptBrief.trim()) {
      toast.error('Please enter a brief description for script generation');
      return;
    }

    try {
      await generateScript(currentProject.id, scriptBrief);
      setIsGenerateDialogOpen(false);
      setScriptBrief('');
      toast.success('Script generated successfully!');
    } catch (error) {
      toast.error('Failed to generate script. Please try again.');
    }
  };

  const handleAddScene = () => {
    if (!newSceneTitle.trim()) {
      toast.error('Please enter a scene title');
      return;
    }

    addScene(currentProject.id, newSceneTitle.trim(), newSceneDescription.trim());
    setNewSceneTitle('');
    setNewSceneDescription('');
    setIsAddSceneDialogOpen(false);
    toast.success('Scene added successfully!');
  };

  const handleDragEnd = (event: any) => {
    const { active, over } = event;

    if (active.id !== over.id && currentEpisode) {
      const oldIndex = currentEpisode.scenes.findIndex(scene => scene.id === active.id);
      const newIndex = currentEpisode.scenes.findIndex(scene => scene.id === over.id);
      
      reorderScenes(currentEpisode.id, oldIndex, newIndex);
    }
  };

  const SortableSceneCard: React.FC<{ scene: Scene }> = ({ scene }) => {
    const {
      attributes,
      listeners,
      setNodeRef,
      transform,
      transition,
    } = useSortable({ id: scene.id });

    const style = {
      transform: CSS.Transform.toString(transform),
      transition,
    };

    return (
      <div ref={setNodeRef} style={style} {...attributes}>
        <Card className="hover:shadow-md transition-shadow">
          <CardHeader className="pb-4">
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3 flex-1">
                <div 
                  {...listeners}
                  className="p-1 hover:bg-gray-100 rounded cursor-grab active:cursor-grabbing"
                >
                  <GripVertical className="w-4 h-4 text-gray-400" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary">Scene {scene.sceneNumber}</Badge>
                    <CardTitle className="text-lg">{scene.title}</CardTitle>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{scene.description}</p>
                </div>
              </div>
              <div className="flex items-center space-x-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    // TODO: Implement scene editing
                    toast.info('Scene editing coming soon!');
                  }}
                >
                  <Edit3 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    deleteScene(scene.id);
                    toast.success('Scene deleted');
                  }}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-sm text-gray-600">
                {scene.shots.length} shot{scene.shots.length !== 1 ? 's' : ''}
              </div>
              {scene.shots.length > 0 && (
                <div className="space-y-2">
                  {scene.shots.map((shot, index) => (
                    <div key={shot.id} className="text-sm bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center justify-between mb-1">
                        <Badge variant="outline" className="text-xs">
                          Shot {shot.shotNumber}
                        </Badge>
                        <span className="text-xs text-gray-500 capitalize">
                          {shot.cameraAngle.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-gray-700">{shot.description}</p>
                      {shot.voiceOver && (
                        <p className="text-gray-600 italic mt-1">"{shot.voiceOver}"</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Script Editor</h1>
          <p className="text-gray-600">Generate and manage your storyboard script</p>
        </div>

        <div className="flex items-center space-x-3">
          <Dialog open={isAddSceneDialogOpen} onOpenChange={setIsAddSceneDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Scene
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Scene</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="scene-title">Scene Title</Label>
                  <Input
                    id="scene-title"
                    placeholder="Enter scene title..."
                    value={newSceneTitle}
                    onChange={(e) => setNewSceneTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="scene-description">Description</Label>
                  <Textarea
                    id="scene-description"
                    placeholder="Describe what happens in this scene..."
                    value={newSceneDescription}
                    onChange={(e) => setNewSceneDescription(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsAddSceneDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleAddScene} disabled={!newSceneTitle.trim()}>
                    Add Scene
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isGenerateDialogOpen} onOpenChange={setIsGenerateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Wand2 className="w-4 h-4 mr-2" />
                Generate Script
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>AI Script Generation</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="brief">Project Brief</Label>
                  <Textarea
                    id="brief"
                    placeholder="Describe your video concept, story, characters, and key scenes..."
                    value={scriptBrief}
                    onChange={(e) => setScriptBrief(e.target.value)}
                    rows={4}
                  />
                  <p className="text-sm text-gray-500">
                    Be as detailed as possible. Include genre, tone, target audience, and key story elements.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="genre">Genre (Optional)</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select genre" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="narrative">Narrative</SelectItem>
                        <SelectItem value="documentary">Documentary</SelectItem>
                        <SelectItem value="animation">Animation</SelectItem>
                        <SelectItem value="music-video">Music Video</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="tone">Tone (Optional)</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select tone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="dramatic">Dramatic</SelectItem>
                        <SelectItem value="humorous">Humorous</SelectItem>
                        <SelectItem value="inspirational">Inspirational</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex justify-end space-x-2 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsGenerateDialogOpen(false)}
                    disabled={isGenerating}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleGenerateScript}
                    disabled={!scriptBrief.trim() || isGenerating}
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-4 h-4 mr-2" />
                        Generate Script
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Content */}
      {!currentEpisode || currentEpisode.scenes.length === 0 ? (
        <div className="text-center py-12">
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
              <FileText className="w-8 h-8 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">No script yet</h3>
              <p className="text-gray-600">Generate a script using AI or add scenes manually</p>
            </div>
            <div className="flex justify-center space-x-3">
              <Button 
                onClick={() => setIsGenerateDialogOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Wand2 className="w-4 h-4 mr-2" />
                Generate with AI
              </Button>
              <Button 
                variant="outline"
                onClick={() => setIsAddSceneDialogOpen(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Scene Manually
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Script Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Script Overview</span>
                <div className="flex items-center space-x-3">
                  <Badge variant="secondary">
                    {currentEpisode?.scenes.length || 0} Scenes
                  </Badge>
                  <Badge variant="secondary">
                    {currentEpisode?.scenes.reduce((acc, scene) => acc + scene.shots.length, 0) || 0} Shots
                  </Badge>
                  <Button 
                    size="sm"
                    onClick={() => setCurrentView('storyboard')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Create Storyboard
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
          </Card>

          {/* Scenes List */}
          <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
          >
            <SortableContext
              items={currentEpisode?.scenes.map(scene => scene.id) || []}
              strategy={verticalListSortingStrategy}
            >
              <div className="space-y-4">
                {currentEpisode?.scenes.map((scene) => (
                  <SortableSceneCard key={scene.id} scene={scene} />
                )) || []}
              </div>
            </SortableContext>
          </DndContext>
        </div>
      )}
    </div>
  );
};

export default ScriptEditor;
