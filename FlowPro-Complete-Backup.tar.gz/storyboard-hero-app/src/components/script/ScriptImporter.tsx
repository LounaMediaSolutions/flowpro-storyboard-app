import React, { useState, useCallback } from 'react';
import { Upload, FileText, Download, Eye, Play, AlertCircle, CheckCircle, Film } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Progress } from '../ui/progress';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useDropzone } from 'react-dropzone';
import { useStoryboardStore } from '../../store/storyboardStore';
import { toast } from 'sonner';

interface ParsedScript {
  title: string;
  scenes: ParsedScene[];
  characters: string[];
  locations: string[];
}

interface ParsedScene {
  sceneNumber: number;
  location: string;
  timeOfDay: string;
  description: string;
  shots: ParsedShot[];
}

interface ParsedShot {
  description: string;
  voiceOver?: string;
  cameraAngle?: string;
  character?: string;
}

const ScriptImporter: React.FC = () => {
  const {
    currentProject,
    currentEpisode,
    createProject,
    createEpisode,
    setCurrentEpisode,
    addScene,
    addShot,
    addCharacter,
    addLocation,
    setCurrentView
  } = useStoryboardStore();

  const [importProgress, setImportProgress] = useState(0);
  const [isImporting, setIsImporting] = useState(false);
  const [parsedScript, setParsedScript] = useState<ParsedScript | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState('');
  const [manualScript, setManualScript] = useState('');
  const [scriptFormat, setScriptFormat] = useState<'fountain' | 'fdx' | 'manual'>('manual');

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    
    if (fileExtension === 'fountain') {
      setScriptFormat('fountain');
      handleFountainImport(file);
    } else if (fileExtension === 'fdx') {
      setScriptFormat('fdx');
      handleFinalDraftImport(file);
    } else {
      toast.error('Unsupported file format. Please upload .fountain or .fdx files.');
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.fountain'],
      'application/xml': ['.fdx'],
      'text/xml': ['.fdx']
    },
    multiple: false
  });

  const handleFountainImport = async (file: File) => {
    setIsImporting(true);
    setImportProgress(0);

    try {
      const text = await file.text();
      const parsed = parseFountainScript(text);
      setParsedScript(parsed);
      setImportProgress(100);
      toast.success('Fountain script parsed successfully!');
    } catch (error) {
      toast.error('Failed to parse Fountain script');
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  const handleFinalDraftImport = async (file: File) => {
    setIsImporting(true);
    setImportProgress(0);

    try {
      const text = await file.text();
      const parsed = parseFinalDraftScript(text);
      setParsedScript(parsed);
      setImportProgress(100);
      toast.success('Final Draft script parsed successfully!');
    } catch (error) {
      toast.error('Failed to parse Final Draft script');
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  const handleManualScript = () => {
    if (!manualScript.trim()) {
      toast.error('Please enter a script');
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      const parsed = parseManualScript(manualScript);
      setParsedScript(parsed);
      setImportProgress(100);
      toast.success('Script parsed successfully!');
    } catch (error) {
      toast.error('Failed to parse script');
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  const parseFountainScript = (text: string): ParsedScript => {
    const lines = text.split('\n');
    const script: ParsedScript = {
      title: 'Imported Script',
      scenes: [],
      characters: [],
      locations: []
    };

    let currentScene: ParsedScene | null = null;
    let sceneNumber = 1;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      setImportProgress((i / lines.length) * 90);

      // Title
      if (line.startsWith('Title:')) {
        script.title = line.replace('Title:', '').trim();
        continue;
      }

      // Scene heading (INT./EXT.)
      if (line.match(/^(INT\.|EXT\.)/)) {
        if (currentScene) {
          script.scenes.push(currentScene);
        }

        const parts = line.split(' - ');
        const location = parts[0].replace(/^(INT\.|EXT\.)\s*/, '').trim();
        const timeOfDay = parts[1] || 'DAY';

        if (!script.locations.includes(location)) {
          script.locations.push(location);
        }

        currentScene = {
          sceneNumber,
          location,
          timeOfDay: timeOfDay.toLowerCase(),
          description: '',
          shots: []
        };
        sceneNumber++;
        continue;
      }

      // Character dialogue
      if (line.match(/^[A-Z][A-Z\s]+$/) && line.length < 30) {
        if (!script.characters.includes(line)) {
          script.characters.push(line);
        }
        continue;
      }

      // Action/Description
      if (line && currentScene && !line.startsWith('(') && !line.startsWith('#')) {
        if (!currentScene.description) {
          currentScene.description = line;
        }
        
        // Create shot from action line
        currentScene.shots.push({
          description: line,
          cameraAngle: 'medium_shot'
        });
      }
    }

    if (currentScene) {
      script.scenes.push(currentScene);
    }

    return script;
  };

  const parseFinalDraftScript = (xmlText: string): ParsedScript => {
    // Basic XML parsing for Final Draft format
    const script: ParsedScript = {
      title: 'Final Draft Import',
      scenes: [],
      characters: [],
      locations: []
    };

    // This is a simplified parser - in production, you'd use a proper XML parser
    const sceneHeadings = xmlText.match(/<Text[^>]*>.*?(INT\.|EXT\.).*?<\/Text>/g) || [];
    let sceneNumber = 1;

    sceneHeadings.forEach((heading: string, index) => {
      setImportProgress((index / sceneHeadings.length) * 90);
      
      const text = heading.replace(/<[^>]*>/g, '').trim();
      const parts = text.split(' - ');
      const location = parts[0].replace(/^(INT\.|EXT\.)\s*/, '').trim();
      const timeOfDay = parts[1] || 'DAY';

      script.scenes.push({
        sceneNumber,
        location,
        timeOfDay: timeOfDay.toLowerCase(),
        description: `Scene ${sceneNumber} - ${location}`,
        shots: [
          {
            description: `Establishing shot of ${location}`,
            cameraAngle: 'wide_shot'
          },
          {
            description: `Main action in ${location}`,
            cameraAngle: 'medium_shot'
          }
        ]
      });
      sceneNumber++;
    });

    return script;
  };

  const parseManualScript = (text: string): ParsedScript => {
    const lines = text.split('\n');
    const script: ParsedScript = {
      title: 'Manual Script Import',
      scenes: [],
      characters: [],
      locations: []
    };

    let currentScene: ParsedScene | null = null;
    let sceneNumber = 1;
    let currentShot: any = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      setImportProgress((i / lines.length) * 90);

      // Skip empty lines
      if (!line) continue;

      // Scene heading (INT./EXT.)
      if (line.match(/^(INT\.|EXT\.)/i)) {
        // Save previous scene
        if (currentScene && currentScene.shots.length > 0) {
          script.scenes.push(currentScene);
        }

        // Parse scene heading
        const parts = line.split(' - ');
        const locationPart = parts[0].replace(/^(INT\.|EXT\.)\s*/i, '').trim();
        const timeOfDay = parts[1] ? parts[1].toLowerCase() : 'day';

        // Add location if not exists
        if (!script.locations.includes(locationPart)) {
          script.locations.push(locationPart);
        }

        currentScene = {
          sceneNumber,
          location: locationPart,
          timeOfDay,
          description: `Scene ${sceneNumber} - ${locationPart}`,
          shots: []
        };
        sceneNumber++;
        continue;
      }

      // Character name (all caps, centered-ish)
      if (line.match(/^[A-Z][A-Z\s]+$/) && line.length < 30 && !line.includes('.')) {
        const characterName = line.trim();
        if (!script.characters.includes(characterName)) {
          script.characters.push(characterName);
        }

        // Create dialogue shot
        if (currentScene) {
          currentShot = {
            description: `${characterName} speaking`,
            cameraAngle: 'close_up',
            character: characterName
          };
          continue;
        }
      }

      // Dialogue or action
      if (currentScene) {
        if (currentShot && currentShot.character) {
          // This is dialogue
          currentShot.description = `${currentShot.character}: "${line}"`;
          currentShot.dialogue = line;
          currentScene.shots.push(currentShot);
          currentShot = null;
        } else {
          // This is action/description
          currentScene.shots.push({
            description: line,
            cameraAngle: 'medium_shot'
          });
        }
      } else {
        // No scene yet, create a default scene
        if (!currentScene) {
          currentScene = {
            sceneNumber: 1,
            location: 'Unknown Location',
            timeOfDay: 'day',
            description: 'Scene 1',
            shots: []
          };
          sceneNumber = 2;
        }
        
        currentScene.shots.push({
          description: line,
          cameraAngle: 'medium_shot'
        });
      }
    }

    // Add final scene
    if (currentScene && currentScene.shots.length > 0) {
      script.scenes.push(currentScene);
    }

    // Ensure we have at least one scene
    if (script.scenes.length === 0 && text.trim()) {
      script.scenes.push({
        sceneNumber: 1,
        location: 'Unknown Location',
        timeOfDay: 'day',
        description: 'Imported Scene',
        shots: [{
          description: text.trim().substring(0, 100) + (text.length > 100 ? '...' : ''),
          cameraAngle: 'medium_shot'
        }]
      });
    }

    return script;
  };

  const handleManualImport = async () => {
    if (!manualScript.trim()) {
      toast.error('Please enter script content');
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      // Parse the manual script
      const parsed = parseManualScript(manualScript);
      setParsedScript(parsed);
      
      setImportProgress(100);
      toast.success('Script parsed successfully!');
      
    } catch (error) {
      toast.error('Failed to parse script');
      console.error(error);
    } finally {
      setIsImporting(false);
      setImportProgress(0);
    }
  };

  const handleImportToEpisode = async () => {
    if (!parsedScript) {
      toast.error('No script to import');
      return;
    }

    // Get current project (might be newly created)
    const project = useStoryboardStore.getState().currentProject;
    if (!project) {
      toast.error('No project available');
      return;
    }

    setIsImporting(true);
    setImportProgress(0);

    try {
      let targetEpisode = currentEpisode;

      // Create new episode if none selected
      if (!selectedEpisode || selectedEpisode === 'new') {
        const newEpisode = createEpisode(project.id, parsedScript.title, 'Imported from script');
        if (!newEpisode) {
          throw new Error('Failed to create episode');
        }
        targetEpisode = newEpisode;
        setCurrentEpisode(targetEpisode);
      } else {
        targetEpisode = project.episodes.find(ep => ep.id === selectedEpisode) || null;
      }

      if (!targetEpisode) {
        throw new Error('No target episode available');
      }

      // Add characters
      parsedScript.characters.forEach(charName => {
        addCharacter(project.id, charName, `Character from imported script`, `${charName} appearance`);
        setImportProgress(prev => prev + (10 / parsedScript.characters.length));
      });

      // Add locations
      parsedScript.locations.forEach(locationName => {
        addLocation(project.id, {
          name: locationName,
          description: `Location from imported script`,
          type: 'location',
          availability: [],
          cost: 0,
          contact: '',
          notes: ''
        });
        setImportProgress(prev => prev + (10 / parsedScript.locations.length));
      });

      // Add scenes and shots
      parsedScript.scenes.forEach((scene, sceneIndex) => {
        const newScene = addScene(targetEpisode!.id, `Scene ${scene.sceneNumber}`, scene.description, scene.location);
        
        if (newScene) {
          // Add shots to the newly created scene
          scene.shots.forEach(shot => {
            addShot(newScene.id, shot.description, shot.voiceOver);
          });
        }

        setImportProgress(prev => prev + (70 / parsedScript.scenes.length));
      });

      setImportProgress(100);
      toast.success(`Script imported successfully! Created ${parsedScript.scenes.length} scenes with ${parsedScript.scenes.reduce((acc, scene) => acc + scene.shots.length, 0)} shots.`);
      
      // Navigate to episodes first, then storyboard
      setTimeout(() => {
        setCurrentView('episodes');
        // Then navigate to storyboard after a brief delay
        setTimeout(() => {
          setCurrentView('storyboard');
        }, 1500);
      }, 1000);

    } catch (error) {
      toast.error('Failed to import script to episode');
      console.error(error);
    } finally {
      setIsImporting(false);
      setImportProgress(0);
    }
  };

  // Handle creating project from script
  const handleCreateProjectFromScript = async () => {
    if (!parsedScript) {
      toast.error('Please import a script first');
      return;
    }

    try {
      // Create project with script title
      const projectTitle = parsedScript.title || 'Imported Script Project';
      createProject(projectTitle, `Project created from imported script: ${projectTitle}`);
      
      toast.success('Project created successfully! Now importing script...');
      
      // Wait a moment for project to be created, then import
      setTimeout(() => {
        handleImportToEpisode();
      }, 500);
      
    } catch (error) {
      toast.error('Failed to create project from script');
      console.error(error);
    }
  };

  if (!currentProject) {
    return (
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col space-y-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">🎬 Start with Your Script</h1>
            <p className="text-gray-600">Import your script to create a new project, or go to dashboard to select existing project</p>
          </div>
        </div>

        {/* Two Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Option 1: Import Script to Create Project */}
          <Card className="border-2 border-blue-200 bg-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5 text-blue-600" />
                Start with Script
              </CardTitle>
              <p className="text-sm text-gray-600">Import script and create project automatically</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* File Upload */}
              <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
                  isDragActive 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-300 hover:border-blue-400'
                }`}
              >
                <input {...getInputProps()} />
                <Upload className="w-8 h-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600">
                  {isDragActive
                    ? 'Drop your script file here...'
                    : 'Drag & drop script file or click to browse'}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Supports .fountain and .fdx files
                </p>
              </div>

              {/* Manual Script Input */}
              <div className="space-y-2">
                <Label>Or paste script content:</Label>
                <Textarea
                  placeholder="Paste your script here..."
                  value={manualScript}
                  onChange={(e) => setManualScript(e.target.value)}
                  rows={8}
                />
                <Button 
                  onClick={() => handleManualImport()}
                  disabled={!manualScript.trim()}
                  className="w-full"
                  variant="outline"
                >
                  Parse Manual Script
                </Button>
              </div>

              {/* Show parsed script and create project button */}
              {parsedScript && (
                <div className="space-y-3 p-4 bg-white rounded-lg border">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium">Script Parsed Successfully!</span>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p><strong>Title:</strong> {parsedScript.title}</p>
                    <p><strong>Scenes:</strong> {parsedScript.scenes.length}</p>
                    <p><strong>Characters:</strong> {parsedScript.characters.length}</p>
                  </div>
                  <Button 
                    onClick={handleCreateProjectFromScript}
                    disabled={isImporting}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    {isImporting ? 'Creating Project...' : '🎬 Create Project from Script'}
                  </Button>
                </div>
              )}

              {/* Import Progress */}
              {isImporting && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Creating project...</span>
                    <span>{Math.round(importProgress)}%</span>
                  </div>
                  <Progress value={importProgress} className="h-2" />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Option 2: Go to Dashboard */}
          <Card className="border-2 border-gray-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Film className="w-5 h-5 text-gray-600" />
                Use Existing Project
              </CardTitle>
              <p className="text-sm text-gray-600">Select from your existing projects</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center py-8">
                <Film className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="text-gray-600 mb-4">Go to dashboard to select an existing project</p>
                <Button onClick={() => setCurrentView('dashboard')} variant="outline" className="w-full">
                  Go to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Script Import</h1>
          <p className="text-gray-600">Import scripts from Fountain, Final Draft, or manual entry</p>
        </div>
      </div>

      <Tabs defaultValue="import" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="import">Import Script</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
          <TabsTrigger value="generate">Generate Storyboard</TabsTrigger>
        </TabsList>

        {/* Import Tab */}
        <TabsContent value="import" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* File Upload */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Upload className="w-5 h-5" />
                  <span>Upload Script File</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
                    isDragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <input {...getInputProps()} />
                  {isDragActive ? (
                    <div className="space-y-2">
                      <Upload className="w-12 h-12 mx-auto text-blue-500" />
                      <p className="text-blue-600">Drop the script file here...</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Upload className="w-12 h-12 mx-auto text-gray-400" />
                      <p className="text-gray-600">Drag & drop a script file here, or click to browse</p>
                      <div className="flex justify-center space-x-2 mt-2">
                        <Badge variant="outline">.fountain</Badge>
                        <Badge variant="outline">.fdx</Badge>
                      </div>
                    </div>
                  )}
                </div>

                {isImporting && (
                  <div className="mt-4 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Processing script...</span>
                      <span>{importProgress.toFixed(0)}%</span>
                    </div>
                    <Progress value={importProgress} className="w-full" />
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Manual Entry */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="w-5 h-5" />
                  <span>Manual Script Entry</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="manual-script">Script Content</Label>
                  <Textarea
                    id="manual-script"
                    placeholder="Enter your script here... Each paragraph will become a shot."
                    value={manualScript}
                    onChange={(e) => setManualScript(e.target.value)}
                    rows={10}
                    className="mt-1"
                  />
                </div>
                <Button 
                  onClick={handleManualScript}
                  disabled={!manualScript.trim() || isImporting}
                  className="w-full"
                >
                  {isImporting ? 'Processing...' : 'Parse Script'}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Supported Formats */}
          <Card>
            <CardHeader>
              <CardTitle>Supported Formats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-green-500">Fountain</Badge>
                    <span className="text-sm">.fountain</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Open-source screenwriting format. Automatic scene and character detection.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-blue-500">Final Draft</Badge>
                    <span className="text-sm">.fdx</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Industry-standard screenwriting software format. Full scene analysis.
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-purple-500">Manual</Badge>
                    <span className="text-sm">Text input</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Plain text input. Each paragraph becomes a storyboard shot.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preview Tab */}
        <TabsContent value="preview" className="space-y-6">
          {parsedScript ? (
            <div className="space-y-6">
              {/* Script Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{parsedScript.title}</span>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">{parsedScript.scenes.length} Scenes</Badge>
                      <Badge variant="outline">{parsedScript.characters.length} Characters</Badge>
                      <Badge variant="outline">{parsedScript.locations.length} Locations</Badge>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div>
                      <h4 className="font-medium mb-2">Characters</h4>
                      <div className="space-y-1">
                        {parsedScript.characters.slice(0, 5).map((char, index) => (
                          <Badge key={index} variant="secondary">{char}</Badge>
                        ))}
                        {parsedScript.characters.length > 5 && (
                          <span className="text-sm text-gray-500">+{parsedScript.characters.length - 5} more</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Locations</h4>
                      <div className="space-y-1">
                        {parsedScript.locations.slice(0, 5).map((loc, index) => (
                          <Badge key={index} variant="secondary">{loc}</Badge>
                        ))}
                        {parsedScript.locations.length > 5 && (
                          <span className="text-sm text-gray-500">+{parsedScript.locations.length - 5} more</span>
                        )}
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Statistics</h4>
                      <div className="space-y-1 text-sm">
                        <div>Total Shots: {parsedScript.scenes.reduce((acc, scene) => acc + scene.shots.length, 0)}</div>
                        <div>Avg. Shots/Scene: {(parsedScript.scenes.reduce((acc, scene) => acc + scene.shots.length, 0) / parsedScript.scenes.length).toFixed(1)}</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Scene Preview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {parsedScript.scenes.map((scene) => (
                  <Card key={scene.sceneNumber} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center justify-between">
                        <span>Scene {scene.sceneNumber}</span>
                        <Badge variant="outline">{scene.shots.length} shots</Badge>
                      </CardTitle>
                      <div className="text-sm text-gray-600">
                        {scene.location} - {scene.timeOfDay.toUpperCase()}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-700 mb-3">{scene.description}</p>
                      <div className="space-y-1">
                        {scene.shots.slice(0, 3).map((shot, index) => (
                          <div key={index} className="text-xs text-gray-600 truncate">
                            {index + 1}. {shot.description}
                          </div>
                        ))}
                        {scene.shots.length > 3 && (
                          <div className="text-xs text-gray-500">+{scene.shots.length - 3} more shots</div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <Eye className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No script to preview</h3>
              <p className="text-gray-600">Import a script first to see the preview</p>
            </div>
          )}
        </TabsContent>

        {/* Generate Tab */}
        <TabsContent value="generate" className="space-y-6">
          {parsedScript ? (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Generate Storyboard</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="target-episode">Target Episode</Label>
                    <Select value={selectedEpisode} onValueChange={setSelectedEpisode}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select episode or create new" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">Create New Episode</SelectItem>
                        {currentProject.episodes.map((episode) => (
                          <SelectItem key={episode.id} value={episode.id}>
                            Episode {episode.episodeNumber}: {episode.title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-blue-900">Ready to Generate</h4>
                        <p className="text-sm text-blue-700 mt-1">
                          This will create {parsedScript.scenes.length} scenes with {parsedScript.scenes.reduce((acc, scene) => acc + scene.shots.length, 0)} shots, 
                          {parsedScript.characters.length} characters, and {parsedScript.locations.length} locations.
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button 
                    onClick={handleImportToEpisode}
                    disabled={isImporting}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                    size="lg"
                  >
                    {isImporting ? (
                      <div className="flex items-center space-x-2">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                        <span>Generating Storyboard... {importProgress.toFixed(0)}%</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Play className="w-4 h-4" />
                        <span>Generate Storyboard</span>
                      </div>
                    )}
                  </Button>

                  {isImporting && (
                    <Progress value={importProgress} className="w-full" />
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-12">
              <AlertCircle className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No script to generate from</h3>
              <p className="text-gray-600">Import and preview a script first</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ScriptImporter;
