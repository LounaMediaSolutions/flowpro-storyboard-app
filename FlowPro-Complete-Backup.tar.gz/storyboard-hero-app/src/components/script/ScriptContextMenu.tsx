import React, { useState, useEffect, useRef } from 'react';
import {
  Film, MessageSquare, Users, Camera, ArrowRight, 
  Map, Clock, Mic, Eye, Type, Zap, Settings, Plus,
  FileText, Edit3, Scissors, Copy, Trash2,
  BookOpen, Star, Palette, ChevronRight
} from 'lucide-react';
import { ScriptElementType } from './EnhancedScriptEditor';

interface ContextMenuProps {
  isVisible: boolean;
  position: { x: number; y: number };
  onClose: () => void;
  onElementSelect: (elementType: ScriptElementType, template?: string) => void;
  onAction?: (action: string) => void;
  savedCharacters?: string[];
  savedLocations?: string[];
}

interface ElementTemplate {
  type: ScriptElementType;
  label: string;
  icon: React.ComponentType<any>;
  color: string;
  template?: string;
  description: string;
  shortcut?: string;
}

const scriptElements: ElementTemplate[] = [
  {
    type: 'scene_heading',
    label: 'Scene Heading',
    icon: Film,
    color: 'text-blue-600',
    template: 'INT. LOCATION - DAY',
    description: 'Location and time of day',
    shortcut: 'Ctrl+H'
  },
  {
    type: 'action',
    label: 'Action/Description',
    icon: Edit3,
    color: 'text-green-600',
    template: '',
    description: 'Scene description or action',
    shortcut: 'Ctrl+A'
  },
  {
    type: 'character',
    label: 'Character Name',
    icon: Users,
    color: 'text-purple-600',
    template: 'CHARACTER NAME',
    description: 'Speaking character name',
    shortcut: 'Ctrl+C'
  },
  {
    type: 'dialogue',
    label: 'Dialogue',
    icon: MessageSquare,
    color: 'text-orange-600',
    template: '',
    description: 'Character dialogue',
    shortcut: 'Ctrl+D'
  },
  {
    type: 'parenthetical',
    label: 'Parenthetical',
    icon: Type,
    color: 'text-indigo-600',
    template: '(continuing)',
    description: 'Direction within dialogue',
    shortcut: 'Ctrl+P'
  },
  {
    type: 'transition',
    label: 'Transition',
    icon: ArrowRight,
    color: 'text-red-600',
    template: 'CUT TO:',
    description: 'Scene transition',
    shortcut: 'Ctrl+T'
  },
  {
    type: 'shot',
    label: 'Camera Shot',
    icon: Camera,
    color: 'text-teal-600',
    template: 'CLOSE-UP ON',
    description: 'Camera direction',
    shortcut: 'Ctrl+S'
  }
];

const quickActions = [
  { action: 'duplicate', label: 'Duplicate Line', icon: Copy, shortcut: 'Ctrl+Shift+D' },
  { action: 'delete', label: 'Delete Line', icon: Trash2, shortcut: 'Del' },
  { action: 'moveUp', label: 'Move Up', icon: ArrowRight, shortcut: 'Ctrl+↑' },
  { action: 'moveDown', label: 'Move Down', icon: ArrowRight, shortcut: 'Ctrl+↓' }
];

const ScriptContextMenu: React.FC<ContextMenuProps> = ({
  isVisible,
  position,
  onClose,
  onElementSelect,
  onAction,
  savedCharacters = [],
  savedLocations = []
}) => {
  const menuRef = useRef<HTMLDivElement>(null);
  const [submenuOpen, setSubmenuOpen] = useState<string | null>(null);
  const [submenuPosition, setSubmenuPosition] = useState({ x: 0, y: 0 });

  // Common character variations for professional screenwriting
  const characterVariations = [
    { suffix: '', label: 'Normal' },
    { suffix: ' (V.O.)', label: 'Voice Over' },
    { suffix: ' (O.S.)', label: 'Off Screen' },
    { suffix: ' (CONT\'D)', label: 'Continued' },
    { suffix: ' (FILTERED)', label: 'Filtered' },
    { suffix: ' (PRE-LAP)', label: 'Pre-Lap' },
    { suffix: ' (POST-LAP)', label: 'Post-Lap' }
  ];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isVisible) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleKeyDown);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [isVisible, onClose]);

  const handleElementClick = (element: ElementTemplate) => {
    onElementSelect(element.type, element.template);
    onClose();
  };

  const handleActionClick = (action: string) => {
    if (onAction) {
      onAction(action);
    }
    onClose();
  };

  const handleCharacterSelect = (characterName: string, variation: string = '') => {
    onElementSelect('character', characterName + variation);
    onClose();
  };

  const handleLocationSelect = (location: string) => {
    onElementSelect('scene_heading', `INT. ${location.toUpperCase()} - DAY`);
    onClose();
  };

  const handleSubmenuHover = (submenu: string, event: React.MouseEvent) => {
    const rect = (event.target as HTMLElement).getBoundingClientRect();
    setSubmenuPosition({
      x: rect.right + 5,
      y: rect.top
    });
    setSubmenuOpen(submenu);
  };

  const closeSubmenu = () => {
    setSubmenuOpen(null);
  };

  if (!isVisible) return null;

  return (
    <div
      ref={menuRef}
      className="fixed z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-2 min-w-[280px]"
      style={{
        left: position.x,
        top: position.y,
        maxHeight: '80vh',
        overflowY: 'auto'
      }}
    >
      {/* Header */}
      <div className="px-4 py-2 border-b border-gray-100 dark:border-gray-700">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            Insert Script Element
          </span>
        </div>
      </div>

      {/* Script Elements */}
      <div className="py-2">
        <div className="px-4 py-1">
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Script Elements
          </span>
        </div>
        {scriptElements.map((element) => (
          <button
            key={element.type}
            onClick={() => handleElementClick(element)}
            className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between group transition-colors"
          >
            <div className="flex items-center gap-3">
              <element.icon className={`w-4 h-4 ${element.color}`} />
              <div className="flex-1">
                <div className="font-medium text-sm text-gray-900 dark:text-gray-100">
                  {element.label}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  {element.description}
                </div>
              </div>
            </div>
            {element.shortcut && (
              <span className="text-xs text-gray-400 dark:text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity">
                {element.shortcut}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Separator */}
      <div className="border-t border-gray-100 dark:border-gray-700 my-2" />

      {/* Quick Actions */}
      <div className="py-2">
        <div className="px-4 py-1">
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Quick Actions
          </span>
        </div>
        {quickActions.map((action) => (
          <button
            key={action.action}
            onClick={() => handleActionClick(action.action)}
            className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between group transition-colors"
          >
            <div className="flex items-center gap-3">
              <action.icon className="w-4 h-4 text-gray-500" />
              <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
                {action.label}
              </span>
            </div>
            {action.shortcut && (
              <span className="text-xs text-gray-400 dark:text-gray-500 opacity-0 group-hover:opacity-100 transition-opacity">
                {action.shortcut}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Saved Characters Section */}
      {savedCharacters.length > 0 && (
        <>
          <div className="border-t border-gray-100 dark:border-gray-700 my-2" />
          <div className="py-2">
            <div className="px-4 py-1">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Characters ({savedCharacters.length})
              </span>
            </div>
            {savedCharacters.slice(0, 8).map((character) => (
              <div key={character} className="relative">
                <button
                  onMouseEnter={(e) => handleSubmenuHover(`character-${character}`, e)}
                  onMouseLeave={closeSubmenu}
                  onClick={() => handleCharacterSelect(character)}
                  className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between group transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <Users className="w-4 h-4 text-purple-600" />
                    <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
                      {character}
                    </span>
                  </div>
                  <ChevronRight className="w-3 h-3 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>

                {/* Character Variations Submenu */}
                {submenuOpen === `character-${character}` && (
                  <div
                    className="fixed z-50 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg py-2 min-w-[200px]"
                    style={{
                      left: submenuPosition.x,
                      top: submenuPosition.y
                    }}
                    onMouseEnter={() => setSubmenuOpen(`character-${character}`)}
                    onMouseLeave={closeSubmenu}
                  >
                    {characterVariations.map((variation) => (
                      <button
                        key={variation.suffix}
                        onClick={() => handleCharacterSelect(character, variation.suffix)}
                        className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-between transition-colors"
                      >
                        <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
                          {character}{variation.suffix}
                        </span>
                        <span className="text-xs text-gray-500">
                          {variation.label}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}
            
            {savedCharacters.length > 8 && (
              <div className="px-4 py-2">
                <span className="text-xs text-gray-500">
                  +{savedCharacters.length - 8} more characters...
                </span>
              </div>
            )}
          </div>
        </>
      )}

      {/* Saved Locations Section */}
      {savedLocations.length > 0 && (
        <>
          <div className="border-t border-gray-100 dark:border-gray-700 my-2" />
          <div className="py-2">
            <div className="px-4 py-1">
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Locations ({savedLocations.length})
              </span>
            </div>
            {savedLocations.slice(0, 6).map((location) => (
              <button
                key={location}
                onClick={() => handleLocationSelect(location)}
                className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
              >
                <Map className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
                  {location}
                </span>
              </button>
            ))}
          </div>
        </>
      )}

      {/* Quick Character Variations */}
      <div className="border-t border-gray-100 dark:border-gray-700 my-2" />
      <div className="py-2">
        <div className="px-4 py-1">
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Quick Characters
          </span>
        </div>
        
        <button
          onClick={() => handleElementClick({ 
            type: 'character', 
            template: 'NARRATOR', 
            label: '', 
            icon: Users, 
            color: '', 
            description: '' 
          })}
          className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
        >
          <Mic className="w-4 h-4 text-blue-500" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            NARRATOR
          </span>
        </button>
        
        <button
          onClick={() => handleElementClick({ 
            type: 'character', 
            template: 'VOICE (V.O.)', 
            label: '', 
            icon: Users, 
            color: '', 
            description: '' 
          })}
          className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
        >
          <Mic className="w-4 h-4 text-purple-500" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            VOICE (V.O.)
          </span>
        </button>
      </div>

      {/* Advanced Templates */}
      <div className="border-t border-gray-100 dark:border-gray-700 my-2" />
      <div className="py-2">
        <div className="px-4 py-1">
          <span className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
            Templates
          </span>
        </div>
        
        <button
          onClick={() => handleElementClick({ 
            type: 'scene_heading', 
            template: 'FADE IN:', 
            label: '', 
            icon: Film, 
            color: '', 
            description: '' 
          })}
          className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
        >
          <Star className="w-4 h-4 text-yellow-500" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            Fade In (Script Start)
          </span>
        </button>
        
        <button
          onClick={() => handleElementClick({ 
            type: 'transition', 
            template: 'FADE OUT.', 
            label: '', 
            icon: Film, 
            color: '', 
            description: '' 
          })}
          className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
        >
          <Star className="w-4 h-4 text-yellow-500" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            Fade Out (Script End)
          </span>
        </button>
        
        <button
          onClick={() => handleElementClick({ 
            type: 'action', 
            template: 'MONTAGE:', 
            label: '', 
            icon: Film, 
            color: '', 
            description: '' 
          })}
          className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-3 transition-colors"
        >
          <Palette className="w-4 h-4 text-purple-500" />
          <span className="font-medium text-sm text-gray-900 dark:text-gray-100">
            Montage Sequence
          </span>
        </button>
      </div>
    </div>
  );
};

export default ScriptContextMenu;
