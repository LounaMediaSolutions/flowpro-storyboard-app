import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Plus, Save, Download, Upload, Eye, Settings, Wand2,
  FileText, Film, Users, Clock, Type, Zap, BookOpen,
  Play, Pause, SkipForward, SkipBack, Volume2
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Textarea } from '../ui/textarea';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { ScrollArea } from '../ui/scroll-area';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { useStoryboardStore } from '../../store/storyboardStore';
import { toast } from 'sonner';
import ScriptContextMenu from './ScriptContextMenu';
import { ScriptElementType, ScriptElement } from './EnhancedScriptEditor';
import { useKeyboardShortcuts } from '../../hooks/useKeyboardShortcuts';
import { useSmartTyping } from '../../hooks/useSmartTyping';

const ProfessionalScriptEditor: React.FC = () => {
  const {
    currentProject,
    currentEpisode,
    isGenerating,
    generateScript,
    setCurrentView
  } = useStoryboardStore();

  const [scriptElements, setScriptElements] = useState<ScriptElement[]>([
    {
      id: '1',
      type: 'scene_heading',
      content: 'FADE IN:',
      formatting: { bold: true }
    },
    {
      id: '2',
      type: 'scene_heading',
      content: 'INT. OFFICE BUILDING - DAY',
      location: 'Office Building',
      timeOfDay: 'Day',
      isInterior: true
    },
    {
      id: '3',
      type: 'action',
      content: 'The busy office buzzes with activity. EMPLOYEES work diligently at their desks, phones ringing in the background.'
    },
    {
      id: '4',
      type: 'character',
      content: 'SARAH',
      formatting: { bold: true }
    },
    {
      id: '5',
      type: 'dialogue',
      content: 'Good morning, everyone! Ready for the big presentation?'
    },
    {
      id: '6',
      type: 'character',
      content: 'MIKE',
      formatting: { bold: true }
    },
    {
      id: '7',
      type: 'dialogue',
      content: 'Absolutely! I\'ve been preparing all week.'
    },
    {
      id: '8',
      type: 'action',
      content: 'SARAH walks over to the whiteboard and begins writing notes.'
    }
  ]);

  const [contextMenu, setContextMenu] = useState({
    isVisible: false,
    position: { x: 0, y: 0 },
    elementIndex: -1
  });

  const [selectedElementIndex, setSelectedElementIndex] = useState(0);
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [currentSuggestions, setCurrentSuggestions] = useState<string[]>([]);
  const scriptAreaRef = useRef<HTMLDivElement>(null);



  const handleRightClick = useCallback((event: React.MouseEvent, elementIndex?: number) => {
    event.preventDefault();
    
    setContextMenu({
      isVisible: true,
      position: { x: event.clientX, y: event.clientY },
      elementIndex: elementIndex ?? -1
    });
  }, []);

  const handleContextMenuClose = useCallback(() => {
    setContextMenu({ isVisible: false, position: { x: 0, y: 0 }, elementIndex: -1 });
  }, []);

  const handleElementSelect = useCallback((elementType: ScriptElementType, template?: string) => {
    const newElement: ScriptElement = {
      id: Date.now().toString(),
      type: elementType,
      content: template || '',
      formatting: {}
    };

    // Add formatting based on element type
    switch (elementType) {
      case 'scene_heading':
        newElement.formatting = { bold: true };
        break;
      case 'character':
        newElement.formatting = { bold: true };
        break;
      case 'transition':
        newElement.formatting = { bold: true };
        break;
    }

    // Insert at current position or after selected element
    const insertIndex = contextMenu.elementIndex >= 0 
      ? contextMenu.elementIndex + 1 
      : selectedElementIndex + 1;

    const newElements = [...scriptElements];
    newElements.splice(insertIndex, 0, newElement);
    setScriptElements(newElements);
    setSelectedElementIndex(insertIndex);
    
    toast.success(`Added ${elementType.replace('_', ' ')} element`);
  }, [contextMenu.elementIndex, selectedElementIndex, scriptElements]);

  const handleQuickAction = useCallback((action: string) => {
    const currentIndex = contextMenu.elementIndex >= 0 ? contextMenu.elementIndex : selectedElementIndex;
    
    switch (action) {
      case 'duplicate':
        const elementToDuplicate = scriptElements[currentIndex];
        if (elementToDuplicate) {
          const duplicated = {
            ...elementToDuplicate,
            id: Date.now().toString()
          };
          const newElements = [...scriptElements];
          newElements.splice(currentIndex + 1, 0, duplicated);
          setScriptElements(newElements);
          toast.success('Element duplicated');
        }
        break;
        
      case 'delete':
        if (scriptElements.length > 1 && currentIndex >= 0) {
          const newElements = scriptElements.filter((_, index) => index !== currentIndex);
          setScriptElements(newElements);
          setSelectedElementIndex(Math.max(0, currentIndex - 1));
          toast.success('Element deleted');
        }
        break;
        
      case 'moveUp':
        if (currentIndex > 0) {
          const newElements = [...scriptElements];
          [newElements[currentIndex], newElements[currentIndex - 1]] = 
          [newElements[currentIndex - 1], newElements[currentIndex]];
          setScriptElements(newElements);
          setSelectedElementIndex(currentIndex - 1);
          toast.success('Element moved up');
        }
        break;
        
      case 'moveDown':
        if (currentIndex < scriptElements.length - 1) {
          const newElements = [...scriptElements];
          [newElements[currentIndex], newElements[currentIndex + 1]] = 
          [newElements[currentIndex + 1], newElements[currentIndex]];
          setScriptElements(newElements);
          setSelectedElementIndex(currentIndex + 1);
          toast.success('Element moved down');
        }
        break;
    }
  }, [contextMenu.elementIndex, selectedElementIndex, scriptElements]);

  const updateElement = (index: number, content: string) => {
    const newElements = [...scriptElements];
    newElements[index] = { ...newElements[index], content };
    setScriptElements(newElements);
  };

  const getElementPlaceholder = (type: ScriptElementType): string => {
    switch (type) {
      case 'scene_heading': return 'INT./EXT. LOCATION - TIME OF DAY';
      case 'action': return 'Describe the action or scene...';
      case 'character': return 'CHARACTER NAME';
      case 'dialogue': return 'What the character says...';
      case 'parenthetical': return '(direction or emotion)';
      case 'transition': return 'CUT TO: / FADE IN: / FADE OUT.';
      case 'shot': return 'CLOSE-UP ON / WIDE SHOT / etc.';
      default: return 'Enter content...';
    }
  };

  const getElementStyle = (type: ScriptElementType, formatting: any = {}) => {
    const base = 'w-full p-3 border rounded-lg transition-all focus:ring-2 focus:ring-blue-500 focus:border-blue-500 ';
    const typeStyles: Record<ScriptElementType, string> = {
      scene_heading: 'font-bold text-lg bg-blue-50 border-blue-200 text-blue-900 ',
      action: 'bg-gray-50 border-gray-200 ',
      character: 'font-bold text-center bg-purple-50 border-purple-200 text-purple-900 ',
      dialogue: 'bg-orange-50 border-orange-200 ml-8 mr-16 ',
      parenthetical: 'text-sm bg-indigo-50 border-indigo-200 ml-12 mr-20 text-indigo-700 ',
      transition: 'font-bold text-right bg-red-50 border-red-200 text-red-900 ',
      shot: 'font-semibold bg-teal-50 border-teal-200 text-teal-900 ',
      general: 'bg-gray-50 border-gray-200 '
    };
    
    return base + (typeStyles[type] || typeStyles.general);
  };

  const exportScript = () => {
    const scriptText = scriptElements
      .map(element => {
        switch (element.type) {
          case 'scene_heading':
            return element.content.toUpperCase();
          case 'character':
            return `                    ${element.content.toUpperCase()}`;
          case 'dialogue':
            return `          ${element.content}`;
          case 'parenthetical':
            return `                    ${element.content}`;
          case 'transition':
            return `                                        ${element.content.toUpperCase()}`;
          default:
            return element.content;
        }
      })
      .join('\n\n');

    const blob = new Blob([scriptText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentEpisode?.title || 'Script'}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast.success('Script exported successfully!');
  };

  // Extract saved characters and locations from script
  const savedCharacters = React.useMemo(() => {
    const characters = new Set<string>();
    scriptElements.forEach(element => {
      if (element.type === 'character' && element.content.trim()) {
        // Clean character name (remove variations like (V.O.), (O.S.), etc.)
        const cleanName = element.content
          .replace(/\s*\(.*?\)\s*$/, '') // Remove parenthetical endings
          .replace(/\s*\(CONT'D\)\s*$/, '') // Remove (CONT'D)
          .trim()
          .toUpperCase();
        if (cleanName) {
          characters.add(cleanName);
        }
      }
    });
    return Array.from(characters).sort();
  }, [scriptElements]);

  const savedLocations = React.useMemo(() => {
    const locations = new Set<string>();
    scriptElements.forEach(element => {
      if (element.type === 'scene_heading' && element.content.trim()) {
        // Extract location from scene heading (INT./EXT. LOCATION - TIME)
        const match = element.content.match(/(?:INT\.|EXT\.)\s+([^-]+)/i);
        if (match) {
          const location = match[1].trim();
          if (location && !location.includes('FADE')) {
            locations.add(location);
          }
        }
      }
    });
    return Array.from(locations).sort();
  }, [scriptElements]);

  // Keyboard shortcuts
  const { shortcuts } = useKeyboardShortcuts({
    onElementSelect: handleElementSelect,
    onAction: handleQuickAction,
    isEnabled: !isPreviewMode
  });

  if (!currentProject || !currentEpisode) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <FileText className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Episode Selected</h3>
            <p className="text-gray-600">Please select an episode to start writing</p>
          </div>
          <Button onClick={() => setCurrentView('episodes')}>
            Go to Episodes
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Script Editor</h1>
          <p className="text-gray-600">
            Episode: {currentEpisode.title} • Right-click anywhere to add elements
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Button variant="outline" onClick={() => setIsPreviewMode(!isPreviewMode)}>
            <Eye className="w-4 h-4 mr-2" />
            {isPreviewMode ? 'Edit Mode' : 'Preview'}
          </Button>
          
          <Button variant="outline" onClick={exportScript}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          
          <Button>
            <Save className="w-4 h-4 mr-2" />
            Save Script
          </Button>
        </div>
      </div>

      {/* Script Statistics */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{scriptElements.length}</div>
              <div className="text-sm text-gray-500">Elements</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                {scriptElements.filter(e => e.type === 'scene_heading').length}
              </div>
              <div className="text-sm text-gray-500">Scenes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">
                {new Set(scriptElements.filter(e => e.type === 'character').map(e => e.content)).size}
              </div>
              <div className="text-sm text-gray-500">Characters</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">
                {Math.ceil(scriptElements.length / 25)}
              </div>
              <div className="text-sm text-gray-500">Est. Pages</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">
                {Math.ceil(scriptElements.length * 0.5)}min
              </div>
              <div className="text-sm text-gray-500">Est. Runtime</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Script Editor */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5" />
            Professional Script Editor
            <Badge variant="secondary" className="ml-2">
              Right-click to add elements
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            ref={scriptAreaRef}
            className="space-y-4 min-h-[400px] p-4 bg-white rounded-lg border-2 border-dashed border-gray-200"
            onContextMenu={(e) => handleRightClick(e)}
          >
            {scriptElements.map((element, index) => (
              <div
                key={element.id}
                className={`group relative ${selectedElementIndex === index ? 'ring-2 ring-blue-500 ring-opacity-50' : ''}`}
                onClick={() => setSelectedElementIndex(index)}
                onContextMenu={(e) => {
                  e.stopPropagation();
                  handleRightClick(e, index);
                }}
              >
                {/* Element Type Badge */}
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-xs">
                    {element.type.replace('_', ' ').toUpperCase()}
                  </Badge>
                  {index === selectedElementIndex && (
                    <span className="text-xs text-gray-500">
                      ← Selected (right-click for options)
                    </span>
                  )}
                </div>

                {/* Content Input */}
                <Textarea
                  value={element.content}
                  onChange={(e) => updateElement(index, e.target.value)}
                  placeholder={getElementPlaceholder(element.type)}
                  className={getElementStyle(element.type, element.formatting)}
                  rows={element.content.length > 100 ? 3 : 1}
                  style={{
                    fontWeight: element.formatting?.bold ? 'bold' : 'normal',
                    fontStyle: element.formatting?.italic ? 'italic' : 'normal',
                    textDecoration: element.formatting?.underline ? 'underline' : 'none'
                  }}
                />
              </div>
            ))}

            {/* Add Element Area */}
            <div 
              className="p-8 border-2 border-dashed border-gray-300 rounded-lg text-center text-gray-500 hover:border-blue-400 hover:text-blue-600 transition-colors cursor-pointer"
              onContextMenu={(e) => handleRightClick(e)}
              onClick={(e) => handleRightClick(e as any)}
            >
              <Plus className="w-8 h-8 mx-auto mb-2" />
              <p className="font-medium">Right-click anywhere to add script elements</p>
              <p className="text-sm">Scene headings, actions, dialogue, characters, transitions...</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Context Menu */}
      <ScriptContextMenu
        isVisible={contextMenu.isVisible}
        position={contextMenu.position}
        onClose={handleContextMenuClose}
        onElementSelect={handleElementSelect}
        onAction={handleQuickAction}
        savedCharacters={savedCharacters}
        savedLocations={savedLocations}
      />
    </div>
  );
};

export default ProfessionalScriptEditor;
