import React, { useState, useEffect } from 'react';
import { Image, Wand2, Loader2, Play, Settings, Eye, Plus, Trash2, RotateCcw, ChevronLeft, ChevronRight, Maximize, Volume2, Clock, Camera, Film, Palette } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import { Slider } from '../ui/slider';
import { Separator } from '../ui/separator';
import { useStoryboardStore } from '../../store/storyboardStore';
import { VisualStyle, CameraAngle, CameraMovement, Transition, Shot } from '../../types';
import { toast } from 'sonner';
import { cn } from '../../lib/utils';

const StoryboardEditor: React.FC = () => {
  const {
    currentProject,
    selectedShot,
    isGenerating,
    setSelectedShot,
    updateShot,
    generateImage,
    regenerateImage,
    addShot,
    deleteShot,
    setCurrentView
  } = useStoryboardStore();

  const [selectedStyle, setSelectedStyle] = useState<VisualStyle>('cinematic');
  const [currentShotIndex, setCurrentShotIndex] = useState(0);
  const [sidebarTab, setSidebarTab] = useState<'details' | 'camera' | 'ai'>('details');

  // Get all shots from current project
  const allShots = currentProject?.episodes
    ?.flatMap(episode => episode.scenes)
    ?.flatMap(scene => scene.shots) || [];

  const currentShot = allShots[currentShotIndex] || null;

  // Auto-select current shot
  useEffect(() => {
    if (currentShot && currentShot !== selectedShot) {
      setSelectedShot(currentShot);
    }
  }, [currentShot, selectedShot, setSelectedShot]);

  const navigateShot = (direction: 'prev' | 'next') => {
    if (direction === 'prev' && currentShotIndex > 0) {
      setCurrentShotIndex(currentShotIndex - 1);
    } else if (direction === 'next' && currentShotIndex < allShots.length - 1) {
      setCurrentShotIndex(currentShotIndex + 1);
    }
  };

  const handleGenerateImage = async () => {
    if (!currentShot) return;
    try {
      await generateImage(currentShot.id, currentShot.description, selectedStyle);
      toast.success('Image generated successfully!');
    } catch (error) {
      toast.error('Failed to generate image');
    }
  };

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full bg-background">
        <div className="text-center space-y-4">
          <Image className="w-16 h-16 mx-auto text-muted-foreground" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">No Project Selected</h3>
            <p className="text-muted-foreground">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  if (allShots.length === 0) {
    return (
      <div className="p-6 flex items-center justify-center h-full bg-background">
        <div className="text-center space-y-4">
          <Film className="w-16 h-16 mx-auto text-muted-foreground" />
          <div>
            <h3 className="text-lg font-semibold text-foreground">No Shots Available</h3>
            <p className="text-muted-foreground">Import a script to create storyboard shots</p>
          </div>
          <Button onClick={() => setCurrentView('script-import')}>
            Import Script
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Main Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Central Storyboard Panel */}
        <div className="flex-1 flex flex-col bg-card border-r border-border">
          {/* Top Toolbar */}
          <div className="flex items-center justify-between p-4 border-b border-border bg-card/50">
            <div className="flex items-center space-x-4">
              <h2 className="text-lg font-semibold text-foreground">
                Shot {currentShotIndex + 1} of {allShots.length}
              </h2>
              <Badge variant="secondary">
                {currentShot?.cameraAngle || 'Medium Shot'}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigateShot('prev')}
                disabled={currentShotIndex === 0}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => navigateShot('next')}
                disabled={currentShotIndex >= allShots.length - 1}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Separator orientation="vertical" className="h-6" />
              <Button variant="outline" size="sm">
                <Maximize className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm">
                <Play className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Main Storyboard Display */}
          <div className="flex-1 flex items-center justify-center p-8 bg-muted/20">
            <div className="relative max-w-4xl w-full aspect-video bg-card border-2 border-dashed border-border rounded-lg overflow-hidden">
              {currentShot?.imageUrl ? (
                <img 
                  src={currentShot.imageUrl} 
                  alt={`Shot ${currentShotIndex + 1}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
                  <Image className="w-24 h-24 mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Image Generated</h3>
                  <p className="text-center mb-4 max-w-md">
                    {currentShot?.description || 'Click "Generate Image" to create a visual for this shot.'}
                  </p>
                  <Button 
                    onClick={handleGenerateImage}
                    disabled={isGenerating}
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {isGenerating ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Wand2 className="w-4 h-4 mr-2" />
                    )}
                    Generate Image
                  </Button>
                </div>
              )}
              
              {/* Shot overlay info */}
              {currentShot && (
                <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 text-sm">
                  <div className="font-medium text-foreground">{currentShot.description}</div>
                  {currentShot.voiceOver && (
                    <div className="text-muted-foreground mt-1 flex items-center">
                      <Volume2 className="w-3 h-3 mr-1" />
                      {currentShot.voiceOver}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Sidebar Panel */}
        <div className="w-80 bg-card border-r border-border flex flex-col">
          {/* Sidebar Header */}
          <div className="p-4 border-b border-border">
            <h3 className="font-semibold text-foreground mb-3">Shot Controls</h3>
            <div className="flex space-x-1 bg-muted rounded-lg p-1">
              <Button
                variant={sidebarTab === 'details' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setSidebarTab('details')}
                className="flex-1"
              >
                Details
              </Button>
              <Button
                variant={sidebarTab === 'camera' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setSidebarTab('camera')}
                className="flex-1"
              >
                Camera
              </Button>
              <Button
                variant={sidebarTab === 'ai' ? 'secondary' : 'ghost'}
                size="sm"
                onClick={() => setSidebarTab('ai')}
                className="flex-1"
              >
                AI
              </Button>
            </div>
          </div>

          {/* Sidebar Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {sidebarTab === 'details' && currentShot && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="description">Shot Description</Label>
                  <Textarea
                    id="description"
                    value={currentShot.description}
                    onChange={(e) => updateShot(currentShot.id, { description: e.target.value })}
                    placeholder="Describe the shot..."
                    className="min-h-20"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="voiceover">Voice Over</Label>
                  <Textarea
                    id="voiceover"
                    value={currentShot.voiceOver || ''}
                    onChange={(e) => updateShot(currentShot.id, { voiceOver: e.target.value })}
                    placeholder="Voice over text..."
                    className="min-h-16"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (seconds)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={currentShot.duration || 3}
                    onChange={(e) => updateShot(currentShot.id, { duration: parseInt(e.target.value) })}
                    min="1"
                    max="60"
                  />
                </div>
              </>
            )}

            {sidebarTab === 'camera' && currentShot && (
              <>
                <div className="space-y-2">
                  <Label>Camera Angle</Label>
                  <Select
                    value={currentShot.cameraAngle}
                    onValueChange={(value) => updateShot(currentShot.id, { cameraAngle: value as CameraAngle })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="extreme_wide_shot">Extreme Wide Shot</SelectItem>
                      <SelectItem value="wide_shot">Wide Shot</SelectItem>
                      <SelectItem value="medium_shot">Medium Shot</SelectItem>
                      <SelectItem value="close_up">Close Up</SelectItem>
                      <SelectItem value="extreme_close_up">Extreme Close Up</SelectItem>
                      <SelectItem value="over_shoulder">Over Shoulder</SelectItem>
                      <SelectItem value="birds_eye">Bird's Eye</SelectItem>
                      <SelectItem value="worms_eye">Worm's Eye</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Camera Movement</Label>
                  <Select
                    value={currentShot.cameraMovement || 'static'}
                    onValueChange={(value) => updateShot(currentShot.id, { cameraMovement: value as CameraMovement })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="static">Static</SelectItem>
                      <SelectItem value="pan_left">Pan Left</SelectItem>
                      <SelectItem value="pan_right">Pan Right</SelectItem>
                      <SelectItem value="tilt_up">Tilt Up</SelectItem>
                      <SelectItem value="tilt_down">Tilt Down</SelectItem>
                      <SelectItem value="zoom_in">Zoom In</SelectItem>
                      <SelectItem value="zoom_out">Zoom Out</SelectItem>
                      <SelectItem value="dolly_in">Dolly In</SelectItem>
                      <SelectItem value="dolly_out">Dolly Out</SelectItem>
                      <SelectItem value="tracking">Tracking</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Transition</Label>
                  <Select
                    value={currentShot.transition || 'cut'}
                    onValueChange={(value) => updateShot(currentShot.id, { transition: value as Transition })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cut">Cut</SelectItem>
                      <SelectItem value="fade_in">Fade In</SelectItem>
                      <SelectItem value="fade_out">Fade Out</SelectItem>
                      <SelectItem value="dissolve">Dissolve</SelectItem>
                      <SelectItem value="wipe">Wipe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {sidebarTab === 'ai' && (
              <>
                <div className="space-y-2">
                  <Label>Visual Style</Label>
                  <Select
                    value={selectedStyle}
                    onValueChange={(value) => setSelectedStyle(value as VisualStyle)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="photorealistic">Photorealistic</SelectItem>
                      <SelectItem value="cinematic">Cinematic</SelectItem>
                      <SelectItem value="animated">Animated</SelectItem>
                      <SelectItem value="sketch">Sketch</SelectItem>
                      <SelectItem value="comic">Comic</SelectItem>
                      <SelectItem value="watercolor">Watercolor</SelectItem>
                      <SelectItem value="oil_painting">Oil Painting</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <Button 
                    onClick={handleGenerateImage}
                    disabled={isGenerating || !currentShot}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {isGenerating ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Wand2 className="w-4 h-4 mr-2" />
                    )}
                    Generate Image
                  </Button>

                  {currentShot?.imageUrl && (
                    <Button 
                      variant="outline"
                      onClick={() => regenerateImage(currentShot.id)}
                      disabled={isGenerating}
                      className="w-full"
                    >
                      <RotateCcw className="w-4 h-4 mr-2" />
                      Regenerate
                    </Button>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Filmstrip */}
      <div className="h-24 bg-card border-t border-border p-2">
        <div className="flex space-x-2 overflow-x-auto h-full">
          {allShots.map((shot, index) => (
            <div
              key={shot.id}
              onClick={() => setCurrentShotIndex(index)}
              className={cn(
                "flex-shrink-0 w-20 h-full bg-muted border-2 rounded cursor-pointer transition-all hover:border-primary/50",
                index === currentShotIndex ? "border-primary" : "border-border"
              )}
            >
              {shot.imageUrl ? (
                <img 
                  src={shot.imageUrl} 
                  alt={`Shot ${index + 1}`}
                  className="w-full h-full object-cover rounded"
                />
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <Image className="w-6 h-6" />
                </div>
              )}
              <div className="absolute bottom-0 left-0 right-0 bg-background/90 text-xs text-center py-1 rounded-b">
                {index + 1}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default StoryboardEditor;
