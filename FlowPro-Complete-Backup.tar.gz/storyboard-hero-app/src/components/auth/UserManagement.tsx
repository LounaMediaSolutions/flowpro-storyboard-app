import React, { useState } from 'react';
import { Users, UserPlus, Edit2, Trash2, Shield, Mail, Phone, Calendar, Settings } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Switch } from '../ui/switch';
import { Checkbox } from '../ui/checkbox';
import { useStoryboardStore } from '../../store/storyboardStore';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

const UserManagement: React.FC = () => {
  const { setCurrentView } = useStoryboardStore();
  
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    role: 'crew' as const,
    department: '',
    permissions: [] as string[]
  });

  // Mock users data
  const [users] = useState([
    {
      id: '1',
      name: 'Sarah Chen',
      email: 'sarah@flowpro.com',
      role: 'director' as const,
      department: 'Creative',
      permissions: ['project_create', 'project_edit', 'script_edit', 'storyboard_create', 'production_manage'],
      avatar: '/images/director.jpg',
      isActive: true,
      lastLogin: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) // 30 days ago
    },
    {
      id: '2',
      name: 'Marcus Johnson',
      email: 'marcus@flowpro.com',
      role: 'cinematographer' as const,
      department: 'Camera',
      permissions: ['storyboard_edit', 'production_manage', 'reports_view'],
      avatar: '/images/camera-production.jpg',
      isActive: true,
      lastLogin: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000) // 15 days ago
    },
    {
      id: '3',
      name: 'Emma Rodriguez',
      email: 'emma@flowpro.com',
      role: 'producer' as const,
      department: 'Production',
      permissions: ['project_edit', 'budget_view', 'budget_edit', 'production_manage', 'reports_view'],
      avatar: '/images/creative-team.webp',
      isActive: true,
      lastLogin: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
      createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000) // 45 days ago
    },
    {
      id: '4',
      name: 'Alex Thompson',
      email: 'alex@flowpro.com',
      role: 'editor' as const,
      department: 'Post-Production',
      permissions: ['storyboard_edit', 'export_all', 'reports_view'],
      avatar: '/images/digital-storyboard.jpg',
      isActive: false,
      lastLogin: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
      createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000) // 20 days ago
    }
  ]);

  const roleDefinitions = {
    admin: {
      label: 'Administrator',
      color: 'bg-red-500',
      permissions: ['project_create', 'project_edit', 'project_delete', 'users_manage', 'budget_edit', 'production_manage', 'export_all']
    },
    director: {
      label: 'Director',
      color: 'bg-purple-500',
      permissions: ['project_edit', 'script_edit', 'storyboard_create', 'storyboard_edit', 'production_manage', 'reports_view']
    },
    producer: {
      label: 'Producer',
      color: 'bg-blue-500',
      permissions: ['project_edit', 'budget_view', 'budget_edit', 'production_manage', 'reports_view', 'export_all']
    },
    cinematographer: {
      label: 'Cinematographer',
      color: 'bg-green-500',
      permissions: ['storyboard_edit', 'production_manage', 'reports_view']
    },
    editor: {
      label: 'Editor',
      color: 'bg-orange-500',
      permissions: ['storyboard_edit', 'export_all', 'reports_view']
    },
    actor: {
      label: 'Actor',
      color: 'bg-pink-500',
      permissions: ['script_edit', 'reports_view']
    },
    crew: {
      label: 'Crew',
      color: 'bg-gray-500',
      permissions: ['reports_view']
    }
  };

  const allPermissions = [
    { id: 'project_create', label: 'Create Projects', category: 'Project' },
    { id: 'project_edit', label: 'Edit Projects', category: 'Project' },
    { id: 'project_delete', label: 'Delete Projects', category: 'Project' },
    { id: 'episode_create', label: 'Create Episodes', category: 'Content' },
    { id: 'episode_edit', label: 'Edit Episodes', category: 'Content' },
    { id: 'script_import', label: 'Import Scripts', category: 'Content' },
    { id: 'script_edit', label: 'Edit Scripts', category: 'Content' },
    { id: 'storyboard_create', label: 'Create Storyboards', category: 'Content' },
    { id: 'storyboard_edit', label: 'Edit Storyboards', category: 'Content' },
    { id: 'budget_view', label: 'View Budget', category: 'Finance' },
    { id: 'budget_edit', label: 'Edit Budget', category: 'Finance' },
    { id: 'production_manage', label: 'Manage Production', category: 'Production' },
    { id: 'reports_view', label: 'View Reports', category: 'Reports' },
    { id: 'users_manage', label: 'Manage Users', category: 'Admin' },
    { id: 'export_all', label: 'Export All Formats', category: 'Export' }
  ];

  const handleAddUser = () => {
    if (!newUser.name.trim() || !newUser.email.trim()) {
      toast.error('Please fill in required fields');
      return;
    }

    toast.success('User added successfully!');
    setIsAddUserOpen(false);
    setNewUser({
      name: '',
      email: '',
      role: 'crew',
      department: '',
      permissions: []
    });
  };

  const getRoleInfo = (role: string) => {
    return roleDefinitions[role as keyof typeof roleDefinitions] || roleDefinitions.crew;
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">User Management</h1>
          <p className="text-gray-600">Manage team members and their access permissions</p>
        </div>

        <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <UserPlus className="w-4 h-4 mr-2" />
              <span className="hidden sm:inline">Add User</span>
              <span className="sm:hidden">Add</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="user-name">Full Name</Label>
                <Input
                  id="user-name"
                  placeholder="Enter full name..."
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="user-email">Email Address</Label>
                <Input
                  id="user-email"
                  type="email"
                  placeholder="user@example.com"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="user-role">Role</Label>
                  <Select
                    value={newUser.role}
                    onValueChange={(value) => setNewUser({ ...newUser, role: value as any })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(roleDefinitions).map(([key, role]) => (
                        <SelectItem key={key} value={key}>
                          {role.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="user-department">Department</Label>
                  <Select
                    value={newUser.department}
                    onValueChange={(value) => setNewUser({ ...newUser, department: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select department" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Creative">Creative</SelectItem>
                      <SelectItem value="Production">Production</SelectItem>
                      <SelectItem value="Camera">Camera</SelectItem>
                      <SelectItem value="Audio">Audio</SelectItem>
                      <SelectItem value="Lighting">Lighting</SelectItem>
                      <SelectItem value="Post-Production">Post-Production</SelectItem>
                      <SelectItem value="Art">Art Department</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3">
                <Label>Permissions</Label>
                <div className="max-h-48 overflow-y-auto border rounded-lg p-3 space-y-3">
                  {Object.entries(
                    allPermissions.reduce((acc, perm) => {
                      if (!acc[perm.category]) acc[perm.category] = [];
                      acc[perm.category].push(perm);
                      return acc;
                    }, {} as Record<string, typeof allPermissions>)
                  ).map(([category, perms]) => (
                    <div key={category}>
                      <div className="font-medium text-sm text-gray-900 mb-2">{category}</div>
                      <div className="space-y-2">
                        {perms.map((perm) => (
                          <div key={perm.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={perm.id}
                              checked={newUser.permissions.includes(perm.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setNewUser({
                                    ...newUser,
                                    permissions: [...newUser.permissions, perm.id]
                                  });
                                } else {
                                  setNewUser({
                                    ...newUser,
                                    permissions: newUser.permissions.filter(p => p !== perm.id)
                                  });
                                }
                              }}
                            />
                            <Label htmlFor={perm.id} className="text-sm">
                              {perm.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setIsAddUserOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddUser}>Add User</Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.length}</div>
            <p className="text-xs text-muted-foreground">Active team members</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{users.filter(u => u.isActive).length}</div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Roles</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{new Set(users.map(u => u.role)).size}</div>
            <p className="text-xs text-muted-foreground">Different roles</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Departments</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{new Set(users.map(u => u.department)).size}</div>
            <p className="text-xs text-muted-foreground">Active departments</p>
          </CardContent>
        </Card>
      </div>

      {/* Users Management */}
      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="roles">Roles</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {users.map((user) => {
              const roleInfo = getRoleInfo(user.role);
              return (
                <Card key={user.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={user.avatar} alt={user.name} />
                          <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-lg">{user.name}</CardTitle>
                          <p className="text-sm text-gray-600">{user.department}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Button variant="ghost" size="sm">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" className="text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Badge className={`${roleInfo.color} text-white`}>
                        {roleInfo.label}
                      </Badge>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${user.isActive ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                        <span className="text-sm text-gray-600">
                          {user.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2">
                        <Mail className="w-3 h-3 text-gray-400" />
                        <span className="text-gray-600 truncate">{user.email}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3 h-3 text-gray-400" />
                        <span className="text-gray-600">
                          Last login: {formatDistanceToNow(user.lastLogin, { addSuffix: true })}
                        </span>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm font-medium text-gray-900 mb-2">Permissions</div>
                      <div className="flex flex-wrap gap-1">
                        {user.permissions.slice(0, 3).map((permission) => (
                          <Badge key={permission} variant="outline" className="text-xs">
                            {allPermissions.find(p => p.id === permission)?.label}
                          </Badge>
                        ))}
                        {user.permissions.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{user.permissions.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="roles" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(roleDefinitions).map(([key, role]) => (
              <Card key={key}>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <div className={`w-4 h-4 rounded-full ${role.color}`}></div>
                    <span>{role.label}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="text-sm font-medium mb-2">Users with this role</div>
                      <div className="text-2xl font-bold">
                        {users.filter(u => u.role === key).length}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-2">Default Permissions</div>
                      <div className="space-y-1">
                        {role.permissions.slice(0, 4).map((permission) => (
                          <div key={permission} className="text-xs text-gray-600">
                            • {allPermissions.find(p => p.id === permission)?.label}
                          </div>
                        ))}
                        {role.permissions.length > 4 && (
                          <div className="text-xs text-gray-500">
                            +{role.permissions.length - 4} more permissions
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <div className="space-y-6">
            {Object.entries(
              allPermissions.reduce((acc, perm) => {
                if (!acc[perm.category]) acc[perm.category] = [];
                acc[perm.category].push(perm);
                return acc;
              }, {} as Record<string, typeof allPermissions>)
            ).map(([category, perms]) => (
              <Card key={category}>
                <CardHeader>
                  <CardTitle>{category} Permissions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {perms.map((perm) => (
                      <div key={perm.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">{perm.label}</div>
                          <div className="text-sm text-gray-600">
                            Used by {users.filter(u => u.permissions.includes(perm.id)).length} users
                          </div>
                        </div>
                        <Badge variant="outline">
                          {perm.id}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default UserManagement;
