import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { auth } from '../../lib/supabase';
import { toast } from '../../hooks/use-toast';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signUp: (email: string, password: string, metadata?: any) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<{ error: any }>;
  resetPassword: (email: string) => Promise<{ error: any }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if we have valid Supabase configuration
    const hasSupabaseConfig = import.meta.env.VITE_SUPABASE_URL && 
                             import.meta.env.VITE_SUPABASE_ANON_KEY &&
                             import.meta.env.VITE_SUPABASE_URL !== 'https://your-project.supabase.co';
    
    // Demo mode only if no real Supabase config is provided
    const demoMode = !hasSupabaseConfig && window.location.hostname.includes('minimax.io');
    
    if (demoMode) {
      // Simulate demo user for demonstration
      console.log('Running in demo mode - Supabase not configured');
      const demoUser = {
        id: 'demo-user-123',
        email: 'demo@flowpro.com',
        user_metadata: {
          full_name: 'Demo User',
          company: 'FlowPro Studios'
        }
      } as any;
      
      setUser(demoUser);
      setLoading(false);
      return;
    }

    // Get initial session (real Supabase)
    const getInitialSession = async () => {
      try {
        const { user, error } = await auth.getCurrentUser();
        if (error) {
          console.error('Error getting initial session:', error);
        } else {
          setUser(user);
        }
      } catch (error) {
        console.error('Supabase connection error:', error);
      }
      setLoading(false);
    };

    getInitialSession();

    // Listen for auth changes
    const { data: { subscription } } = auth.onAuthChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);

        switch (event) {
          case 'SIGNED_IN':
            toast({
              title: "Welcome back!",
              description: "You have been successfully signed in.",
            });
            break;
          case 'SIGNED_OUT':
            toast({
              title: "Signed out",
              description: "You have been successfully signed out.",
            });
            break;
          case 'PASSWORD_RECOVERY':
            toast({
              title: "Password recovery",
              description: "Check your email for password reset instructions.",
            });
            break;
          case 'USER_UPDATED':
            toast({
              title: "Profile updated",
              description: "Your profile has been successfully updated.",
            });
            break;
        }
      }
    );

    return () => subscription?.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, metadata?: any) => {
    setLoading(true);
    const { data, error } = await auth.signUp(email, password, metadata);
    
    if (error) {
      toast({
        title: "Sign up failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Sign up successful",
        description: "Please check your email to verify your account.",
      });
    }
    
    setLoading(false);
    return { error };
  };

  const signIn = async (email: string, password: string) => {
    setLoading(true);
    const { data, error } = await auth.signIn(email, password);
    
    if (error) {
      toast({
        title: "Sign in failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setLoading(false);
    return { error };
  };

  const signOut = async () => {
    setLoading(true);
    const { error } = await auth.signOut();
    
    if (error) {
      toast({
        title: "Sign out failed",
        description: error.message,
        variant: "destructive",
      });
    }
    
    setLoading(false);
    return { error };
  };

  const resetPassword = async (email: string) => {
    const { error } = await auth.signOut(); // This should be reset password, but we'll implement it later
    
    if (error) {
      toast({
        title: "Password reset failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Password reset sent",
        description: "Check your email for password reset instructions.",
      });
    }
    
    return { error };
  };

  const value = {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    resetPassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
