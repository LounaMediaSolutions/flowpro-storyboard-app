import React, { useState } from 'react';
import { 
  Film, Users, MapPin, Shirt, Camera, Calendar, Clock, DollarSign, 
  BarChart3, FileText, Image, Download, Play, Settings, Plus,
  TrendingUp, AlertCircle, CheckCircle, Timer
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { useStoryboardStore } from '../../store/storyboardStore';
import { cn } from '../../lib/utils';
import CreateProjectDialog from './CreateProjectDialog';

interface ProductionStats {
  totalCharacters: number;
  totalLocations: number;
  totalAccessories: number;
  totalShootingDays: number;
  totalEquipment: number;
  totalStaff: number;
  estimatedBudget: number;
  totalScenes: number;
  totalShots: number;
  estimatedDuration: number;
}

const ProfessionalDashboard: React.FC = () => {
  const { currentProject, projects, setCurrentProject, setCurrentView } = useStoryboardStore();
  const [selectedTab, setSelectedTab] = useState<'overview' | 'analytics' | 'breakdown'>('overview');

  const calculateProductionStats = (project: any): ProductionStats => {
    if (!project) {
      return {
        totalCharacters: 0,
        totalLocations: 0,
        totalAccessories: 0,
        totalShootingDays: 0,
        totalEquipment: 0,
        totalStaff: 0,
        estimatedBudget: 0,
        totalScenes: 0,
        totalShots: 0,
        estimatedDuration: 0
      };
    }

    const totalScenes = project.episodes?.reduce((acc: number, ep: any) => acc + (ep.scenes?.length || 0), 0) || 0;
    const totalShots = project.episodes?.reduce((acc: number, ep: any) => 
      acc + (ep.scenes?.reduce((sceneAcc: number, scene: any) => sceneAcc + (scene.shots?.length || 0), 0) || 0), 0) || 0;

    return {
      totalCharacters: project.characters?.length || 0,
      totalLocations: project.locations?.length || 0,
      totalAccessories: 45, // Mock data
      totalShootingDays: Math.ceil(totalScenes / 3), // Estimate 3 scenes per day
      totalEquipment: 28, // Mock data
      totalStaff: 15, // Mock data
      estimatedBudget: totalScenes * 5000, // $5k per scene estimate
      totalScenes,
      totalShots,
      estimatedDuration: totalShots * 2 // 2 minutes per shot estimate
    };
  };

  const currentStats = calculateProductionStats(currentProject);

  if (!currentProject) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Production Dashboard</h1>
            <p className="text-muted-foreground">Select a project to view comprehensive production analytics</p>
          </div>
          <CreateProjectDialog />
        </div>

        {projects.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card 
                key={project.id} 
                className="cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => setCurrentProject(project)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{project.title}</span>
                    <Badge variant="outline">{project.projectType}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Episodes:</span>
                      <span>{project.episodes?.length || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Scenes:</span>
                      <span>{calculateProductionStats(project).totalScenes}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Characters:</span>
                      <span>{project.characters?.length || 0}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mb-4">
              <Film className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-2">No Projects Yet</h3>
            <p className="text-muted-foreground mb-4 max-w-md">
              Get started by creating your first film production project. You can create feature films, TV series, or short films.
            </p>
            <div className="flex flex-col space-y-3">
              <CreateProjectDialog>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Your First Project
                </Button>
              </CreateProjectDialog>
              
              <Button 
                onClick={() => setCurrentView('settings')}
                variant="outline"
                className="bg-green-50 border-green-500 text-green-700 hover:bg-green-100 font-bold"
              >
                <Settings className="w-4 h-4 mr-2" />
                ⚙️ CONFIGURE API SETTINGS
              </Button>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">{currentProject.title}</h1>
          <p className="text-muted-foreground">
            {currentProject.projectType} • {currentProject.episodes?.length || 0} Episodes
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Badge variant="outline" className="flex items-center space-x-1">
            <Timer className="w-3 h-3" />
            <span>{currentStats.estimatedDuration}min</span>
          </Badge>
          <Badge variant="outline" className="flex items-center space-x-1">
            <DollarSign className="w-3 h-3" />
            <span>${currentStats.estimatedBudget.toLocaleString()}</span>
          </Badge>
          <Button 
            onClick={() => setCurrentView('settings')}
            variant="outline"
            className="bg-green-50 border-green-500 text-green-700 hover:bg-green-100 font-bold"
          >
            <Settings className="w-4 h-4 mr-2" />
            ⚙️ API SETTINGS
          </Button>
          <Button onClick={() => setCurrentView('episodes')}>
            View Episodes
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as any)} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Production Overview</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="breakdown">Scene Breakdown</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Production Statistics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <div className="text-2xl font-bold">{currentStats.totalCharacters}</div>
                <div className="text-xs text-muted-foreground">Characters</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <MapPin className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <div className="text-2xl font-bold">{currentStats.totalLocations}</div>
                <div className="text-xs text-muted-foreground">Locations</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Shirt className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <div className="text-2xl font-bold">{currentStats.totalAccessories}</div>
                <div className="text-xs text-muted-foreground">Accessories</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Calendar className="w-8 h-8 mx-auto mb-2 text-orange-600" />
                <div className="text-2xl font-bold">{currentStats.totalShootingDays}</div>
                <div className="text-xs text-muted-foreground">Shooting Days</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Camera className="w-8 h-8 mx-auto mb-2 text-red-600" />
                <div className="text-2xl font-bold">{currentStats.totalEquipment}</div>
                <div className="text-xs text-muted-foreground">Equipment</div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 text-center">
                <Users className="w-8 h-8 mx-auto mb-2 text-indigo-600" />
                <div className="text-2xl font-bold">{currentStats.totalStaff}</div>
                <div className="text-xs text-muted-foreground">Staff Needed</div>
              </CardContent>
            </Card>
          </div>

          {/* Comprehensive Report */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Complete Production Report
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-primary/10 p-6 rounded-lg">
                <h3 className="text-lg font-semibold mb-4">Series Production Summary</h3>
                <div className="prose prose-sm max-w-none">
                  <p>
                    <strong>Complete report of the series:</strong> This {currentProject.projectType} project 
                    contains {currentProject.episodes?.length || 0} episodes with a total of{' '}
                    <strong>{currentStats.totalCharacters} characters</strong>,{' '}
                    <strong>{currentStats.totalLocations} locations</strong>,{' '}
                    <strong>{currentStats.totalAccessories} accessories</strong>, and requires{' '}
                    <strong>{currentStats.totalShootingDays} days of shooting</strong>.
                  </p>
                  <p>
                    <strong>Equipment needed:</strong> {currentStats.totalEquipment} pieces of equipment 
                    including cameras, lighting, audio, and specialized gear.
                  </p>
                  <p>
                    <strong>Staff needed:</strong> {currentStats.totalStaff} crew members including 
                    director, cinematographer, sound engineer, lighting technician, script supervisor, 
                    and production assistants.
                  </p>
                  <p>
                    <strong>Production timeline:</strong> {currentStats.totalScenes} scenes across 
                    {currentStats.totalShots} shots with an estimated total duration of{' '}
                    {Math.floor(currentStats.estimatedDuration / 60)}h {currentStats.estimatedDuration % 60}m.
                  </p>
                  <p>
                    <strong>Estimated budget:</strong> ${currentStats.estimatedBudget.toLocaleString()} 
                    covering pre-production, production, and post-production phases.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Episodes Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Episodes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {currentProject.episodes?.map((episode, index) => (
                  <Card key={episode.id} className="border-l-4 border-l-primary">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold">Episode {episode.episodeNumber}</h4>
                        <Badge variant="outline">{episode.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3">{episode.title}</p>
                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span>Scenes:</span>
                          <span>{episode.scenes?.length || 0}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Shots:</span>
                          <span>
                            {episode.scenes?.reduce((acc, scene) => acc + (scene.shots?.length || 0), 0) || 0}
                          </span>
                        </div>
                        {episode.targetDuration && (
                          <div className="flex justify-between">
                            <span>Target:</span>
                            <span>{episode.targetDuration}min</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* Analytics Charts and Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Production Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Script Development</span>
                    <span>85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Storyboard Creation</span>
                    <span>60%</span>
                  </div>
                  <Progress value={60} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Pre-Production</span>
                    <span>40%</span>
                  </div>
                  <Progress value={40} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Production</span>
                    <span>0%</span>
                  </div>
                  <Progress value={0} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Budget Allocation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Pre-Production</span>
                    <span className="font-semibold">${(currentStats.estimatedBudget * 0.2).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Production</span>
                    <span className="font-semibold">${(currentStats.estimatedBudget * 0.5).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Post-Production</span>
                    <span className="font-semibold">${(currentStats.estimatedBudget * 0.3).toLocaleString()}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Resource Allocation */}
          <Card>
            <CardHeader>
              <CardTitle>Resource Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <h4 className="font-semibold mb-3">Characters by Episode</h4>
                  <div className="space-y-2">
                    {currentProject.episodes?.map((episode, index) => (
                      <div key={episode.id} className="flex justify-between text-sm">
                        <span>Episode {episode.episodeNumber}</span>
                        <span>{Math.floor(Math.random() * 5) + 2} characters</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Locations by Type</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Interior</span>
                      <span>{Math.floor(currentStats.totalLocations * 0.6)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Exterior</span>
                      <span>{Math.floor(currentStats.totalLocations * 0.4)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Studio</span>
                      <span>{Math.floor(currentStats.totalLocations * 0.2)}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">Equipment Categories</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Camera</span>
                      <span>8 items</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Lighting</span>
                      <span>12 items</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Audio</span>
                      <span>6 items</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Grip</span>
                      <span>2 items</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="breakdown" className="space-y-6">
          {/* Scene Breakdown Grid - Similar to Final Draft Import */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Scene Breakdown Analysis</span>
                <div className="flex items-center space-x-4 text-sm">
                  <Badge variant="outline">{currentStats.totalScenes} Scenes</Badge>
                  <Badge variant="outline">{currentStats.totalCharacters} Characters</Badge>
                  <Badge variant="outline">{currentStats.totalLocations} Locations</Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 p-4 bg-muted rounded-lg">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-primary">{currentStats.totalShots}</div>
                    <div className="text-sm text-muted-foreground">Total Shots</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">
                      {currentStats.totalScenes > 0 ? (currentStats.totalShots / currentStats.totalScenes).toFixed(1) : 0}
                    </div>
                    <div className="text-sm text-muted-foreground">Avg. Shots/Scene</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-primary">{currentStats.estimatedDuration}</div>
                    <div className="text-sm text-muted-foreground">Est. Duration (min)</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {currentProject.episodes?.map((episode) =>
                  episode.scenes?.map((scene, sceneIndex) => (
                    <Card key={scene.id} className="border-l-4 border-l-primary/30">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-sm">Scene {scene.sceneNumber}</h4>
                          <Badge variant="outline" className="text-xs">
                            {scene.shots?.length || 0} shots
                          </Badge>
                        </div>
                        <div className="text-xs text-muted-foreground mb-3">
                          <div className="font-medium">{scene.location || 'Unknown Location'}</div>
                          <div>{scene.timeOfDay?.toUpperCase()}</div>
                        </div>
                        <div className="space-y-1 text-xs">
                          {scene.shots?.map((shot, shotIndex) => (
                            <div key={shot.id} className="p-1 bg-muted/50 rounded text-xs">
                              {shotIndex + 1}. {shot.description}
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfessionalDashboard;
