import React, { useState } from 'react';
import { Button } from '../ui/button';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Plus, Film, Tv, Camera } from 'lucide-react';
import { useStoryboardStore } from '../../store/storyboardStore';
import { useToast } from '../../hooks/use-toast';

interface CreateProjectDialogProps {
  children?: React.ReactNode;
}

const CreateProjectDialog: React.FC<CreateProjectDialogProps> = ({ children }) => {
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  
  const { createProject, setCurrentView } = useStoryboardStore();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim()) {
      toast({
        title: "Error",
        description: "Please enter a project title",
        variant: "destructive"
      });
      return;
    }

    setIsCreating(true);
    
    try {
      // Create the project
      createProject(title.trim(), description.trim());
      
      // Show success message
      toast({
        title: "Project Created!",
        description: `"${title}" has been created successfully`,
      });
      
      // Reset form and close dialog
      setTitle('');
      setDescription('');
      setOpen(false);
      
      // Navigate to the new project
      setCurrentView('episodes');
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsCreating(false);
    }
  };

  const projectTemplates = [
    {
      title: "Feature Film",
      description: "Full-length narrative film project with comprehensive planning tools",
      icon: <Film className="h-4 w-4" />,
      template: {
        title: "New Feature Film",
        description: "A compelling feature film story"
      }
    },
    {
      title: "TV Series",
      description: "Multi-episode series with season and episode management",
      icon: <Tv className="h-4 w-4" />,
      template: {
        title: "New TV Series",
        description: "An engaging television series"
      }
    },
    {
      title: "Short Film",
      description: "Quick project setup for short-form content",
      icon: <Camera className="h-4 w-4" />,
      template: {
        title: "New Short Film",
        description: "A creative short film project"
      }
    }
  ];

  const useTemplate = (template: any) => {
    setTitle(template.title);
    setDescription(template.description);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button className="flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Create New Project
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Film className="h-5 w-5" />
            Create New Project
          </DialogTitle>
          <DialogDescription>
            Start a new film production project. Choose a template or create from scratch.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Project Templates */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Quick Templates</Label>
            <div className="grid grid-cols-1 gap-2">
              {projectTemplates.map((template, index) => (
                <button
                  key={index}
                  type="button"
                  onClick={() => useTemplate(template.template)}
                  className="flex items-start gap-3 p-3 text-left border rounded-lg hover:bg-muted transition-colors"
                >
                  <div className="mt-0.5">{template.icon}</div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm">{template.title}</div>
                    <div className="text-xs text-muted-foreground">{template.description}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Project Details */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Project Title</Label>
              <Input
                id="title"
                placeholder="Enter project title..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Brief description of your project..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isCreating || !title.trim()}
            >
              {isCreating ? 'Creating...' : 'Create Project'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateProjectDialog;
