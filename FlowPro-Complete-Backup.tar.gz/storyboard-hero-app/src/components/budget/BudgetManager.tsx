import React, { useState } from 'react';
import { DollarSign, Plus, Edit2, Trash2, PieChart, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { useStoryboardStore } from '../../store/storyboardStore';
import { BudgetCategory, BudgetItem, BudgetStatus } from '../../types';
import { toast } from 'sonner';

const BudgetManager: React.FC = () => {
  const {
    currentProject,
    updateProjectBudget,
    setCurrentView
  } = useStoryboardStore();

  const [isAddCategoryOpen, setIsAddCategoryOpen] = useState(false);
  const [isAddItemOpen, setIsAddItemOpen] = useState(false);
  const [newCategory, setNewCategory] = useState({ name: '', allocated: 0 });
  const [newItem, setNewItem] = useState({
    categoryId: '',
    name: '',
    description: '',
    unitCost: 0,
    quantity: 1,
    vendor: '',
    status: 'planned' as BudgetStatus
  });

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <DollarSign className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const budget = currentProject.budget || {
    totalBudget: 0,
    spent: 0,
    remaining: 0,
    categories: []
  };

  const handleAddCategory = () => {
    if (!newCategory.name.trim() || newCategory.allocated <= 0) {
      toast.error('Please enter a valid category name and budget');
      return;
    }

    const newCat: BudgetCategory = {
      id: Math.random().toString(36),
      name: newCategory.name.trim(),
      allocated: newCategory.allocated,
      spent: 0,
      items: []
    };

    const updatedBudget = {
      ...budget,
      categories: [...budget.categories, newCat],
      totalBudget: budget.totalBudget + newCategory.allocated
    };

    updatedBudget.remaining = updatedBudget.totalBudget - updatedBudget.spent;

    updateProjectBudget(currentProject.id, updatedBudget);
    setNewCategory({ name: '', allocated: 0 });
    setIsAddCategoryOpen(false);
    toast.success('Budget category added successfully!');
  };

  const handleAddItem = () => {
    if (!newItem.categoryId || !newItem.name.trim() || newItem.unitCost <= 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    const totalCost = newItem.unitCost * newItem.quantity;
    const item: BudgetItem = {
      id: Math.random().toString(36),
      categoryId: newItem.categoryId,
      name: newItem.name.trim(),
      description: newItem.description,
      unitCost: newItem.unitCost,
      quantity: newItem.quantity,
      totalCost,
      vendor: newItem.vendor,
      status: newItem.status
    };

    const updatedCategories = budget.categories.map(cat => 
      cat.id === newItem.categoryId 
        ? { ...cat, items: [...cat.items, item] }
        : cat
    );

    const updatedBudget = {
      ...budget,
      categories: updatedCategories
    };

    updateProjectBudget(currentProject.id, updatedBudget);
    setNewItem({
      categoryId: '',
      name: '',
      description: '',
      unitCost: 0,
      quantity: 1,
      vendor: '',
      status: 'planned'
    });
    setIsAddItemOpen(false);
    toast.success('Budget item added successfully!');
  };

  const getStatusColor = (status: BudgetStatus) => {
    switch (status) {
      case 'planned': return 'bg-gray-500';
      case 'approved': return 'bg-blue-500';
      case 'ordered': return 'bg-yellow-500';
      case 'received': return 'bg-purple-500';
      case 'paid': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: BudgetStatus) => {
    switch (status) {
      case 'planned': return 'Planned';
      case 'approved': return 'Approved';
      case 'ordered': return 'Ordered';
      case 'received': return 'Received';
      case 'paid': return 'Paid';
      default: return 'Unknown';
    }
  };

  const calculateCategorySpent = (category: BudgetCategory) => {
    return category.items.reduce((total, item) => {
      if (item.status === 'paid' || item.status === 'received') {
        return total + item.totalCost;
      }
      return total;
    }, 0);
  };

  const budgetUsedPercentage = budget.totalBudget > 0 ? (budget.spent / budget.totalBudget) * 100 : 0;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Budget Management</h1>
          <p className="text-gray-600">Track and manage project budget and expenses</p>
        </div>

        <div className="flex items-center space-x-3">
          <Dialog open={isAddCategoryOpen} onOpenChange={setIsAddCategoryOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Category
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Budget Category</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="category-name">Category Name</Label>
                  <Input
                    id="category-name"
                    placeholder="e.g., Pre-Production, Equipment..."
                    value={newCategory.name}
                    onChange={(e) => setNewCategory({ ...newCategory, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category-budget">Allocated Budget ($)</Label>
                  <Input
                    id="category-budget"
                    type="number"
                    placeholder="10000"
                    value={newCategory.allocated}
                    onChange={(e) => setNewCategory({ ...newCategory, allocated: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsAddCategoryOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddCategory}>Add Category</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isAddItemOpen} onOpenChange={setIsAddItemOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Item
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>Add Budget Item</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="item-category">Category</Label>
                  <Select
                    value={newItem.categoryId}
                    onValueChange={(value) => setNewItem({ ...newItem, categoryId: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {budget.categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="item-name">Item Name</Label>
                  <Input
                    id="item-name"
                    placeholder="e.g., Camera rental, Catering..."
                    value={newItem.name}
                    onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="item-description">Description</Label>
                  <Textarea
                    id="item-description"
                    placeholder="Item description..."
                    value={newItem.description}
                    onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="item-cost">Unit Cost ($)</Label>
                    <Input
                      id="item-cost"
                      type="number"
                      placeholder="100"
                      value={newItem.unitCost}
                      onChange={(e) => setNewItem({ ...newItem, unitCost: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="item-quantity">Quantity</Label>
                    <Input
                      id="item-quantity"
                      type="number"
                      placeholder="1"
                      value={newItem.quantity}
                      onChange={(e) => setNewItem({ ...newItem, quantity: parseInt(e.target.value) || 1 })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="item-vendor">Vendor (Optional)</Label>
                  <Input
                    id="item-vendor"
                    placeholder="Vendor name..."
                    value={newItem.vendor}
                    onChange={(e) => setNewItem({ ...newItem, vendor: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="item-status">Status</Label>
                  <Select
                    value={newItem.status}
                    onValueChange={(value) => setNewItem({ ...newItem, status: value as BudgetStatus })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="planned">Planned</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="ordered">Ordered</SelectItem>
                      <SelectItem value="received">Received</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsAddItemOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddItem}>
                    Add Item (${(newItem.unitCost * newItem.quantity).toLocaleString()})
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Budget Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Budget</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${budget.totalBudget.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Project allocation</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Spent</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${budget.spent.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">{budgetUsedPercentage.toFixed(1)}% of budget</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Remaining</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${budget.remaining.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Available funds</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Categories</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{budget.categories.length}</div>
            <p className="text-xs text-muted-foreground">Budget categories</p>
          </CardContent>
        </Card>
      </div>

      {/* Budget Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Budget Usage</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span>{budgetUsedPercentage.toFixed(1)}%</span>
            </div>
            <Progress value={budgetUsedPercentage} className="w-full" />
            {budgetUsedPercentage > 80 && (
              <div className="flex items-center space-x-2 text-amber-600">
                <AlertTriangle className="w-4 h-4" />
                <span className="text-sm">Budget usage is high</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Budget Categories */}
      <Tabs defaultValue="categories" className="space-y-6">
        <TabsList>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="items">All Items</TabsTrigger>
        </TabsList>

        <TabsContent value="categories" className="space-y-6">
          {budget.categories.length === 0 ? (
            <div className="text-center py-12">
              <PieChart className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No budget categories</h3>
              <p className="text-gray-600 mb-4">Create budget categories to organize your project expenses</p>
              <Button onClick={() => setIsAddCategoryOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Category
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {budget.categories.map((category) => {
                const spent = calculateCategorySpent(category);
                const usagePercentage = category.allocated > 0 ? (spent / category.allocated) * 100 : 0;

                return (
                  <Card key={category.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{category.name}</CardTitle>
                          <p className="text-sm text-gray-600 mt-1">
                            ${spent.toLocaleString()} / ${category.allocated.toLocaleString()}
                          </p>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Button variant="ghost" size="sm">
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>

                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Usage</span>
                          <span>{usagePercentage.toFixed(1)}%</span>
                        </div>
                        <Progress value={usagePercentage} className="w-full" />
                      </div>

                      <div className="text-sm">
                        <div className="text-gray-600">Items</div>
                        <div className="font-semibold">{category.items.length}</div>
                      </div>

                      {category.items.length > 0 && (
                        <div className="space-y-2">
                          <div className="text-sm text-gray-600">Recent Items</div>
                          {category.items.slice(0, 3).map((item) => (
                            <div key={item.id} className="flex items-center justify-between text-sm">
                              <span className="truncate">{item.name}</span>
                              <div className="flex items-center space-x-2">
                                <Badge className={`${getStatusColor(item.status)} text-white text-xs`}>
                                  {getStatusLabel(item.status)}
                                </Badge>
                                <span className="font-medium">${item.totalCost.toLocaleString()}</span>
                              </div>
                            </div>
                          ))}
                          {category.items.length > 3 && (
                            <div className="text-xs text-gray-500">
                              +{category.items.length - 3} more items
                            </div>
                          )}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="items" className="space-y-6">
          <div className="space-y-4">
            {budget.categories.map((category) => (
              <div key={category.id}>
                {category.items.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold mb-3">{category.name}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                      {category.items.map((item) => (
                        <Card key={item.id} className="hover:shadow-sm transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1">
                                <h4 className="font-medium">{item.name}</h4>
                                {item.description && (
                                  <p className="text-sm text-gray-600">{item.description}</p>
                                )}
                              </div>
                              <Badge className={`${getStatusColor(item.status)} text-white ml-2`}>
                                {getStatusLabel(item.status)}
                              </Badge>
                            </div>
                            
                            <div className="space-y-1 text-sm">
                              <div className="flex justify-between">
                                <span>Unit Cost:</span>
                                <span>${item.unitCost.toLocaleString()}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Quantity:</span>
                                <span>{item.quantity}</span>
                              </div>
                              <div className="flex justify-between font-semibold">
                                <span>Total:</span>
                                <span>${item.totalCost.toLocaleString()}</span>
                              </div>
                              {item.vendor && (
                                <div className="flex justify-between">
                                  <span>Vendor:</span>
                                  <span className="truncate ml-2">{item.vendor}</span>
                                </div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default BudgetManager;
