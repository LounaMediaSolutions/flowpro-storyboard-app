import React, { useState } from 'react';
import { Users, MapPin, Camera, UserPlus, Plus, Edit2, Trash2, Phone, Mail, Calendar } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useStoryboardStore } from '../../store/storyboardStore';
import { Location, LocationType } from '../../types';
import { toast } from 'sonner';

const ProductionManager: React.FC = () => {
  const {
    currentProject,
    addLocation,
    updateLocation,
    deleteLocation,
    setCurrentView
  } = useStoryboardStore();

  const [isLocationDialogOpen, setIsLocationDialogOpen] = useState(false);
  const [newLocation, setNewLocation] = useState<Partial<Location>>({
    name: '',
    description: '',
    type: 'location',
    availability: [],
    cost: 0,
    contact: '',
    notes: ''
  });

  // Mock crew data
  const [crewMembers] = useState([
    {
      id: '1',
      name: 'Alex Rodriguez',
      role: 'Director of Photography',
      department: 'Camera',
      contact: 'alex@example.com',
      rate: 800,
      availability: ['Mon-Fri']
    },
    {
      id: '2',
      name: 'Sarah Chen',
      role: 'Gaffer',
      department: 'Lighting',
      contact: 'sarah@example.com',
      rate: 600,
      availability: ['Mon-Sun']
    },
    {
      id: '3',
      name: 'Marcus Johnson',
      role: 'Sound Engineer',
      department: 'Audio',
      contact: 'marcus@example.com',
      rate: 500,
      availability: ['Mon-Fri']
    }
  ]);

  // Mock cast data
  const [castMembers] = useState([
    {
      id: '1',
      name: 'Emma Watson',
      role: 'Lead Actor',
      contact: 'emma@agency.com',
      rate: 2000,
      availability: ['Mon-Thu'],
      wardrobe: ['Business casual', 'Evening wear'],
      characterId: currentProject?.characters[0]?.id || ''
    },
    {
      id: '2',
      name: 'James Wilson',
      role: 'Supporting Actor',
      contact: 'james@agency.com',
      rate: 1200,
      availability: ['Mon-Fri'],
      wardrobe: ['Casual', 'Formal'],
      characterId: currentProject?.characters[1]?.id || ''
    }
  ]);

  // Mock equipment data
  const [equipment] = useState([
    {
      id: '1',
      name: 'RED Komodo 6K',
      category: 'camera' as const,
      description: 'Professional 6K cinema camera',
      specifications: ['6K sensor', 'Global shutter', 'Canon RF mount'],
      rental: true,
      cost: 800,
      vendor: 'Camera Rentals Inc',
      availability: ['Mon-Fri']
    },
    {
      id: '2',
      name: 'ARRI SkyPanel S60-C',
      category: 'lighting' as const,
      description: 'LED soft light with color mixing',
      specifications: ['LED technology', 'Full color spectrum', 'DMX control'],
      rental: true,
      cost: 300,
      vendor: 'Lighting Pro',
      availability: ['Mon-Sun']
    }
  ]);

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <Users className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const handleAddLocation = () => {
    if (!newLocation.name?.trim()) {
      toast.error('Please enter a location name');
      return;
    }

    addLocation(currentProject.id, {
      ...newLocation,
      name: newLocation.name.trim(),
      description: newLocation.description || '',
      type: newLocation.type || 'location',
      availability: newLocation.availability || [],
      cost: newLocation.cost || 0,
      contact: newLocation.contact || '',
      notes: newLocation.notes || ''
    } as Omit<Location, 'id' | 'projectId'>);

    setNewLocation({
      name: '',
      description: '',
      type: 'location',
      availability: [],
      cost: 0,
      contact: '',
      notes: ''
    });
    setIsLocationDialogOpen(false);
    toast.success('Location added successfully!');
  };

  const getLocationTypeLabel = (type: LocationType) => {
    switch (type) {
      case 'interior': return 'Interior';
      case 'exterior': return 'Exterior';
      case 'studio': return 'Studio';
      case 'greenscreen': return 'Green Screen';
      case 'location': return 'Location';
      default: return 'Unknown';
    }
  };

  const getLocationTypeColor = (type: LocationType) => {
    switch (type) {
      case 'interior': return 'bg-blue-500';
      case 'exterior': return 'bg-green-500';
      case 'studio': return 'bg-purple-500';
      case 'greenscreen': return 'bg-emerald-500';
      case 'location': return 'bg-orange-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Production Management</h1>
          <p className="text-gray-600">Manage crew, cast, equipment, and locations</p>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="locations" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="locations" className="flex items-center space-x-2">
            <MapPin className="w-4 h-4" />
            <span>Locations</span>
          </TabsTrigger>
          <TabsTrigger value="crew" className="flex items-center space-x-2">
            <Users className="w-4 h-4" />
            <span>Crew</span>
          </TabsTrigger>
          <TabsTrigger value="cast" className="flex items-center space-x-2">
            <UserPlus className="w-4 h-4" />
            <span>Cast</span>
          </TabsTrigger>
          <TabsTrigger value="equipment" className="flex items-center space-x-2">
            <Camera className="w-4 h-4" />
            <span>Equipment</span>
          </TabsTrigger>
        </TabsList>

        {/* Locations Tab */}
        <TabsContent value="locations" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Locations</h2>
            <Dialog open={isLocationDialogOpen} onOpenChange={setIsLocationDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Location
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Add New Location</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <Label htmlFor="location-name">Location Name</Label>
                    <Input
                      id="location-name"
                      placeholder="Enter location name..."
                      value={newLocation.name}
                      onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="location-type">Type</Label>
                    <Select
                      value={newLocation.type}
                      onValueChange={(value) => setNewLocation({ ...newLocation, type: value as LocationType })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="interior">Interior</SelectItem>
                        <SelectItem value="exterior">Exterior</SelectItem>
                        <SelectItem value="studio">Studio</SelectItem>
                        <SelectItem value="greenscreen">Green Screen</SelectItem>
                        <SelectItem value="location">Location</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location-description">Description</Label>
                    <Textarea
                      id="location-description"
                      placeholder="Describe the location..."
                      value={newLocation.description}
                      onChange={(e) => setNewLocation({ ...newLocation, description: e.target.value })}
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="location-cost">Daily Cost ($)</Label>
                      <Input
                        id="location-cost"
                        type="number"
                        placeholder="0"
                        value={newLocation.cost}
                        onChange={(e) => setNewLocation({ ...newLocation, cost: parseInt(e.target.value) || 0 })}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="location-contact">Contact</Label>
                      <Input
                        id="location-contact"
                        placeholder="contact@example.com"
                        value={newLocation.contact}
                        onChange={(e) => setNewLocation({ ...newLocation, contact: e.target.value })}
                      />
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsLocationDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button onClick={handleAddLocation} disabled={!newLocation.name?.trim()}>
                      Add Location
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentProject.locations.map((location) => (
              <Card key={location.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge className={`${getLocationTypeColor(location.type)} text-white`}>
                          {getLocationTypeLabel(location.type)}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg">{location.name}</CardTitle>
                      <p className="text-sm text-gray-600 mt-1">{location.description}</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => {
                          deleteLocation(location.id);
                          toast.success('Location deleted');
                        }}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  {location.address && (
                    <div className="text-sm">
                      <div className="text-gray-600">Address</div>
                      <div>{location.address}</div>
                    </div>
                  )}
                  
                  {location.cost && (
                    <div className="text-sm">
                      <div className="text-gray-600">Daily Cost</div>
                      <div className="font-semibold">${location.cost}</div>
                    </div>
                  )}
                  
                  {location.contact && (
                    <div className="text-sm">
                      <div className="text-gray-600">Contact</div>
                      <div className="flex items-center space-x-1">
                        <Mail className="w-3 h-3" />
                        <span>{location.contact}</span>
                      </div>
                    </div>
                  )}
                  
                  {location.availability && location.availability.length > 0 && (
                    <div className="text-sm">
                      <div className="text-gray-600">Availability</div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {location.availability.map((time, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {time}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {currentProject.locations.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="w-12 h-12 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No locations added</h3>
              <p className="text-gray-600 mb-4">Add locations to organize your shooting schedule</p>
              <Button onClick={() => setIsLocationDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Location
              </Button>
            </div>
          )}
        </TabsContent>

        {/* Crew Tab */}
        <TabsContent value="crew" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Crew Members</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Crew Member
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {crewMembers.map((crew) => (
              <Card key={crew.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{crew.name}</CardTitle>
                      <p className="text-sm text-gray-600">{crew.role}</p>
                      <Badge variant="secondary" className="mt-1">
                        {crew.department}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="text-gray-600">Contact</div>
                    <div className="flex items-center space-x-1">
                      <Mail className="w-3 h-3" />
                      <span>{crew.contact}</span>
                    </div>
                  </div>
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Daily Rate</div>
                    <div className="font-semibold">${crew.rate}</div>
                  </div>
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Availability</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {crew.availability.map((time, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {time}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Cast Tab */}
        <TabsContent value="cast" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Cast Members</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Cast Member
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {castMembers.map((cast) => (
              <Card key={cast.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{cast.name}</CardTitle>
                      <p className="text-sm text-gray-600">{cast.role}</p>
                      {cast.characterId && (
                        <Badge variant="secondary" className="mt-1">
                          Character Role
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="text-gray-600">Contact</div>
                    <div className="flex items-center space-x-1">
                      <Mail className="w-3 h-3" />
                      <span>{cast.contact}</span>
                    </div>
                  </div>
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Daily Rate</div>
                    <div className="font-semibold">${cast.rate}</div>
                  </div>
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Wardrobe</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {cast.wardrobe?.map((item, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {item}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Availability</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {cast.availability.map((time, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {time}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Equipment Tab */}
        <TabsContent value="equipment" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Equipment</h2>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Add Equipment
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {equipment.map((item) => (
              <Card key={item.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg">{item.name}</CardTitle>
                      <p className="text-sm text-gray-600">{item.description}</p>
                      <Badge variant="secondary" className="mt-1 capitalize">
                        {item.category}
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="sm">
                        <Edit2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <div className="text-gray-600">Specifications</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {item.specifications?.map((spec, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {spec}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  {item.rental && (
                    <div className="text-sm">
                      <div className="text-gray-600">Daily Rental</div>
                      <div className="font-semibold">${item.cost}</div>
                    </div>
                  )}
                  
                  {item.vendor && (
                    <div className="text-sm">
                      <div className="text-gray-600">Vendor</div>
                      <div>{item.vendor}</div>
                    </div>
                  )}
                  
                  <div className="text-sm">
                    <div className="text-gray-600">Availability</div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {item.availability.map((time, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {time}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProductionManager;
