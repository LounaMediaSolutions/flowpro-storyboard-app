import React, { useState } from 'react';
import { Download, FileText, Image, Film, Share2, Settings, Loader2, CheckCircle, Filter, Code, Video } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Label } from '../ui/label';
import { Input } from '../ui/input';
import { Switch } from '../ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Separator } from '../ui/separator';
import { Badge } from '../ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Checkbox } from '../ui/checkbox';
import { useStoryboardStore } from '../../store/storyboardStore';
import { ExportOptions, AdvancedExportOptions, XMLExportOptions } from '../../types';
import { toast } from 'sonner';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

const ExportPage: React.FC = () => {
  const { currentProject, setCurrentView } = useStoryboardStore();
  
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    format: 'pdf',
    includeScript: true,
    includeBranding: true,
    companyName: '',
    watermark: false,
    resolution: 'high',
    organizationMethod: 'by_scene',
    includeShootingSchedule: false,
    includeCastList: false,
    includeLocationDetails: false
  });

  const [advancedOptions, setAdvancedOptions] = useState<AdvancedExportOptions>({
    ...exportOptions,
    filterBy: {},
    customLayout: false,
    includeNotes: true,
    includeVFX: true,
    includeBudget: false,
    includeSchedule: false,
    pageOrientation: 'portrait',
    paperSize: 'A4'
  });

  const [xmlOptions, setXmlOptions] = useState<XMLExportOptions>({
    ...exportOptions,
    targetNLE: 'premiere',
    includeMedia: true,
    includeAudio: true,
    includeEffects: false,
    timecodeStart: '01:00:00:00',
    frameRate: 24
  });

  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [selectedEpisodes, setSelectedEpisodes] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [selectedCharacters, setSelectedCharacters] = useState<string[]>([]);

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <Download className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const totalShots = currentProject.episodes.reduce((acc, episode) => 
    acc + episode.scenes.reduce((sceneAcc, scene) => sceneAcc + scene.shots.length, 0), 0
  );
  const shotsWithImages = currentProject.episodes.reduce((acc, episode) => 
    acc + episode.scenes.reduce((sceneAcc, scene) => 
      sceneAcc + scene.shots.filter(shot => shot.imageUrl).length, 0
    ), 0
  );

  const exportFormats = [
    { value: 'pdf', label: 'PDF Storyboard', icon: FileText, description: 'Professional PDF document with filtering' },
    { value: 'images', label: 'Image Files', icon: Image, description: 'Individual PNG/JPG files' },
    { value: 'screenplay', label: 'Screenplay', icon: Film, description: 'Text-based script format' },
    { value: 'xml_premiere', label: 'Adobe Premiere XML', icon: Code, description: 'Timeline for Premiere Pro' },
    { value: 'xml_davinci', label: 'DaVinci Resolve XML', icon: Video, description: 'Timeline for DaVinci Resolve' },
    { value: 'edl', label: 'Edit Decision List', icon: FileText, description: 'Industry standard EDL format' }
  ];

  const resolutionOptions = [
    { value: 'low', label: 'Low (72 DPI)', description: 'Faster export, smaller file size' },
    { value: 'medium', label: 'Medium (150 DPI)', description: 'Balanced quality and size' },
    { value: 'high', label: 'High (300 DPI)', description: 'Best quality, larger file size' }
  ];

  const handleExport = async () => {
    if (exportOptions.format === 'pdf' && shotsWithImages === 0) {
      toast.error('No images found to export. Generate images first.');
      return;
    }

    setIsExporting(true);
    setExportProgress(0);

    try {
      if (exportOptions.format === 'pdf') {
        await exportToPDF();
      } else if (exportOptions.format === 'images') {
        await exportToImages();
      } else if (exportOptions.format === 'screenplay') {
        await exportToScreenplay();
      }
      
      toast.success('Export completed successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Export failed. Please try again.');
    } finally {
      setIsExporting(false);
      setExportProgress(0);
    }
  };

  const exportToPDF = async () => {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 20;
    const contentWidth = pageWidth - (margin * 2);
    
    // Title Page
    if (exportOptions.includeBranding && exportOptions.companyName) {
      pdf.setFontSize(20);
      pdf.text(exportOptions.companyName, margin, margin + 10);
    }
    
    pdf.setFontSize(24);
    pdf.text('STORYBOARD', margin, margin + 30);
    
    pdf.setFontSize(18);
    pdf.text(currentProject.title, margin, margin + 45);
    
    pdf.setFontSize(12);
    pdf.text(currentProject.description || '', margin, margin + 60);
    
    pdf.setFontSize(10);
    pdf.text(`Generated on ${new Date().toLocaleDateString()}`, margin, margin + 80);
    
    let currentPage = 1;
    let yPosition = margin + 100;
    
    for (const episode of currentProject.episodes) {
      for (const scene of episode.scenes) {
        for (const shot of scene.shots) {
        setExportProgress((currentPage / totalShots) * 100);
        
        // Check if we need a new page
        if (yPosition + 120 > pageHeight - margin) {
          pdf.addPage();
          yPosition = margin;
        }
        
        // Shot header
        pdf.setFontSize(14);
        pdf.text(`Scene ${scene.sceneNumber}, Shot ${shot.shotNumber}`, margin, yPosition);
        yPosition += 10;
        
        // Shot description
        pdf.setFontSize(10);
        const lines = pdf.splitTextToSize(shot.description, contentWidth);
        pdf.text(lines, margin, yPosition);
        yPosition += lines.length * 5 + 5;
        
        // Voice over
        if (shot.voiceOver && exportOptions.includeScript) {
          pdf.setFont(undefined, 'italic');
          const voLines = pdf.splitTextToSize(`"${shot.voiceOver}"`, contentWidth);
          pdf.text(voLines, margin, yPosition);
          yPosition += voLines.length * 5 + 5;
          pdf.setFont(undefined, 'normal');
        }
        
        // Camera details
        pdf.setFontSize(8);
        pdf.text(`Camera: ${shot.cameraAngle.replace('_', ' ')} | Movement: ${shot.cameraMovement.replace('_', ' ')} | Transition: ${shot.transition}`, margin, yPosition);
        yPosition += 10;
        
        // Image placeholder (in a real implementation, you'd add the actual image)
        pdf.rect(margin, yPosition, contentWidth * 0.7, 60);
        pdf.setFontSize(8);
        pdf.text('Storyboard Frame', margin + 5, yPosition + 30);
        
        yPosition += 70;
        currentPage++;
        }
      }
    }
    
    // Watermark
    if (exportOptions.watermark) {
      const totalPages = pdf.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i);
        pdf.setFontSize(50);
        pdf.setTextColor(200, 200, 200); // Light gray color for watermark
        pdf.text('STORYBOARD AI', pageWidth / 2, pageHeight / 2, { angle: 45, align: 'center' });
        pdf.setTextColor(0, 0, 0); // Reset to black
      }
    }
    
    pdf.save(`${currentProject.title}-storyboard.pdf`);
  };

  const exportToImages = async () => {
    // In a real implementation, you would zip individual shot images
    toast.info('Image export functionality would download all storyboard frames as individual files.');
    
    // Simulate progress
    for (let i = 0; i <= 100; i += 10) {
      setExportProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  };

  const exportToScreenplay = async () => {
    let screenplay = '';
    
    screenplay += `${currentProject.title}\n`;
    screenplay += `${currentProject.description}\n\n`;
    screenplay += '=' .repeat(50) + '\n\n';
    
    for (const episode of currentProject.episodes) {
      for (const scene of episode.scenes) {
      screenplay += `SCENE ${scene.sceneNumber}: ${scene.title.toUpperCase()}\n\n`;
      screenplay += `${scene.description}\n\n`;
      
      for (const shot of scene.shots) {
        screenplay += `SHOT ${shot.shotNumber} - ${shot.cameraAngle.replace('_', ' ').toUpperCase()}\n`;
        screenplay += `${shot.description}\n`;
        
        if (shot.voiceOver) {
          screenplay += `\nVOICE OVER:\n"${shot.voiceOver}"\n`;
        }
        
        screenplay += `\nCAMERA: ${shot.cameraMovement.replace('_', ' ')} | TRANSITION: ${shot.transition.replace('_', ' ')}\n\n`;
        screenplay += '-'.repeat(30) + '\n\n';
      }
      
      screenplay += '\n';
      }
    }
    
    // Create and download the file
    const blob = new Blob([screenplay], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentProject.title}-screenplay.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    // Simulate progress
    for (let i = 0; i <= 100; i += 20) {
      setExportProgress(i);
      await new Promise(resolve => setTimeout(resolve, 50));
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-gray-900">Export Storyboard</h1>
        <p className="text-gray-600">Export your storyboard in various formats for presentation and sharing</p>
      </div>

      {/* Project Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Project Summary</span>
            <div className="flex items-center space-x-2">
              <Badge variant="secondary">{currentProject.episodes.reduce((acc, episode) => acc + episode.scenes.length, 0)} Scenes</Badge>
              <Badge variant="secondary">{totalShots} Shots</Badge>
              <Badge variant={shotsWithImages === totalShots ? "default" : "destructive"}>
                {shotsWithImages}/{totalShots} Images
              </Badge>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <h3 className="font-semibold">{currentProject.title}</h3>
            <p className="text-gray-600">{currentProject.description}</p>
            {shotsWithImages < totalShots && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <span className="text-sm text-yellow-700">
                    {totalShots - shotsWithImages} shots are missing images. 
                    <Button 
                      variant="link" 
                      className="p-0 ml-1 text-yellow-700"
                      onClick={() => setCurrentView('storyboard')}
                    >
                      Generate them now
                    </Button>
                  </span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Export Format */}
        <Card>
          <CardHeader>
            <CardTitle>Export Format</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-3">
              {exportFormats.map((format) => (
                <div
                  key={format.value}
                  className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                    exportOptions.format === format.value
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setExportOptions(prev => ({ ...prev, format: format.value as any }))}
                >
                  <div className="flex items-start space-x-3">
                    <format.icon className="w-5 h-5 mt-0.5 text-gray-600" />
                    <div className="flex-1">
                      <div className="font-medium">{format.label}</div>
                      <div className="text-sm text-gray-600">{format.description}</div>
                    </div>
                    {exportOptions.format === format.value && (
                      <CheckCircle className="w-5 h-5 text-blue-500" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Export Options */}
        <Card>
          <CardHeader>
            <CardTitle>Export Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Include Script</Label>
                  <p className="text-sm text-gray-600">Add scene descriptions and voice-over text</p>
                </div>
                <Switch
                  checked={exportOptions.includeScript}
                  onCheckedChange={(checked) => 
                    setExportOptions(prev => ({ ...prev, includeScript: checked }))
                  }
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Include Branding</Label>
                  <p className="text-sm text-gray-600">Add your company name and logo</p>
                </div>
                <Switch
                  checked={exportOptions.includeBranding}
                  onCheckedChange={(checked) => 
                    setExportOptions(prev => ({ ...prev, includeBranding: checked }))
                  }
                />
              </div>

              {exportOptions.includeBranding && (
                <div>
                  <Label htmlFor="company-name" className="text-sm font-medium">Company Name</Label>
                  <Input
                    id="company-name"
                    placeholder="Enter your company name"
                    value={exportOptions.companyName}
                    onChange={(e) => 
                      setExportOptions(prev => ({ ...prev, companyName: e.target.value }))
                    }
                    className="mt-1"
                  />
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-sm font-medium">Add Watermark</Label>
                  <p className="text-sm text-gray-600">Add semi-transparent watermark</p>
                </div>
                <Switch
                  checked={exportOptions.watermark}
                  onCheckedChange={(checked) => 
                    setExportOptions(prev => ({ ...prev, watermark: checked }))
                  }
                />
              </div>

              <div>
                <Label className="text-sm font-medium">Quality/Resolution</Label>
                <Select
                  value={exportOptions.resolution}
                  onValueChange={(value) => 
                    setExportOptions(prev => ({ ...prev, resolution: value as any }))
                  }
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {resolutionOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        <div>
                          <div className="font-medium">{option.label}</div>
                          <div className="text-sm text-gray-500">{option.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export Actions */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="text-sm font-medium">Ready to export</div>
              <div className="text-sm text-gray-600">
                {exportOptions.format === 'pdf' ? 'PDF document' : 
                 exportOptions.format === 'images' ? 'Image files' : 
                 'Screenplay text file'} • {exportOptions.resolution} quality
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Button variant="outline">
                <Share2 className="w-4 h-4 mr-2" />
                Share Link
              </Button>
              
              <Button 
                onClick={handleExport}
                disabled={isExporting || (exportOptions.format === 'pdf' && shotsWithImages === 0)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isExporting ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Exporting... {Math.round(exportProgress)}%
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Export {exportOptions.format.toUpperCase()}
                  </>
                )}
              </Button>
            </div>
          </div>

          {isExporting && (
            <div className="mt-4">
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${exportProgress}%` }}
                ></div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ExportPage;
