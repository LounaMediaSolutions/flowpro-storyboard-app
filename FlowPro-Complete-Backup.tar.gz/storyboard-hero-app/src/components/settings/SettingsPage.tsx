import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Settings, Brain, Bot, Database, Zap, CheckCircle, AlertCircle } from 'lucide-react';
import { toast } from '../../hooks/use-toast';

interface APIKeys {
  google: string;
  deepseek: string;
  openai: string;
  supabase: string;
  minimax: string;
}

const SettingsPage: React.FC = () => {
  const [apiKeys, setApiKeys] = useState<APIKeys>({
    google: '',
    deepseek: '',
    openai: '',
    supabase: '',
    minimax: ''
  });
  const [isTestingConnections, setIsTestingConnections] = useState(false);
  const [connectionResults, setConnectionResults] = useState<{ [key: string]: boolean }>({});

  useEffect(() => {
    // Load saved API keys on component mount
    const savedKeys = localStorage.getItem('flowpro-api-keys');
    if (savedKeys) {
      try {
        const parsedKeys = JSON.parse(savedKeys);
        setApiKeys(prev => ({ ...prev, ...parsedKeys }));
      } catch (error) {
        console.error('Error loading saved API keys:', error);
      }
    }
  }, []);

  const handleApiKeySave = () => {
    localStorage.setItem('flowpro-api-keys', JSON.stringify(apiKeys));
    toast({
      title: "✅ Configuration Saved!",
      description: "Your API keys have been securely saved to browser storage.",
    });
  };

  const handleTestConnections = async () => {
    setIsTestingConnections(true);
    const results: { [key: string]: boolean } = {};
    
    // Simple validation tests
    if (apiKeys.google && apiKeys.google.length > 10) {
      results.google = true;
    } else {
      results.google = false;
    }
    
    if (apiKeys.deepseek && apiKeys.deepseek.length > 10) {
      results.deepseek = true;
    } else {
      results.deepseek = false;
    }
    
    if (apiKeys.openai && apiKeys.openai.startsWith('sk-')) {
      results.openai = true;
    } else {
      results.openai = false;
    }
    
    if (apiKeys.supabase && apiKeys.supabase.includes('supabase.co')) {
      results.supabase = true;
    } else {
      results.supabase = false;
    }
    
    if (apiKeys.minimax && apiKeys.minimax.length > 10) {
      results.minimax = true;
    } else {
      results.minimax = false;
    }
    
    setConnectionResults(results);
    setIsTestingConnections(false);
    
    const successCount = Object.values(results).filter(Boolean).length;
    toast({
      title: `✅ Connection Test Complete`,
      description: `${successCount}/5 API keys appear to be valid format.`,
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Settings className="h-8 w-8 text-green-600" />
        <div>
          <h1 className="text-3xl font-bold">API Settings</h1>
          <p className="text-gray-600">Configure your API keys for AI services</p>
        </div>
      </div>

      {/* Success Banner */}
      <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 mb-6">
        <div className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <h3 className="text-lg font-semibold text-green-800">Settings Page is Working! ✅</h3>
        </div>
        <p className="text-green-700 mt-1">This is a dedicated Settings page - no tabs required!</p>
      </div>

      {/* API Configuration */}
      <Card className="border-2 border-green-100">
        <CardHeader className="bg-green-50">
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-6 w-6 text-green-600" />
            Multi-Platform API Configuration
          </CardTitle>
          <CardDescription>
            Configure API keys for all integrated AI services. These keys are stored locally in your browser.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6 p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Google AI */}
            <div className="space-y-3">
              <Label htmlFor="google-key" className="flex items-center gap-2 text-base font-medium">
                <Brain className="h-5 w-5 text-blue-600" />
                Google AI Studio API Key
                {connectionResults.google !== undefined && (
                  connectionResults.google ? 
                    <CheckCircle className="h-4 w-4 text-green-500" /> : 
                    <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </Label>
              <Input
                id="google-key"
                type="password"
                placeholder="Enter your Google AI Studio API key"
                value={apiKeys.google}
                onChange={(e) => setApiKeys(prev => ({ ...prev, google: e.target.value }))}
                className="text-base p-3"
              />
            </div>
            
            {/* DeepSeek */}
            <div className="space-y-3">
              <Label htmlFor="deepseek-key" className="flex items-center gap-2 text-base font-medium">
                <Brain className="h-5 w-5 text-purple-600" />
                DeepSeek API Key
                {connectionResults.deepseek !== undefined && (
                  connectionResults.deepseek ? 
                    <CheckCircle className="h-4 w-4 text-green-500" /> : 
                    <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </Label>
              <Input
                id="deepseek-key"
                type="password"
                placeholder="Enter your DeepSeek API key"
                value={apiKeys.deepseek}
                onChange={(e) => setApiKeys(prev => ({ ...prev, deepseek: e.target.value }))}
                className="text-base p-3"
              />
            </div>

            {/* OpenAI */}
            <div className="space-y-3">
              <Label htmlFor="openai-key" className="flex items-center gap-2 text-base font-medium">
                <Bot className="h-5 w-5 text-green-600" />
                OpenAI API Key
                {connectionResults.openai !== undefined && (
                  connectionResults.openai ? 
                    <CheckCircle className="h-4 w-4 text-green-500" /> : 
                    <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </Label>
              <Input
                id="openai-key"
                type="password"
                placeholder="Enter your OpenAI API key (sk-...)"
                value={apiKeys.openai}
                onChange={(e) => setApiKeys(prev => ({ ...prev, openai: e.target.value }))}
                className="text-base p-3"
              />
            </div>
            
            {/* Supabase */}
            <div className="space-y-3">
              <Label htmlFor="supabase-key" className="flex items-center gap-2 text-base font-medium">
                <Database className="h-5 w-5 text-orange-600" />
                Supabase Project URL
                {connectionResults.supabase !== undefined && (
                  connectionResults.supabase ? 
                    <CheckCircle className="h-4 w-4 text-green-500" /> : 
                    <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </Label>
              <Input
                id="supabase-key"
                type="password"
                placeholder="Enter your Supabase project URL"
                value={apiKeys.supabase}
                onChange={(e) => setApiKeys(prev => ({ ...prev, supabase: e.target.value }))}
                className="text-base p-3"
              />
            </div>

            {/* MiniMax */}
            <div className="space-y-3 md:col-span-2">
              <Label htmlFor="minimax-key" className="flex items-center gap-2 text-base font-medium">
                <Zap className="h-5 w-5 text-yellow-600" />
                MiniMax API Key
                {connectionResults.minimax !== undefined && (
                  connectionResults.minimax ? 
                    <CheckCircle className="h-4 w-4 text-green-500" /> : 
                    <AlertCircle className="h-4 w-4 text-red-500" />
                )}
              </Label>
              <Input
                id="minimax-key"
                type="password"
                placeholder="Enter your MiniMax API key"
                value={apiKeys.minimax}
                onChange={(e) => setApiKeys(prev => ({ ...prev, minimax: e.target.value }))}
                className="text-base p-3"
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t">
            <Button 
              onClick={handleApiKeySave}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3"
            >
              <CheckCircle className="h-5 w-5" />
              Save Configuration
            </Button>
            
            <Button 
              onClick={handleTestConnections}
              disabled={isTestingConnections}
              variant="outline"
              className="flex items-center gap-2 border-green-600 text-green-600 hover:bg-green-50 px-6 py-3"
            >
              <Zap className="h-5 w-5" />
              {isTestingConnections ? 'Testing...' : 'Test Connections'}
            </Button>
          </div>

          {/* Connection Results */}
          {Object.keys(connectionResults).length > 0 && (
            <div className="pt-4 border-t space-y-2">
              <h4 className="font-medium text-gray-900">Connection Test Results:</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {Object.entries(connectionResults).map(([service, success]) => (
                  <div key={service} className="flex items-center gap-2">
                    {success ? 
                      <CheckCircle className="h-4 w-4 text-green-500" /> : 
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    }
                    <span className={`text-sm ${success ? 'text-green-700' : 'text-red-700'}`}>
                      {service.toUpperCase()}: {success ? 'Valid format' : 'Invalid format'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>Setup Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium">Google AI Studio</h4>
              <p className="text-sm text-gray-600">Get your API key from Google AI Studio console</p>
            </div>
            <div>
              <h4 className="font-medium">DeepSeek</h4>
              <p className="text-sm text-gray-600">Sign up at DeepSeek platform for API access</p>
            </div>
            <div>
              <h4 className="font-medium">OpenAI</h4>
              <p className="text-sm text-gray-600">Get your API key from OpenAI platform (starts with sk-)</p>
            </div>
            <div>
              <h4 className="font-medium">Supabase</h4>
              <p className="text-sm text-gray-600">Your Supabase project URL from dashboard</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SettingsPage;
