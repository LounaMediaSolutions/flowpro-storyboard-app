import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Switch } from '../ui/switch';
import { Label } from '../ui/label';
import { 
  Brain, 
  Image, 
  FileText, 
  Video, 
  Music, 
  Wand2, 
  Settings,
  Upload,
  Download,
  Play,
  Pause,
  RefreshCw,
  Cloud,
  Zap,
  Database,
  Bot,
  Workflow,
  Sparkles,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';
import { toast } from '../../hooks/use-toast';
import APITester, { ConnectionTest } from '../../utils/apiTester';
import AIServicesGuide from './AIServicesGuide';
import PromptTester from './PromptTester';

interface AIService {
  id: string;
  name: string;
  description: string;
  category: 'image' | 'text' | 'audio' | 'video' | 'analysis' | 'workflow' | 'automation';
  status: 'available' | 'processing' | 'error' | 'connected';
  icon: React.ReactNode;
  provider: 'google' | 'deepseek' | 'supabase' | 'minimax' | 'openai';
  capabilities: string[];
}

const enhancedAIServices: AIService[] = [
  {
    id: 'google-script-analysis',
    name: 'Google AI Script Analysis',
    description: 'Advanced screenplay analysis with character extraction, scene breakdown, and shot suggestions',
    category: 'analysis',
    status: 'available',
    provider: 'google',
    icon: <Brain className="h-5 w-5" />,
    capabilities: ['Character Analysis', 'Scene Breakdown', 'Shot Planning', 'Budget Estimation']
  },
  {
    id: 'deepseek-reasoning',
    name: 'DeepSeek Advanced Analysis',
    description: 'Advanced reasoning and analysis for complex script and production planning',
    category: 'analysis',
    status: 'available',
    provider: 'deepseek',
    icon: <Brain className="h-5 w-5" />,
    capabilities: ['Advanced Reasoning', 'Character Analysis', 'Story Logic', 'Production Planning']
  },
  {
    id: 'openai-content-generation',
    name: 'ChatGPT Content Generation',
    description: 'Versatile AI assistant for script writing, dialogue enhancement, and creative content',
    category: 'text',
    status: 'available',
    provider: 'openai',
    icon: <Bot className="h-5 w-5" />,
    capabilities: ['Script Writing', 'Dialogue Enhancement', 'Creative Brainstorming', 'Content Editing']
  },
  {
    id: 'minimax-image-generation',
    name: 'MiniMax Image Generation',
    description: 'Professional storyboard image generation with consistent character styling',
    category: 'image',
    status: 'available',
    provider: 'minimax',
    icon: <Image className="h-5 w-5" />,
    capabilities: ['Storyboard Images', 'Character Consistency', 'Scene Visualization', 'Style Control']
  },
  {
    id: 'minimax-video-generation',
    name: 'MiniMax Video Preview',
    description: 'Create animated previews and pre-visualization videos',
    category: 'video',
    status: 'available',
    provider: 'minimax',
    icon: <Video className="h-5 w-5" />,
    capabilities: ['Animatics', 'Pre-visualization', 'Motion Studies', 'Timeline Preview']
  },
  {
    id: 'minimax-audio-generation',
    name: 'MiniMax Voice & Audio',
    description: 'Generate voice-overs, dialogue, and ambient audio',
    category: 'audio',
    status: 'available',
    provider: 'minimax',
    icon: <Music className="h-5 w-5" />,
    capabilities: ['Voice Synthesis', 'Dialogue Generation', 'Background Audio', 'Sound Effects']
  },
  {
    id: 'supabase-realtime-collaboration',
    name: 'Supabase Real-time Collaboration',
    description: 'Live collaboration features with real-time updates and notifications',
    category: 'workflow',
    status: 'connected',
    provider: 'supabase',
    icon: <Database className="h-5 w-5" />,
    capabilities: ['Real-time Updates', 'Collaborative Editing', 'Version Control', 'Team Notifications']
  }
];

export const EnhancedAIServiceManager: React.FC = () => {
  const [activeService, setActiveService] = useState<string>('google-script-analysis');
  const [prompt, setPrompt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<any[]>([]);
  const [apiKeys, setApiKeys] = useState({
    google: '',
    supabase: '',
    minimax: '',
    deepseek: '',
    openai: ''
  });
  const [serviceSettings, setServiceSettings] = useState({
    autoAnalysis: true,
    realTimeSync: true,
    smartSuggestions: true,
    contextAwareness: true
  });
  const [connectionTests, setConnectionTests] = useState<ConnectionTest[]>([]);
  const [isTestingConnections, setIsTestingConnections] = useState(false);

  useEffect(() => {
    // Load saved API keys from localStorage
    const savedKeys = localStorage.getItem('flowpro-api-keys');
    if (savedKeys) {
      setApiKeys(JSON.parse(savedKeys));
    }
  }, []);

  const handleServiceExecute = async (serviceId: string) => {
    const service = enhancedAIServices.find(s => s.id === serviceId);
    if (!service) return;

    setIsProcessing(true);
    setProgress(0);

    try {
      // Simulate different processing based on provider
      let simulatedResult;
      
      switch (service.provider) {
        case 'google':
          simulatedResult = {
            characters: ['John Smith', 'Sarah Johnson'],
            scenes: 12,
            shots: 48,
            estimatedBudget: '$125,000',
            analysisComplete: true
          };
          break;

        case 'deepseek':
          simulatedResult = {
            reasoningSteps: 15,
            logicalConnections: 28,
            analysisDepth: '98%',
            insightsGenerated: 12,
            reasoningComplete: true
          };
          break;
        case 'openai':
          simulatedResult = {
            contentGenerated: '2,500 words',
            dialogueEnhanced: 18,
            creativeSuggestions: 25,
            editingComplete: true,
            qualityScore: '94%'
          };
          break;
        case 'minimax':
          if (service.category === 'image') {
            simulatedResult = {
              imagesGenerated: 15,
              style: 'Professional Cinematic',
              resolution: '1920x1080',
              estimatedTime: '3 minutes'
            };
          } else if (service.category === 'video') {
            simulatedResult = {
              videoCreated: true,
              duration: '2:30',
              format: 'MP4',
              quality: '4K'
            };
          } else if (service.category === 'audio') {
            simulatedResult = {
              audioGenerated: true,
              duration: '45 seconds',
              voice: 'Professional Male',
              quality: 'Studio'
            };
          }
          break;
        default:
          simulatedResult = { success: true, data: `Mock result for ${service.name}` };
      }

      // Simulate progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsProcessing(false);
            
            setResults(prev => [...prev, {
              id: Date.now(),
              service: serviceId,
              provider: service.provider,
              result: simulatedResult,
              prompt: prompt,
              timestamp: new Date().toISOString()
            }]);
            
            toast({
              title: "AI Service Completed",
              description: `${service.name} has finished processing your request.`,
            });
            
            return 100;
          }
          return prev + 15;
        });
      }, 600);

    } catch (error) {
      setIsProcessing(false);
      setProgress(0);
      toast({
        title: "Service Error",
        description: `Failed to execute ${service.name}. Please check your configuration.`,
        variant: "destructive",
      });
    }
  };

  const handleApiKeySave = () => {
    localStorage.setItem('flowpro-api-keys', JSON.stringify(apiKeys));
    toast({
      title: "Configuration Saved",
      description: "Your API keys have been securely saved.",
    });
  };

  const handleTestConnections = async () => {
    setIsTestingConnections(true);
    
    try {
      // Test each API with simple prompts
      const tests: ConnectionTest[] = [];
      
      // Test Google AI
      if (apiKeys.google) {
        const googleTest = await testGoogleAI(apiKeys.google);
        tests.push(googleTest);
      } else {
        tests.push({
          service: 'Google AI Studio',
          status: 'missing_key',
          message: 'API key not provided'
        });
      }
      
      // Test Supabase
      if (apiKeys.supabase) {
        const supabaseTest = await testSupabase(apiKeys.supabase);
        tests.push(supabaseTest);
      } else {
        tests.push({
          service: 'Supabase',
          status: 'missing_key',
          message: 'Project URL not provided'
        });
      }
      
      // Test other APIs (basic validation)
      ['deepseek', 'minimax', 'openai'].forEach(provider => {
        const key = apiKeys[provider as keyof typeof apiKeys];
        tests.push({
          service: provider.charAt(0).toUpperCase() + provider.slice(1),
          status: key ? 'connected' : 'missing_key',
          message: key ? 'API key configured' : 'API key not provided'
        });
      });
      
      setConnectionTests(tests);
      
      const summary = APITester.getConnectionSummary(tests);
      toast({
        title: "Connection Test Complete",
        description: `${summary.connected}/${summary.total} services connected successfully`,
      });
      
    } catch (error) {
      toast({
        title: "Test Failed",
        description: "Failed to test connections. Please check your API keys.",
        variant: "destructive",
      });
    } finally {
      setIsTestingConnections(false);
    }
  };

  const testGoogleAI = async (apiKey: string): Promise<ConnectionTest> => {
    const startTime = Date.now();
    try {
      const response = await fetch(
        `https://generativeai.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: "Respond with exactly 'Connection successful' if you can read this."
              }]
            }]
          })
        }
      );
      
      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        return {
          service: 'Google AI Studio',
          status: 'connected',
          message: 'Successfully connected to Google AI',
          responseTime
        };
      } else {
        return {
          service: 'Google AI Studio',
          status: 'error',
          message: `API error: ${response.status}`,
          responseTime
        };
      }
    } catch (error) {
      return {
        service: 'Google AI Studio',
        status: 'error',
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  };

  const testSupabase = async (projectUrl: string): Promise<ConnectionTest> => {
    const startTime = Date.now();
    try {
      const response = await fetch(`${projectUrl}/rest/v1/`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      const responseTime = Date.now() - startTime;
      
      return {
        service: 'Supabase',
        status: response.ok ? 'connected' : 'error',
        message: response.ok ? 'Supabase project accessible' : `HTTP ${response.status}`,
        responseTime
      };
    } catch (error) {
      return {
        service: 'Supabase',
        status: 'error',
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  };

  const getCategoryServices = (category: string) => {
    return enhancedAIServices.filter(service => service.category === category);
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'image': return <Image className="h-4 w-4" />;
      case 'text': return <FileText className="h-4 w-4" />;
      case 'audio': return <Music className="h-4 w-4" />;
      case 'video': return <Video className="h-4 w-4" />;
      case 'analysis': return <Brain className="h-4 w-4" />;
      case 'workflow': return <Workflow className="h-4 w-4" />;
      case 'automation': return <Zap className="h-4 w-4" />;
      default: return <Wand2 className="h-4 w-4" />;
    }
  };

  const getProviderBadge = (provider: string) => {
    const colors = {
      google: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
      deepseek: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
      openai: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200',
      supabase: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
      minimax: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
    };
    
    return (
      <Badge className={`text-xs ${colors[provider as keyof typeof colors] || 'bg-gray-100 text-gray-800'}`}>
        {provider.toUpperCase()}
      </Badge>
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'available': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'connected': return <CheckCircle className="h-4 w-4 text-blue-500" />;
      case 'processing': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <CheckCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-primary" />
            Optional AI Tools
          </h2>
          <p className="text-muted-foreground">
            ⚡ <strong>Optional Enhancement:</strong> FlowPro works completely without AI. These tools are just for generating images, analyzing content, or automation if you choose to use them.
          </p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="flex items-center gap-1">
            <Cloud className="h-3 w-3" />
            Cloud Enabled
          </Badge>
          <Badge variant="outline" className="flex items-center gap-1">
            <Zap className="h-3 w-3" />
            {enhancedAIServices.filter(s => s.status === 'available').length} Services
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="guide" className="space-y-4">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="guide" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
            Guide
          </TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
            AI Services
          </TabsTrigger>
          <TabsTrigger value="prompts" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
            Test Prompts
          </TabsTrigger>
          <TabsTrigger value="workflows" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
            Workflows
          </TabsTrigger>
          <TabsTrigger value="history" className="data-[state=active]:bg-green-500 data-[state=active]:text-white">
            History
          </TabsTrigger>
          <TabsTrigger 
            value="settings" 
            className="data-[state=active]:bg-green-500 data-[state=active]:text-white font-bold"
            onClick={() => console.log('Settings tab clicked!')}
          >
            ⚙️ Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="guide" className="space-y-4">
          <AIServicesGuide />
        </TabsContent>

        <TabsContent value="services" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {['analysis', 'image', 'video', 'audio', 'automation', 'workflow'].map(category => (
              <Card key={category} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center gap-2">
                    {getCategoryIcon(category)}
                    <CardTitle className="text-lg capitalize">{category}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {getCategoryServices(category).map(service => (
                    <div
                      key={service.id}
                      className="flex flex-col gap-2 p-3 rounded-lg border hover:bg-accent cursor-pointer transition-colors"
                      onClick={() => setActiveService(service.id)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {service.icon}
                          <span className="font-medium text-sm">{service.name}</span>
                          {getStatusIcon(service.status)}
                        </div>
                        {getProviderBadge(service.provider)}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {service.description}
                      </p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {service.capabilities.slice(0, 2).map(cap => (
                          <Badge key={cap} variant="secondary" className="text-xs">
                            {cap}
                          </Badge>
                        ))}
                        {service.capabilities.length > 2 && (
                          <Badge variant="secondary" className="text-xs">
                            +{service.capabilities.length - 2} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Enhanced Service Panel */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {enhancedAIServices.find(s => s.id === activeService)?.icon}
                    {enhancedAIServices.find(s => s.id === activeService)?.name || 'Select a Service'}
                    {enhancedAIServices.find(s => s.id === activeService) && 
                      getStatusIcon(enhancedAIServices.find(s => s.id === activeService)!.status)}
                  </CardTitle>
                  <CardDescription>
                    {enhancedAIServices.find(s => s.id === activeService)?.description}
                  </CardDescription>
                </div>
                {enhancedAIServices.find(s => s.id === activeService) && 
                  getProviderBadge(enhancedAIServices.find(s => s.id === activeService)!.provider)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="ai-prompt">Prompt/Input</Label>
                <Textarea
                  id="ai-prompt"
                  placeholder="Enter your detailed prompt or description..."
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  rows={4}
                />
              </div>

              {/* Service Capabilities */}
              {enhancedAIServices.find(s => s.id === activeService) && (
                <div className="space-y-2">
                  <Label>Available Capabilities</Label>
                  <div className="flex flex-wrap gap-2">
                    {enhancedAIServices.find(s => s.id === activeService)!.capabilities.map(cap => (
                      <Badge key={cap} variant="outline" className="text-xs">
                        {cap}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {isProcessing && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Processing with AI...</span>
                    <span>{progress}%</span>
                  </div>
                  <Progress value={progress} className="w-full" />
                </div>
              )}

              <div className="flex gap-2">
                <Button 
                  onClick={() => handleServiceExecute(activeService)}
                  disabled={isProcessing || !prompt.trim()}
                  className="flex-1"
                >
                  {isProcessing ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Execute AI Service
                    </>
                  )}
                </Button>
                <Button variant="outline" size="icon">
                  <Upload className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="workflows" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Intelligent Automation</CardTitle>
              <CardDescription>
                Configure AI-powered automation for your production pipeline
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auto-analysis">Automatic Script Analysis</Label>
                    <p className="text-sm text-muted-foreground">Analyze scripts automatically when uploaded</p>
                  </div>
                  <Switch 
                    id="auto-analysis"
                    checked={serviceSettings.autoAnalysis}
                    onCheckedChange={(checked) => setServiceSettings(prev => ({ ...prev, autoAnalysis: checked }))}
                  />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="realtime-sync">Real-time Synchronization</Label>
                    <p className="text-sm text-muted-foreground">Keep all team members synchronized via Supabase</p>
                  </div>
                  <Switch 
                    id="realtime-sync"
                    checked={serviceSettings.realTimeSync}
                    onCheckedChange={(checked) => setServiceSettings(prev => ({ ...prev, realTimeSync: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="smart-suggestions">Smart Suggestions</Label>
                    <p className="text-sm text-muted-foreground">AI-powered suggestions for improvement</p>
                  </div>
                  <Switch 
                    id="smart-suggestions"
                    checked={serviceSettings.smartSuggestions}
                    onCheckedChange={(checked) => setServiceSettings(prev => ({ ...prev, smartSuggestions: checked }))}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="context-awareness">Context Awareness</Label>
                    <p className="text-sm text-muted-foreground">AI understands your project context via Bubble workflows</p>
                  </div>
                  <Switch 
                    id="context-awareness"
                    checked={serviceSettings.contextAwareness}
                    onCheckedChange={(checked) => setServiceSettings(prev => ({ ...prev, contextAwareness: checked }))}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="prompts" className="space-y-4">
          <PromptTester />
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI Processing History</CardTitle>
              <CardDescription>
                Recent AI service executions and results across all platforms
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results.length === 0 ? (
                <div className="text-center py-8">
                  <Brain className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">
                    No AI processing history yet. Execute an AI service to see results here.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {results.reverse().slice(0, 10).map(result => (
                    <div key={result.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          {getProviderBadge(result.provider)}
                          <Badge variant="outline">
                            {enhancedAIServices.find(s => s.id === result.service)?.name}
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(result.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Prompt:</p>
                        <p className="text-sm text-muted-foreground bg-muted p-2 rounded">
                          {result.prompt}
                        </p>
                        <div className="text-sm">
                          <p className="font-medium">Results:</p>
                          <pre className="bg-muted p-2 rounded text-xs overflow-auto">
                            {JSON.stringify(result.result, null, 2)}
                          </pre>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            <Download className="h-3 w-3 mr-1" />
                            Export
                          </Button>
                          <Button variant="outline" size="sm">
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Rerun
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="bg-green-50 border-l-4 border-green-500 p-4 mb-4">
            <div className="flex items-center">
              <Settings className="h-5 w-5 text-green-500 mr-2" />
              <h3 className="text-lg font-medium text-green-800">Settings Tab Active!</h3>
            </div>
            <p className="text-green-700 mt-1">✅ The Settings tab is working correctly</p>
          </div>
          
          <Card className="border-2 border-green-200">
            <CardHeader className="bg-green-50">
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5 text-green-600" />
                Multi-Platform API Configuration
              </CardTitle>
              <CardDescription>
                Configure API keys for all integrated AI services
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="google-key" className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    Google AI Studio API Key
                  </Label>
                  <Input
                    id="google-key"
                    type="password"
                    placeholder="Enter your Google AI API key"
                    value={apiKeys.google}
                    onChange={(e) => setApiKeys(prev => ({ ...prev, google: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="deepseek-key" className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    DeepSeek API Key
                  </Label>
                  <Input
                    id="deepseek-key"
                    type="password"
                    placeholder="Enter your DeepSeek API key"
                    value={apiKeys.deepseek}
                    onChange={(e) => setApiKeys(prev => ({ ...prev, deepseek: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="openai-key" className="flex items-center gap-2">
                    <Bot className="h-4 w-4" />
                    ChatGPT/OpenAI API Key
                  </Label>
                  <Input
                    id="openai-key"
                    type="password"
                    placeholder="Enter your OpenAI API key"
                    value={apiKeys.openai}
                    onChange={(e) => setApiKeys(prev => ({ ...prev, openai: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="supabase-key" className="flex items-center gap-2">
                    <Database className="h-4 w-4" />
                    Supabase Project URL
                  </Label>
                  <Input
                    id="supabase-key"
                    type="text"
                    placeholder="https://your-project.supabase.co"
                    value={apiKeys.supabase}
                    onChange={(e) => setApiKeys(prev => ({ ...prev, supabase: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minimax-key" className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4" />
                    MiniMax API Key
                  </Label>
                  <Input
                    id="minimax-key"
                    type="password"
                    placeholder="Enter your MiniMax API key"
                    value={apiKeys.minimax}
                    onChange={(e) => setApiKeys(prev => ({ ...prev, minimax: e.target.value }))}
                  />
                </div>


              </div>
              
              <div className="flex gap-2 pt-4">
                <Button onClick={handleApiKeySave}>
                  <Settings className="h-4 w-4 mr-2" />
                  Save Configuration
                </Button>
                <Button variant="outline" onClick={handleTestConnections} disabled={isTestingConnections}>
                  {isTestingConnections ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Testing...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Test Connections
                    </>
                  )}
                </Button>
              </div>

              {/* Connection Test Results */}
              {connectionTests.length > 0 && (
                <div className="mt-6 space-y-3">
                  <Label>Connection Test Results</Label>
                  {connectionTests.map((test, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        {test.status === 'connected' && <CheckCircle className="h-5 w-5 text-green-500" />}
                        {test.status === 'error' && <AlertCircle className="h-5 w-5 text-red-500" />}
                        {test.status === 'missing_key' && <Clock className="h-5 w-5 text-yellow-500" />}
                        <div>
                          <p className="font-medium">{test.service}</p>
                          <p className="text-sm text-muted-foreground">{test.message}</p>
                        </div>
                      </div>
                      {test.responseTime && (
                        <Badge variant="outline" className="text-xs">
                          {test.responseTime}ms
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EnhancedAIServiceManager;
