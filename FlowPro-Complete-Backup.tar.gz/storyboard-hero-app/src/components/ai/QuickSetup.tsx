import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Badge } from '../ui/badge';
import { Alert, AlertDescription } from '../ui/alert';
import { 
  Brain, 
  Database, 
  Workflow, 
  Bot, 
  Sparkles,
  ExternalLink,
  Copy,
  CheckCircle,
  Info
} from 'lucide-react';
import { toast } from '../../hooks/use-toast';

interface QuickSetupProps {
  onComplete: (apiKeys: any) => void;
}

export const QuickSetup: React.FC<QuickSetupProps> = ({ onComplete }) => {
  const [apiKeys, setApiKeys] = useState({
    google: '',
    supabase: '',
    bubble: '',
    lovable: '',
    minimax: ''
  });

  const [currentStep, setCurrentStep] = useState(0);

  const setupSteps = [
    {
      id: 'google',
      title: 'Google AI Studio',
      icon: <Brain className="h-5 w-5" />,
      required: true,
      description: 'AI-powered script analysis and content generation',
      instructions: [
        'Go to https://aistudio.google.com',
        'Sign in with your Google account',
        'Click "Get API Key" in the sidebar',
        'Create API key and copy it'
      ],
      testPrompt: 'Analyze this short script: "FADE IN: INT. COFFEE SHOP - DAY\\nJOHN sits alone, writing."',
      url: 'https://aistudio.google.com'
    },
    {
      id: 'supabase',
      title: 'Supabase',
      icon: <Database className="h-5 w-5" />,
      required: true,
      description: 'Cloud database and real-time collaboration',
      instructions: [
        'Go to https://supabase.com',
        'Create a new project',
        'Get your Project URL from Settings → API',
        'Copy the project URL (not the API key for now)'
      ],
      testPrompt: 'Test database connection',
      url: 'https://supabase.com'
    },
    {
      id: 'minimax',
      title: 'MiniMax',
      icon: <Sparkles className="h-5 w-5" />,
      required: false,
      description: 'Advanced image, video, and audio generation',
      instructions: [
        'Go to MiniMax platform',
        'Sign up for an account',
        'Get your API key from dashboard',
        'Copy the API key'
      ],
      testPrompt: 'Generate a professional storyboard image',
      url: '#'
    }
  ];

  const handleInputChange = (service: string, value: string) => {
    setApiKeys(prev => ({
      ...prev,
      [service]: value
    }));
  };

  const handleTestService = async (service: any) => {
    const apiKey = apiKeys[service.id as keyof typeof apiKeys];
    if (!apiKey) {
      toast({
        title: "Missing API Key",
        description: "Please enter an API key first",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Testing Connection",
      description: `Testing ${service.title}...`,
    });

    // Simple validation for demo
    setTimeout(() => {
      toast({
        title: "Connection Successful",
        description: `${service.title} is properly configured!`,
      });
    }, 2000);
  };

  const handleComplete = () => {
    // Check required services
    const requiredServices = setupSteps.filter(s => s.required);
    const missingRequired = requiredServices.filter(s => !apiKeys[s.id as keyof typeof apiKeys]);
    
    if (missingRequired.length > 0) {
      toast({
        title: "Missing Required Services",
        description: `Please configure: ${missingRequired.map(s => s.title).join(', ')}`,
        variant: "destructive"
      });
      return;
    }

    // Save to localStorage
    localStorage.setItem('flowpro-api-keys', JSON.stringify(apiKeys));
    
    toast({
      title: "Setup Complete!",
      description: "FlowPro is now connected to your AI services.",
    });

    onComplete(apiKeys);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Prompt copied to clipboard",
    });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">🚀 FlowPro Quick Setup</h1>
        <p className="text-muted-foreground">
          Connect your AI services in just a few minutes
        </p>
      </div>

      <Tabs defaultValue="google" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          {setupSteps.map((step) => (
            <TabsTrigger 
              key={step.id} 
              value={step.id} 
              className="flex items-center gap-2"
            >
              {step.icon}
              {step.title}
              {step.required && <Badge variant="destructive" className="text-xs">Required</Badge>}
            </TabsTrigger>
          ))}
        </TabsList>

        {setupSteps.map((step) => (
          <TabsContent key={step.id} value={step.id} className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {step.icon}
                  {step.title}
                  {step.required && <Badge variant="destructive">Required</Badge>}
                </CardTitle>
                <CardDescription>{step.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Instructions */}
                <div className="space-y-2">
                  <Label>Setup Instructions</Label>
                  <div className="bg-muted p-4 rounded-lg space-y-2">
                    {step.instructions.map((instruction, index) => (
                      <div key={index} className="flex items-start gap-2">
                        <Badge variant="outline" className="text-xs mt-0.5">
                          {index + 1}
                        </Badge>
                        <span className="text-sm">{instruction}</span>
                      </div>
                    ))}
                  </div>
                  {step.url !== '#' && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => window.open(step.url, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Open {step.title}
                    </Button>
                  )}
                </div>

                {/* API Key Input */}
                <div className="space-y-2">
                  <Label htmlFor={`${step.id}-key`}>
                    {step.id === 'supabase' ? 'Project URL' : 'API Key'}
                  </Label>
                  <Input
                    id={`${step.id}-key`}
                    type="password"
                    placeholder={
                      step.id === 'supabase' 
                        ? 'https://your-project.supabase.co' 
                        : 'Enter your API key here...'
                    }
                    value={apiKeys[step.id as keyof typeof apiKeys]}
                    onChange={(e) => handleInputChange(step.id, e.target.value)}
                  />
                </div>

                {/* Test Prompt */}
                <div className="space-y-2">
                  <Label>Test Prompt</Label>
                  <div className="flex gap-2">
                    <div className="flex-1 bg-muted p-3 rounded text-sm font-mono">
                      {step.testPrompt}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(step.testPrompt)}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Test Button */}
                <Button 
                  onClick={() => handleTestService(step)}
                  disabled={!apiKeys[step.id as keyof typeof apiKeys]}
                  className="w-full"
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Test {step.title} Connection
                </Button>

                {/* Tips */}
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Tip:</strong> {
                      step.id === 'google' 
                        ? 'Google AI Studio offers free tier with generous limits for testing.'
                        : step.id === 'supabase'
                        ? 'Supabase provides 500MB free database and real-time features.'
                        : 'This service is optional but enhances FlowPro capabilities.'
                    }
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Complete Setup */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <h3 className="text-lg font-semibold">Ready to Start?</h3>
            <p className="text-muted-foreground">
              Configure at least Google AI Studio and Supabase to get started
            </p>
            <Button onClick={handleComplete} size="lg" className="px-8">
              Complete Setup & Start Using FlowPro
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default QuickSetup;
