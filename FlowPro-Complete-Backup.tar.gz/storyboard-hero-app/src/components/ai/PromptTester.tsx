import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { 
  Play, 
  Copy, 
  Download, 
  Wand2,
  Brain,
  Image,
  Video,
  Mic,
  Settings,
  TrendingUp,
  Workflow,
  Sparkles
} from 'lucide-react';
import { toast } from '../../hooks/use-toast';
import { PROMPT_LIBRARY, QUICK_TEST_PROMPTS, replaceVariables, PromptTemplate } from '../../utils/apiPrompts';

export const PromptTester: React.FC = () => {
  const [selectedPrompt, setSelectedPrompt] = useState<PromptTemplate | null>(null);
  const [variables, setVariables] = useState<Record<string, string>>({});
  const [customPrompt, setCustomPrompt] = useState('');
  const [activeService, setActiveService] = useState<string>('google');
  const [isExecuting, setIsExecuting] = useState(false);
  const [result, setResult] = useState<string>('');

  const services = [
    { id: 'google', name: 'Google AI Studio', icon: <Brain className="h-4 w-4" />, color: 'bg-blue-100 text-blue-800' },
    { id: 'minimax', name: 'MiniMax', icon: <Sparkles className="h-4 w-4" />, color: 'bg-orange-100 text-orange-800' },
    { id: 'deepseek', name: 'DeepSeek', icon: <Brain className="h-4 w-4" />, color: 'bg-purple-100 text-purple-800' },
    { id: 'openai', name: 'OpenAI/ChatGPT', icon: <Wand2 className="h-4 w-4" />, color: 'bg-green-100 text-green-800' }
  ];

  const categories = [
    { id: 'script_analysis', name: 'Script Analysis', icon: <Brain className="h-4 w-4" /> },
    { id: 'character_creation', name: 'Character Creation', icon: <Brain className="h-4 w-4" /> },
    { id: 'scene_description', name: 'Scene Description', icon: <Brain className="h-4 w-4" /> },
    { id: 'image_generation', name: 'Image Generation', icon: <Image className="h-4 w-4" /> },
    { id: 'video_generation', name: 'Video Generation', icon: <Video className="h-4 w-4" /> },
    { id: 'audio_generation', name: 'Audio Generation', icon: <Mic className="h-4 w-4" /> },
    { id: 'reasoning', name: 'Advanced Reasoning', icon: <Brain className="h-4 w-4" /> },
    { id: 'content_generation', name: 'Content Generation', icon: <Wand2 className="h-4 w-4" /> },
    { id: 'production_planning', name: 'Production Planning', icon: <Settings className="h-4 w-4" /> },
    { id: 'market_analysis', name: 'Market Analysis', icon: <TrendingUp className="h-4 w-4" /> }
  ];

  const getServicePrompts = (serviceId: string) => {
    return PROMPT_LIBRARY.filter(prompt => prompt.service === serviceId);
  };

  const handlePromptSelect = (promptId: string) => {
    const prompt = PROMPT_LIBRARY.find(p => p.id === promptId);
    setSelectedPrompt(prompt || null);
    if (prompt?.variables) {
      const newVariables: Record<string, string> = {};
      prompt.variables.forEach(variable => {
        newVariables[variable] = '';
      });
      setVariables(newVariables);
    }
  };

  const handleVariableChange = (variable: string, value: string) => {
    setVariables(prev => ({
      ...prev,
      [variable]: value
    }));
  };

  const handleExecutePrompt = async () => {
    setIsExecuting(true);
    
    let finalPrompt = '';
    if (selectedPrompt) {
      finalPrompt = replaceVariables(selectedPrompt.prompt, variables);
    } else {
      finalPrompt = customPrompt;
    }

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock response based on service
      let mockResponse = '';
      if (activeService === 'google') {
        mockResponse = `{
  "analysis": "Successfully analyzed content",
  "characters": ["Character 1", "Character 2"],
  "scenes": ["Scene 1: Location", "Scene 2: Location"],
  "complexity": "medium",
  "estimated_duration": "15 minutes"
}`;
      } else if (activeService === 'minimax') {
        mockResponse = 'Image/Video generation request submitted successfully. Processing time: ~2-3 minutes.';
      } else {
        mockResponse = 'Service request completed successfully.';
      }
      
      setResult(mockResponse);
      
      toast({
        title: "Prompt Executed",
        description: `Successfully executed prompt using ${services.find(s => s.id === activeService)?.name}`,
      });
    } catch (error) {
      toast({
        title: "Execution Failed",
        description: "Failed to execute prompt. Please check your API configuration.",
        variant: "destructive",
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleQuickTest = (service: string) => {
    const testPrompt = QUICK_TEST_PROMPTS[service as keyof typeof QUICK_TEST_PROMPTS];
    if (typeof testPrompt === 'string') {
      setCustomPrompt(testPrompt);
    } else {
      setCustomPrompt((testPrompt as any).basic || Object.values(testPrompt)[0] || '');
    }
    setActiveService(service);
    setSelectedPrompt(null);
  };

  const copyPrompt = () => {
    const promptText = selectedPrompt 
      ? replaceVariables(selectedPrompt.prompt, variables)
      : customPrompt;
    
    navigator.clipboard.writeText(promptText);
    toast({
      title: "Copied",
      description: "Prompt copied to clipboard",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">🧪 Prompt Tester</h2>
          <p className="text-muted-foreground">
            Test and experiment with AI prompts for different services
          </p>
        </div>
      </div>

      <Tabs defaultValue="library" className="space-y-4">
        <TabsList>
          <TabsTrigger value="library">Prompt Library</TabsTrigger>
          <TabsTrigger value="custom">Custom Prompt</TabsTrigger>
          <TabsTrigger value="quick">Quick Tests</TabsTrigger>
        </TabsList>

        <TabsContent value="library" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Service Selection & Prompts */}
            <Card>
              <CardHeader>
                <CardTitle>Select Service & Prompt</CardTitle>
                <CardDescription>
                  Choose an AI service and prompt template
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Service Selection */}
                <div className="space-y-2">
                  <Label>AI Service</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {services.map((service) => (
                      <Button
                        key={service.id}
                        variant={activeService === service.id ? "default" : "outline"}
                        size="sm"
                        onClick={() => setActiveService(service.id)}
                        className="justify-start"
                      >
                        {service.icon}
                        <span className="ml-2">{service.name}</span>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Prompt Selection */}
                <div className="space-y-2">
                  <Label>Prompt Template</Label>
                  <Select onValueChange={handlePromptSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a prompt template" />
                    </SelectTrigger>
                    <SelectContent>
                      {getServicePrompts(activeService).map((prompt) => (
                        <SelectItem key={prompt.id} value={prompt.id}>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {prompt.category}
                            </Badge>
                            {prompt.name}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Variables */}
                {selectedPrompt?.variables && (
                  <div className="space-y-3">
                    <Label>Prompt Variables</Label>
                    {selectedPrompt.variables.map((variable) => (
                      <div key={variable} className="space-y-1">
                        <Label className="text-sm text-muted-foreground capitalize">
                          {variable.replace('_', ' ')}
                        </Label>
                        <Input
                          placeholder={`Enter ${variable.replace('_', ' ')}`}
                          value={variables[variable] || ''}
                          onChange={(e) => handleVariableChange(variable, e.target.value)}
                        />
                      </div>
                    ))}
                    {selectedPrompt.example && (
                      <div className="text-xs text-muted-foreground">
                        <span className="font-medium">Example:</span> {selectedPrompt.example}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Prompt Preview & Execution */}
            <Card>
              <CardHeader>
                <CardTitle>Prompt Preview</CardTitle>
                <CardDescription>
                  Review and execute your prompt
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {selectedPrompt && (
                  <div className="space-y-2">
                    <Label>Generated Prompt</Label>
                    <Textarea
                      value={replaceVariables(selectedPrompt.prompt, variables)}
                      readOnly
                      rows={8}
                      className="font-mono text-sm"
                    />
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    onClick={handleExecutePrompt}
                    disabled={isExecuting || (!selectedPrompt && !customPrompt)}
                    className="flex-1"
                  >
                    {isExecuting ? (
                      <>
                        <Wand2 className="h-4 w-4 mr-2 animate-spin" />
                        Executing...
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Execute Prompt
                      </>
                    )}
                  </Button>
                  <Button variant="outline" size="icon" onClick={copyPrompt}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>

                {result && (
                  <div className="space-y-2">
                    <Label>Result</Label>
                    <div className="bg-muted p-3 rounded text-sm font-mono max-h-40 overflow-auto">
                      {result}
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download Result
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="custom" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Custom Prompt Testing</CardTitle>
              <CardDescription>
                Write and test your own custom prompts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Service</Label>
                <Select value={activeService} onValueChange={setActiveService}>
                  <SelectTrigger className="w-64">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        <div className="flex items-center gap-2">
                          {service.icon}
                          {service.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Custom Prompt</Label>
                <Textarea
                  placeholder="Enter your custom prompt here..."
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  rows={10}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  onClick={handleExecutePrompt}
                  disabled={isExecuting || !customPrompt.trim()}
                  className="flex-1"
                >
                  {isExecuting ? (
                    <>
                      <Wand2 className="h-4 w-4 mr-2 animate-spin" />
                      Executing...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Execute Custom Prompt
                    </>
                  )}
                </Button>
                <Button variant="outline" size="icon" onClick={copyPrompt}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quick" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {services.map((service) => (
              <Card key={service.id}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {service.icon}
                    {service.name}
                  </CardTitle>
                  <CardDescription>
                    Quick test prompt for {service.name}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-sm bg-muted p-3 rounded">
                      {(() => {
                        const testPrompt = QUICK_TEST_PROMPTS[service.id as keyof typeof QUICK_TEST_PROMPTS];
                        if (typeof testPrompt === 'string') {
                          return testPrompt;
                        } else {
                          return (testPrompt as any).basic || Object.values(testPrompt)[0] || 'No test prompt available';
                        }
                      })()}
                    </div>
                    <Button
                      onClick={() => handleQuickTest(service.id)}
                      className="w-full"
                      variant="outline"
                    >
                      <Play className="h-4 w-4 mr-2" />
                      Quick Test
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default PromptTester;
