import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { 
  Brain, 
  Database, 
  Workflow, 
  Bot, 
  Sparkles,
  FileText,
  Users,
  Image,
  Video,
  Calendar,
  DollarSign,
  Settings,
  Shield,
  BarChart3,
  Wand2,
  Code,
  Palette,
  ExternalLink,
  CheckCircle
} from 'lucide-react';

export const AIServicesGuide: React.FC = () => {
  const services = [
    {
      id: 'google',
      name: 'Google AI Studio (Gemini)',
      icon: <Brain className="h-6 w-6" />,
      role: 'Script Intelligence & Content Analysis',
      color: 'bg-blue-100 text-blue-800 border-blue-200',
      priority: 'Essential',
      priorityColor: 'bg-red-100 text-red-800',
      capabilities: [
        {
          category: 'Script Analysis',
          icon: <FileText className="h-4 w-4" />,
          features: [
            'Extract characters, scenes, and locations automatically',
            'Analyze script complexity and budget requirements',
            'Generate shooting schedules and timeline estimates',
            'Identify potential continuity issues'
          ]
        },
        {
          category: 'Character Development',
          icon: <Users className="h-4 w-4" />,
          features: [
            'Create detailed character profiles and backstories',
            'Analyze dialogue patterns and character arcs',
            'Generate casting suggestions and requirements',
            'Develop costume and makeup notes'
          ]
        },
        {
          category: 'Production Planning',
          icon: <Calendar className="h-4 w-4" />,
          features: [
            'Convert scenes into detailed shot lists',
            'Generate director notes and production insights',
            'Create budget breakdowns by scene complexity',
            'Analyze genre-specific requirements'
          ]
        }
      ]
    },
    {
      id: 'minimax',
      name: 'MiniMax',
      icon: <Sparkles className="h-6 w-6" />,
      role: 'Visual Content Generation',
      color: 'bg-orange-100 text-orange-800 border-orange-200',
      priority: 'High Value',
      priorityColor: 'bg-orange-100 text-orange-800',
      capabilities: [
        {
          category: 'Storyboard Creation',
          icon: <Image className="h-4 w-4" />,
          features: [
            'Generate professional storyboard frames',
            'Multiple artistic styles (photorealistic, sketch, etc.)',
            'Consistent character and location visuals',
            'Fast iteration and style variations'
          ]
        },
        {
          category: 'Video Production',
          icon: <Video className="h-4 w-4" />,
          features: [
            'Create animatics from storyboards',
            'Generate preview animations and transitions',
            'Produce video mockups for client presentations',
            'Animate character movements and camera angles'
          ]
        },
        {
          category: 'Audio Enhancement',
          icon: <Wand2 className="h-4 w-4" />,
          features: [
            'Generate voice-over for presentations',
            'Create temp audio for animatics',
            'Produce sound effect descriptions',
            'Generate narration for storyboard presentations'
          ]
        }
      ]
    },
    {
      id: 'supabase',
      name: 'Supabase',
      icon: <Database className="h-6 w-6" />,
      role: 'Data & Collaboration Hub',
      color: 'bg-green-100 text-green-800 border-green-200',
      priority: 'Essential',
      priorityColor: 'bg-red-100 text-red-800',
      capabilities: [
        {
          category: 'Project Storage',
          icon: <Database className="h-4 w-4" />,
          features: [
            'Store all scripts, storyboards, and project files',
            'Automatic backup and version control',
            'Fast search across all project content',
            'Secure cloud storage with unlimited access'
          ]
        },
        {
          category: 'Team Collaboration',
          icon: <Users className="h-4 w-4" />,
          features: [
            'Real-time collaborative editing',
            'Live comments and feedback system',
            'Track changes and revision history',
            'Role-based access and permissions'
          ]
        },
        {
          category: 'Security & Analytics',
          icon: <Shield className="h-4 w-4" />,
          features: [
            'Enterprise-grade security and encryption',
            'Project analytics and usage tracking',
            'User management and access controls',
            'Complete audit trail of all changes'
          ]
        }
      ]
    },
    {
      id: 'deepseek',
      name: 'DeepSeek AI',
      icon: <Brain className="h-6 w-6" />,
      role: 'Advanced Reasoning & Analysis',
      color: 'bg-purple-100 text-purple-800 border-purple-200',
      priority: 'Cost-Effective',
      priorityColor: 'bg-green-100 text-green-800',
      capabilities: [
        {
          category: 'Advanced Reasoning',
          icon: <Brain className="h-4 w-4" />,
          features: [
            'Complex script logic analysis and validation',
            'Advanced character development insights',
            'Story structure optimization suggestions',
            'Production planning with cost analysis'
          ]
        },
        {
          category: 'Cost Efficiency',
          icon: <DollarSign className="h-4 w-4" />,
          features: [
            'Ultra-low pricing: $0.01/M tokens vs $30/M competitors',
            '98% cost reduction compared to premium AI',
            'OpenAI-compatible API for easy integration',
            'No compromise on quality or performance'
          ]
        },
        {
          category: 'Technical Excellence',
          icon: <Settings className="h-4 w-4" />,
          features: [
            'State-of-the-art reasoning capabilities',
            'Extended context for long-form scripts',
            'Multi-step logical analysis',
            'Professional-grade outputs'
          ]
        }
      ]
    },
    {
      id: 'openai',
      name: 'ChatGPT/OpenAI',
      icon: <Bot className="h-6 w-6" />,
      role: 'Versatile AI Assistant & Content Generation',
      color: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      priority: 'Versatile',
      priorityColor: 'bg-blue-100 text-blue-800',
      capabilities: [
        {
          category: 'Script Writing',
          icon: <FileText className="h-4 w-4" />,
          features: [
            'Natural dialogue generation and enhancement',
            'Scene description and action writing',
            'Character voice consistency',
            'Creative brainstorming and ideation'
          ]
        },
        {
          category: 'Content Enhancement',
          icon: <Wand2 className="h-4 w-4" />,
          features: [
            'Script editing and refinement',
            'Tone and style adjustments',
            'Genre-specific writing assistance',
            'Plot development and story structure'
          ]
        },
        {
          category: 'Creative Support',
          icon: <Sparkles className="h-4 w-4" />,
          features: [
            'Creative problem-solving for plot issues',
            'Alternative scene suggestions',
            'Character backstory development',
            'Marketing and synopsis creation'
          ]
        }
      ]
    }
  ];

  const workflowSteps = [
    { step: 1, service: 'Google AI', action: 'Analyzes and breaks down your script intelligently', icon: <FileText className="h-4 w-4" /> },
    { step: 2, service: 'DeepSeek + ChatGPT', action: 'Advanced reasoning and content enhancement', icon: <Brain className="h-4 w-4" /> },
    { step: 3, service: 'MiniMax', action: 'Generates storyboard visuals, videos, and audio', icon: <Image className="h-4 w-4" /> },
    { step: 4, service: 'Supabase', action: 'Stores everything and enables team collaboration', icon: <Users className="h-4 w-4" /> }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <h1 className="text-3xl font-bold">🎬 AI-Powered Film Production</h1>
        <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
          Discover how 5 powerful AI platforms work together to transform your film production workflow, 
          from script to screen.
        </p>
      </div>

      {/* Quick Workflow */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Workflow className="h-5 w-5" />
            Complete AI Workflow
          </CardTitle>
          <CardDescription>
            See how all AI services work together in your production pipeline
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {workflowSteps.map((item, index) => (
              <div key={index} className="flex items-center gap-4 p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-center w-8 h-8 bg-primary text-primary-foreground rounded-full text-sm font-bold">
                  {item.step}
                </div>
                <div className="flex items-center gap-2 text-sm">
                  {item.icon}
                  <span className="font-medium">{item.service}</span>
                </div>
                <div className="flex-1 text-sm text-muted-foreground">
                  {item.action}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Services Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {services.map((service) => (
          <Card key={service.id} className="h-full">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-lg ${service.color}`}>
                    {service.icon}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{service.name}</CardTitle>
                    <CardDescription className="font-medium">
                      {service.role}
                    </CardDescription>
                  </div>
                </div>
                <Badge variant="outline" className={service.priorityColor}>
                  {service.priority}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {service.capabilities.map((capability, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex items-center gap-2 font-medium text-sm">
                    {capability.icon}
                    {capability.category}
                  </div>
                  <ul className="space-y-1 ml-6">
                    {capability.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <CheckCircle className="h-3 w-3 mt-0.5 text-green-600 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Setup Priority */}
      <Card>
        <CardHeader>
          <CardTitle>🚀 Recommended Setup Order</CardTitle>
          <CardDescription>
            Start with essentials, then add productivity boosters as your projects grow
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-3">
              <Badge className="bg-red-100 text-red-800">Essential - Start Here</Badge>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Brain className="h-4 w-4" />
                  <span className="font-medium">Google AI Studio</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Database className="h-4 w-4" />
                  <span className="font-medium">Supabase</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <Badge className="bg-green-100 text-green-800">Cost-Effective AI</Badge>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Brain className="h-4 w-4" />
                  <span className="font-medium">DeepSeek</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Bot className="h-4 w-4" />
                  <span className="font-medium">ChatGPT</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <Badge className="bg-blue-100 text-blue-800">Visual Creation</Badge>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Sparkles className="h-4 w-4" />
                  <span className="font-medium">MiniMax</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Benefits Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <h3 className="text-xl font-bold">Why Use AI in Film Production?</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div className="space-y-2">
                <div className="text-2xl">⚡</div>
                <div className="font-medium">Faster Production</div>
                <div className="text-muted-foreground">90% faster script breakdown and planning</div>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">💰</div>
                <div className="font-medium">Cost Reduction</div>
                <div className="text-muted-foreground">Reduce pre-production costs by 70%</div>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">🎨</div>
                <div className="font-medium">Enhanced Creativity</div>
                <div className="text-muted-foreground">More time for creative decisions</div>
              </div>
              <div className="space-y-2">
                <div className="text-2xl">👥</div>
                <div className="font-medium">Better Collaboration</div>
                <div className="text-muted-foreground">Real-time team coordination</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AIServicesGuide;