import React, { useState } from 'react';
import { Brain, Settings, CreditCard, Zap, Image, Upload, Download, Play, Pause, MoreHorizontal } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { toast } from 'sonner';
import { AIService, AIServiceType, AIGenerationRequest, GenerationStatus } from '../../types';

const AIServiceManager: React.FC = () => {
  const [services, setServices] = useState<AIService[]>([
    {
      id: 'midjourney',
      name: 'Midjourney',
      type: 'midjourney',
      isConnected: false,
      accountInfo: {
        planType: 'free',
        subscriptionStatus: 'inactive',
        creditsRemaining: 0
      },
      capabilities: ['text_to_image', 'style_transfer', 'upscaling'],
      promptTemplates: [],
      pricing: {
        costPerGeneration: 0.25,
        currency: 'USD'
      }
    },
    {
      id: 'openart',
      name: 'OpenArt AI',
      type: 'openart',
      isConnected: false,
      accountInfo: {
        planType: 'free',
        subscriptionStatus: 'inactive',
        creditsRemaining: 0
      },
      capabilities: ['text_to_image', 'image_to_image', 'style_transfer'],
      promptTemplates: [],
      pricing: {
        costPerGeneration: 0.15,
        currency: 'USD'
      }
    },
    {
      id: 'internal',
      name: 'FlowPro AI',
      type: 'internal',
      isConnected: true,
      accountInfo: {
        planType: 'pro',
        subscriptionStatus: 'active',
        creditsRemaining: 500
      },
      capabilities: ['text_to_image', 'technical_prompts', 'camera_control'],
      promptTemplates: []
    }
  ]);

  const [isConnectDialogOpen, setIsConnectDialogOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<AIService | null>(null);
  const [generationQueue, setGenerationQueue] = useState<AIGenerationRequest[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleConnectService = (service: AIService) => {
    setSelectedService(service);
    setIsConnectDialogOpen(true);
  };

  const handleServiceConnection = (serviceId: string, apiKey: string) => {
    setServices(prev => prev.map(service => 
      service.id === serviceId 
        ? { 
            ...service, 
            isConnected: true,
            accountInfo: {
              ...service.accountInfo!,
              subscriptionStatus: 'active',
              creditsRemaining: 100
            }
          }
        : service
    ));
    setIsConnectDialogOpen(false);
    toast.success(`Connected to ${selectedService?.name} successfully!`);
  };

  const handleDisconnectService = (serviceId: string) => {
    setServices(prev => prev.map(service => 
      service.id === serviceId 
        ? { 
            ...service, 
            isConnected: false,
            accountInfo: {
              ...service.accountInfo!,
              subscriptionStatus: 'inactive'
            }
          }
        : service
    ));
    toast.info(`Disconnected from service`);
  };

  const getServiceStatusColor = (service: AIService) => {
    if (!service.isConnected) return 'bg-gray-500';
    
    switch (service.accountInfo?.subscriptionStatus) {
      case 'active': return 'bg-green-500';
      case 'trial': return 'bg-blue-500';
      case 'expired': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getServiceStatusText = (service: AIService) => {
    if (!service.isConnected) return 'Disconnected';
    
    switch (service.accountInfo?.subscriptionStatus) {
      case 'active': return 'Active';
      case 'trial': return 'Trial';
      case 'expired': return 'Expired';
      case 'inactive': return 'Inactive';
      default: return 'Unknown';
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">AI Services</h1>
        <p className="text-muted-foreground">Manage your AI image generation services and accounts</p>
      </div>

      <Tabs defaultValue="services" className="w-full">
        <TabsList className="grid grid-cols-4 w-full max-w-md">
          <TabsTrigger value="services">Services</TabsTrigger>
          <TabsTrigger value="queue">Queue</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-6">
          {/* AI Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service) => (
              <Card key={service.id} className="relative overflow-hidden">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center space-x-2">
                      <Brain className="w-5 h-5" />
                      <span>{service.name}</span>
                    </CardTitle>
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${getServiceStatusColor(service)}`}></div>
                      <Badge variant={service.isConnected ? 'default' : 'secondary'}>
                        {getServiceStatusText(service)}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Account Info */}
                  {service.isConnected && service.accountInfo && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Plan:</span>
                        <span className="capitalize">{service.accountInfo.planType}</span>
                      </div>
                      
                      {service.accountInfo.creditsRemaining !== undefined && (
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Credits:</span>
                            <span>{service.accountInfo.creditsRemaining}</span>
                          </div>
                          <Progress 
                            value={(service.accountInfo.creditsRemaining / (service.accountInfo.monthlyLimit || 100)) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {/* Capabilities */}
                  <div>
                    <div className="text-sm font-medium mb-2">Capabilities</div>
                    <div className="flex flex-wrap gap-1">
                      {service.capabilities.map((capability) => (
                        <Badge key={capability} variant="outline" className="text-xs">
                          {capability.replace('_', ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Pricing */}
                  {service.pricing && (
                    <div className="text-sm">
                      <span className="text-muted-foreground">Cost: </span>
                      <span>${service.pricing.costPerGeneration}/generation</span>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex space-x-2 pt-2">
                    {service.isConnected ? (
                      <>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDisconnectService(service.id)}
                        >
                          Disconnect
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </>
                    ) : (
                      <Button 
                        size="sm" 
                        onClick={() => handleConnectService(service)}
                        className="w-full"
                      >
                        Connect Service
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quick Generation Test */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Generation Test</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="test-prompt">Test Prompt</Label>
                  <Textarea 
                    id="test-prompt"
                    placeholder="Enter a test prompt to try your AI services..."
                    className="min-h-[100px]"
                  />
                </div>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="test-service">AI Service</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select AI service" />
                      </SelectTrigger>
                      <SelectContent>
                        {services.filter(s => s.isConnected).map(service => (
                          <SelectItem key={service.id} value={service.id}>
                            {service.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full">
                    <Zap className="w-4 h-4 mr-2" />
                    Generate Test Image
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="queue" className="space-y-6">
          {/* Generation Queue */}
          <Card>
            <CardHeader>
              <CardTitle>Generation Queue</CardTitle>
              <div className="flex items-center space-x-2">
                <Button size="sm" variant="outline">
                  <Play className="w-4 h-4 mr-2" />
                  Start Queue
                </Button>
                <Button size="sm" variant="outline">
                  <Pause className="w-4 h-4 mr-2" />
                  Pause Queue
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {generationQueue.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Image className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No generations in queue</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {generationQueue.map((request) => (
                    <div key={request.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="space-y-1">
                        <div className="font-medium">{request.serviceType}</div>
                        <div className="text-sm text-muted-foreground truncate max-w-md">
                          {request.prompt}
                        </div>
                        <Badge variant="outline">{request.status}</Badge>
                      </div>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          {/* AI Settings */}
          <Card>
            <CardHeader>
              <CardTitle>Generation Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Auto-generate prompts</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically enhance prompts with technical details
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Batch processing</Label>
                    <p className="text-sm text-muted-foreground">
                      Process multiple generations simultaneously
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <Separator />
                
                <div className="space-y-2">
                  <Label>Default quality</Label>
                  <Select defaultValue="high">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="ultra">Ultra</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label>Maximum concurrent generations</Label>
                  <Select defaultValue="3">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1</SelectItem>
                      <SelectItem value="3">3</SelectItem>
                      <SelectItem value="5">5</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          {/* Billing Overview */}
          <Card>
            <CardHeader>
              <CardTitle>Billing Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-primary">$24.50</div>
                  <div className="text-sm text-muted-foreground">This Month</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-green-600">156</div>
                  <div className="text-sm text-muted-foreground">Generations</div>
                </div>
                <div className="text-center p-4 border rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">$0.16</div>
                  <div className="text-sm text-muted-foreground">Avg. Cost</div>
                </div>
              </div>
              
              <div className="space-y-4">
                <h4 className="font-medium">Service Costs</h4>
                {services.filter(s => s.isConnected).map(service => (
                  <div key={service.id} className="flex justify-between items-center">
                    <span>{service.name}</span>
                    <span className="text-muted-foreground">
                      ${service.pricing?.costPerGeneration || 0}/generation
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Connect Service Dialog */}
      <Dialog open={isConnectDialogOpen} onOpenChange={setIsConnectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Connect to {selectedService?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-key">API Key</Label>
              <Input
                id="api-key"
                type="password"
                placeholder="Enter your API key"
              />
              <p className="text-sm text-muted-foreground">
                Your API key will be stored securely and used only for image generation.
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="account-email">Account Email (Optional)</Label>
              <Input
                id="account-email"
                type="email"
                placeholder="your@email.com"
              />
            </div>
            
            <div className="flex space-x-2">
              <Button 
                onClick={() => handleServiceConnection(selectedService?.id || '', '')}
                className="flex-1"
              >
                Connect Service
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setIsConnectDialogOpen(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AIServiceManager;
