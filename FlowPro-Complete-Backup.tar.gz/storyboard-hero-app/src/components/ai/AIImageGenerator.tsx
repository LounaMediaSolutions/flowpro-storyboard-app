import React, { useState } from 'react';
import { Wand2, Settings, Camera, Lightbulb, Palette, Upload, Download, Copy, RefreshCw, Zap, Eye } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Slider } from '../ui/slider';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { toast } from 'sonner';
import { Shot, AIServiceType, TechnicalPromptBuilder, AIGenerationParameters } from '../../types';
import AIPromptGenerator from '../../utils/aiPromptGenerator';

interface AIImageGeneratorProps {
  shot: Shot;
  onImageGenerated: (imageUrl: string, prompt: string) => void;
  onClose: () => void;
}

const AIImageGenerator: React.FC<AIImageGeneratorProps> = ({
  shot,
  onImageGenerated,
  onClose
}) => {
  const [selectedService, setSelectedService] = useState<AIServiceType>('midjourney');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [customPrompt, setCustomPrompt] = useState('');
  const [useAutoPrompt, setUseAutoPrompt] = useState(true);
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [parameters, setParameters] = useState<AIGenerationParameters>({
    aspectRatio: '16:9',
    quality: 'high',
    styleIntensity: 70,
    creativityLevel: 60,
    variations: 1,
    upscale: false,
    negativePrompt: ''
  });

  const [advancedSettings, setAdvancedSettings] = useState({
    includeCamera: true,
    includeLighting: true,
    includeLocation: true,
    includeCharacters: true,
    includeStyle: true,
    technicalDetails: 'full'
  });

  const availableServices = [
    { id: 'midjourney', name: 'Midjourney', cost: 0.25, status: 'connected' },
    { id: 'openart', name: 'OpenArt AI', cost: 0.15, status: 'connected' },
    { id: 'dalle', name: 'DALL-E 3', cost: 0.40, status: 'disconnected' },
    { id: 'stable_diffusion', name: 'Stable Diffusion', cost: 0.05, status: 'connected' },
    { id: 'internal', name: 'FlowPro AI', cost: 0.10, status: 'connected' }
  ];

  const aspectRatios = [
    { value: '16:9', label: '16:9 (Widescreen)' },
    { value: '4:3', label: '4:3 (Standard)' },
    { value: '1:1', label: '1:1 (Square)' },
    { value: '9:16', label: '9:16 (Portrait)' },
    { value: '21:9', label: '21:9 (Cinematic)' }
  ];

  const generateTechnicalPrompt = () => {
    const builder: TechnicalPromptBuilder = {
      shotId: shot.id,
      baseDescription: shot.description,
      cameraSpecs: {
        cameraType: 'Professional camera',
        lens: shot.technicalSpecs?.lens || '50mm lens',
        focalLength: shot.technicalSpecs?.focalLength || '50mm',
        aperture: shot.technicalSpecs?.aperture || 'f/2.8',
        shutterSpeed: '1/50s',
        iso: '800',
        filterUsed: undefined,
        mountType: 'tripod',
        movement: shot.cameraMovement,
        height: shot.cameraAngle.includes('low') ? 'low angle' : 
                shot.cameraAngle.includes('high') ? 'high angle' : 'eye level',
        distance: shot.cameraAngle.includes('close') ? 'close-up' :
                 shot.cameraAngle.includes('medium') ? 'medium shot' : 'wide shot'
      },
      lightingSpecs: {
        primaryLight: {
          type: 'key light',
          intensity: 'medium',
          direction: 'front',
          color: undefined
        },
        fillLight: undefined,
        ambientLighting: 'natural',
        colorTemperature: '5600K',
        mood: 'natural',
        timeOfDay: 'morning',
        weather: undefined
      },
      locationSpecs: {
        setting: 'professional indoor location',
        atmosphere: 'professional',
        materials: [],
        colors: [],
        textures: []
      },
      characterSpecs: [],
      visualStyle: {
        overallMood: 'cinematic',
        colorPalette: [],
        grading: {
          highlights: 'neutral',
          shadows: 'neutral',
          midtones: 'neutral',
          overall: 'cinematic'
        },
        composition: {
          ruleOfThirds: true,
          depth: 'medium',
          framing: 'professional'
        },
        contrast: 'medium',
        saturation: 'natural'
      }
    };

    return AIPromptGenerator.generateTechnicalPrompt(builder, selectedService);
  };

  const handleGeneratePrompt = () => {
    if (useAutoPrompt) {
      const prompt = generateTechnicalPrompt();
      setGeneratedPrompt(prompt);
      toast.success('Technical prompt generated successfully!');
    } else {
      setGeneratedPrompt(customPrompt);
    }
  };

  const handleGenerate = async () => {
    if (!generatedPrompt && !customPrompt) {
      toast.error('Please generate or enter a prompt first');
      return;
    }

    setIsGenerating(true);
    setGenerationProgress(0);

    try {
      // Simulate generation progress
      const progressInterval = setInterval(() => {
        setGenerationProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return 95;
          }
          return prev + Math.random() * 15;
        });
      }, 500);

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 3000));

      clearInterval(progressInterval);
      setGenerationProgress(100);

      // Simulate generated image URL
      const imageUrl = `https://picsum.photos/800/450?random=${Date.now()}`;
      const usedPrompt = generatedPrompt || customPrompt;

      onImageGenerated(imageUrl, usedPrompt);
      toast.success('Image generated successfully!');
      
      setTimeout(() => {
        setIsGenerating(false);
        setGenerationProgress(0);
        onClose();
      }, 1000);

    } catch (error) {
      setIsGenerating(false);
      setGenerationProgress(0);
      toast.error('Generation failed. Please try again.');
    }
  };

  const copyPromptToClipboard = () => {
    navigator.clipboard.writeText(generatedPrompt);
    toast.success('Prompt copied to clipboard!');
  };

  const selectedServiceInfo = availableServices.find(s => s.id === selectedService);

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Wand2 className="w-5 h-5 text-primary" />
            <span>AI Image Generation</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Service Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">AI Service</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {availableServices.map((service) => (
                  <div
                    key={service.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${
                      selectedService === service.id 
                        ? 'border-primary bg-primary/5' 
                        : 'border-border hover:border-primary/50'
                    } ${service.status === 'disconnected' ? 'opacity-50' : ''}`}
                    onClick={() => service.status === 'connected' && setSelectedService(service.id as AIServiceType)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{service.name}</span>
                      <Badge variant={service.status === 'connected' ? 'default' : 'secondary'}>
                        {service.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      ${service.cost}/generation
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="prompt" className="w-full">
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="prompt">Prompt</TabsTrigger>
              <TabsTrigger value="parameters">Parameters</TabsTrigger>
              <TabsTrigger value="advanced">Advanced</TabsTrigger>
            </TabsList>

            <TabsContent value="prompt" className="space-y-4">
              {/* Prompt Generation */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Prompt Generation</span>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor="auto-prompt" className="text-sm">Auto-generate</Label>
                      <Switch 
                        id="auto-prompt"
                        checked={useAutoPrompt}
                        onCheckedChange={setUseAutoPrompt}
                      />
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {useAutoPrompt ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-muted/30 rounded-lg">
                        <div className="text-sm font-medium mb-2">Shot Information</div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div><strong>Description:</strong> {shot.description}</div>
                          <div><strong>Camera Angle:</strong> {shot.cameraAngle}</div>
                          <div><strong>Movement:</strong> {shot.cameraMovement}</div>
                          <div><strong>Shot Number:</strong> {shot.shotNumber}</div>
                          <div><strong>Duration:</strong> {shot.duration}s</div>
                        </div>
                      </div>

                      <Button 
                        onClick={handleGeneratePrompt}
                        className="w-full"
                        size="lg"
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Generate Technical Prompt
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Label htmlFor="custom-prompt">Custom Prompt</Label>
                      <Textarea
                        id="custom-prompt"
                        placeholder="Enter your custom prompt..."
                        value={customPrompt}
                        onChange={(e) => setCustomPrompt(e.target.value)}
                        className="min-h-[120px]"
                      />
                    </div>
                  )}

                  {/* Generated Prompt Display */}
                  {generatedPrompt && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Generated Prompt</Label>
                        <Button variant="outline" size="sm" onClick={copyPromptToClipboard}>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                      </div>
                      <div className="p-4 bg-muted rounded-lg">
                        <p className="text-sm">{generatedPrompt}</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="parameters" className="space-y-4">
              {/* Generation Parameters */}
              <Card>
                <CardHeader>
                  <CardTitle>Generation Parameters</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Aspect Ratio</Label>
                      <Select 
                        value={parameters.aspectRatio} 
                        onValueChange={(value) => setParameters(prev => ({ ...prev, aspectRatio: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {aspectRatios.map(ratio => (
                            <SelectItem key={ratio.value} value={ratio.value}>
                              {ratio.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Quality</Label>
                      <Select 
                        value={parameters.quality} 
                        onValueChange={(value) => setParameters(prev => ({ ...prev, quality: value as any }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="ultra">Ultra</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Style Intensity: {parameters.styleIntensity}%</Label>
                      <Slider
                        value={[parameters.styleIntensity]}
                        onValueChange={([value]) => setParameters(prev => ({ ...prev, styleIntensity: value }))}
                        max={100}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Creativity Level: {parameters.creativityLevel}%</Label>
                      <Slider
                        value={[parameters.creativityLevel]}
                        onValueChange={([value]) => setParameters(prev => ({ ...prev, creativityLevel: value }))}
                        max={100}
                        step={1}
                        className="w-full"
                      />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Generate Variations</Label>
                        <p className="text-sm text-muted-foreground">Create multiple versions</p>
                      </div>
                      <Select 
                        value={parameters.variations?.toString()} 
                        onValueChange={(value) => setParameters(prev => ({ ...prev, variations: parseInt(value) }))}
                      >
                        <SelectTrigger className="w-20">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1</SelectItem>
                          <SelectItem value="2">2</SelectItem>
                          <SelectItem value="4">4</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Auto Upscale</Label>
                        <p className="text-sm text-muted-foreground">Enhance resolution automatically</p>
                      </div>
                      <Switch 
                        checked={parameters.upscale}
                        onCheckedChange={(checked) => setParameters(prev => ({ ...prev, upscale: checked }))}
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Negative Prompt (Optional)</Label>
                    <Textarea
                      placeholder="What you don't want in the image..."
                      value={parameters.negativePrompt}
                      onChange={(e) => setParameters(prev => ({ ...prev, negativePrompt: e.target.value }))}
                      className="min-h-[80px]"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="advanced" className="space-y-4">
              {/* Advanced Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Advanced Prompt Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>Include Camera Details</Label>
                        <Switch 
                          checked={advancedSettings.includeCamera}
                          onCheckedChange={(checked) => setAdvancedSettings(prev => ({ ...prev, includeCamera: checked }))}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Include Lighting Setup</Label>
                        <Switch 
                          checked={advancedSettings.includeLighting}
                          onCheckedChange={(checked) => setAdvancedSettings(prev => ({ ...prev, includeLighting: checked }))}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Include Location Details</Label>
                        <Switch 
                          checked={advancedSettings.includeLocation}
                          onCheckedChange={(checked) => setAdvancedSettings(prev => ({ ...prev, includeLocation: checked }))}
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label>Include Characters</Label>
                        <Switch 
                          checked={advancedSettings.includeCharacters}
                          onCheckedChange={(checked) => setAdvancedSettings(prev => ({ ...prev, includeCharacters: checked }))}
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label>Include Visual Style</Label>
                        <Switch 
                          checked={advancedSettings.includeStyle}
                          onCheckedChange={(checked) => setAdvancedSettings(prev => ({ ...prev, includeStyle: checked }))}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Technical Detail Level</Label>
                        <Select 
                          value={advancedSettings.technicalDetails}
                          onValueChange={(value) => setAdvancedSettings(prev => ({ ...prev, technicalDetails: value }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="minimal">Minimal</SelectItem>
                            <SelectItem value="standard">Standard</SelectItem>
                            <SelectItem value="full">Full Details</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Generation Controls */}
          <Card>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {/* Cost Estimate */}
                {selectedServiceInfo && (
                  <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <span className="text-sm">Estimated Cost:</span>
                    <span className="font-medium">
                      ${(selectedServiceInfo.cost * (parameters.variations || 1)).toFixed(2)}
                    </span>
                  </div>
                )}

                {/* Generation Progress */}
                {isGenerating && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Generating image...</span>
                      <span>{generationProgress.toFixed(0)}%</span>
                    </div>
                    <Progress value={generationProgress} className="w-full" />
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex space-x-3">
                  <Button
                    onClick={handleGenerate}
                    disabled={isGenerating || (!generatedPrompt && !customPrompt)}
                    className="flex-1"
                    size="lg"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Generate Image
                      </>
                    )}
                  </Button>
                  
                  <Button variant="outline" onClick={onClose} size="lg">
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AIImageGenerator;
