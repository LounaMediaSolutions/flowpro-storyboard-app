import React from 'react';
import { Film, Home, FileText, Image, Download, Settings, Menu, X, Tv, Users, DollarSign, BarChart3, UserCog, Upload, Brain, Camera } from 'lucide-react';
import { Button } from '../ui/button';
import { ThemeToggle } from '../theme/ThemeToggle';
import { useStoryboardStore } from '../../store/storyboardStore';
import { cn } from '../../lib/utils';
import { useState } from 'react';

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { currentView, setCurrentView, currentProject } = useStoryboardStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Get dynamic content labels based on project type
  const getContentLabel = () => {
    if (!currentProject) return { label: 'Content', icon: Tv, description: 'Content management & organization' };
    
    switch (currentProject.projectType) {
      case 'series':
      case 'web_series':
      case 'tv_pilot':
        return { label: 'Episodes', icon: Tv, description: 'Episode management & organization' };
      case 'movie':
      case 'documentary':
        return { label: 'Acts', icon: Film, description: 'Act/sequence management & organization' };
      case 'short_film':
      case 'commercial':
      case 'music_video':
      case 'promotional':
        return { label: 'Scenes', icon: Camera, description: 'Scene management & organization' };
      case 'animation':
        return { label: 'Sequences', icon: Film, description: 'Animation sequence management' };
      default:
        return { label: 'Content', icon: Tv, description: 'Content management & organization' };
    }
  };

  const contentInfo = getContentLabel();

  // Core Film Production Features (Independent of AI)
  const coreNavigationItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home, description: 'Project overview & management', disabled: false },
    { id: 'episodes', label: contentInfo.label, icon: contentInfo.icon, description: contentInfo.description, disabled: !currentProject },
    { id: 'script', label: 'Script Editor', icon: FileText, description: 'Professional script writing', disabled: !currentProject },
    { id: 'script-import', label: 'Import Script', icon: Upload, description: 'Import Final Draft/Fountain/PDF - Available anytime!', disabled: false }, // Removed restriction!
    { id: 'storyboard', label: 'Storyboard', icon: Image, description: 'Visual scene planning', disabled: !currentProject },
    { id: 'production', label: 'Production', icon: Users, description: 'Crew & locations management', disabled: !currentProject },
    { id: 'budget', label: 'Budget', icon: DollarSign, description: 'Budget tracking & planning', disabled: !currentProject },
    { id: 'reports', label: 'Reports', icon: BarChart3, description: 'Production reports & analytics', disabled: !currentProject },
    { id: 'export', label: 'Export', icon: Download, description: 'Export & share deliverables', disabled: !currentProject },
  ] as const;

  // Optional AI Enhancement Features
  const enhancementItems = [
    { id: 'ai-services', label: 'AI Tools', icon: Brain, description: 'Optional: AI image generation', disabled: false },
    { id: 'settings', label: 'Settings', icon: Settings, description: 'API keys & configuration', disabled: false },
    { id: 'users', label: 'Users', icon: UserCog, description: 'Team & user management', disabled: false },
  ] as const;

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-72 bg-card border-r border-border transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-6 border-b border-border">
            <div className="flex items-center space-x-3">
              <img 
                src="/images/flowpro-icon.png" 
                alt="FlowPro" 
                className="w-10 h-10 rounded-xl"
              />
              <div>
                <h1 className="text-xl font-bold text-foreground">FlowPro</h1>
                <p className="text-sm text-muted-foreground">Film Production Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <ThemeToggle />
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Current Project */}
          {currentProject && (
            <div className="p-6 border-b border-border bg-muted/30">
              <div className="text-sm text-muted-foreground mb-1">Current Project</div>
              <div className="font-semibold text-foreground truncate">{currentProject.title}</div>
              <div className="text-sm text-muted-foreground truncate">{currentProject.description}</div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-6">
            {/* Core Film Production Features */}
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-3">Film Production</h3>
              <div className="space-y-2">
                {coreNavigationItems.map((item) => (
                  <Button
                    key={item.id}
                    variant={currentView === item.id ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start h-12 text-left transition-all duration-200",
                      currentView === item.id && "bg-primary text-primary-foreground hover:bg-primary/90 shadow-md",
                      item.disabled && "opacity-50 cursor-not-allowed"
                    )}
                    onClick={() => !item.disabled && setCurrentView(item.id)}
                    disabled={item.disabled}
                  >
                    <item.icon className="w-5 h-5 mr-3" />
                    <div>
                      <div className="font-medium">{item.label}</div>
                      <div className={cn(
                        "text-xs",
                        currentView === item.id ? "text-primary-foreground/80" : "text-muted-foreground"
                      )}>
                        {item.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>

            {/* Optional Enhancement Features */}
            <div>
              <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-3">Optional Tools</h3>
              <div className="space-y-2">
                {enhancementItems.map((item) => (
                  <Button
                    key={item.id}
                    variant={currentView === item.id ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start h-12 text-left transition-all duration-200",
                      currentView === item.id && "bg-primary text-primary-foreground hover:bg-primary/90 shadow-md",
                      item.disabled && "opacity-50 cursor-not-allowed"
                    )}
                    onClick={() => !item.disabled && setCurrentView(item.id)}
                    disabled={item.disabled}
                  >
                    <item.icon className="w-5 h-5 mr-3" />
                    <div>
                      <div className="font-medium">{item.label}</div>
                      <div className={cn(
                        "text-xs",
                        currentView === item.id ? "text-primary-foreground/80" : "text-muted-foreground"
                      )}>
                        {item.description}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </nav>

          {/* Footer */}
          <div className="p-6 border-t border-border">
            <Button variant="ghost" className="w-full justify-start hover:bg-accent">
              <Settings className="w-5 h-5 mr-3" />
              Settings
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden lg:ml-0">
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center justify-between p-4 border-b border-border bg-card mobile-nav">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarOpen(true)}
            className="mobile-touch-target"
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center space-x-2">
            <img 
              src="/images/flowpro-icon.png" 
              alt="FlowPro" 
              className="w-6 h-6"
            />
            <span className="font-bold text-foreground">FlowPro</span>
          </div>
          <ThemeToggle />
        </div>

        {/* Page Content */}
        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}
    </div>
  );
};

export default MainLayout;
