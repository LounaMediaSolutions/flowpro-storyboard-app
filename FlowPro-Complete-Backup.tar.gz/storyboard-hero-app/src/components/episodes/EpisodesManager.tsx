import React, { useState } from 'react';
import { Plus, Play, Edit2, Trash2, Upload, Download, Tv, Clock, Users, Calendar, FileText } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useStoryboardStore } from '../../store/storyboardStore';
import { Episode, EpisodeStatus } from '../../types';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import EpisodeScriptImporter from './EpisodeScriptImporter';

const EpisodesManager: React.FC = () => {
  const {
    currentProject,
    currentEpisode,
    createEpisode,
    updateEpisode,
    deleteEpisode,
    setCurrentEpisode,
    batchCreateEpisodes,
    setCurrentView
  } = useStoryboardStore();

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isBatchDialogOpen, setIsBatchDialogOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [importTargetEpisode, setImportTargetEpisode] = useState<Episode | null>(null);
  const [newEpisodeTitle, setNewEpisodeTitle] = useState('');
  const [newEpisodeDescription, setNewEpisodeDescription] = useState('');
  const [batchCount, setBatchCount] = useState(5);
  const [batchPrefix, setBatchPrefix] = useState('Episode');

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <Tv className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const handleCreateEpisode = () => {
    if (!newEpisodeTitle.trim()) {
      toast.error('Please enter an episode title');
      return;
    }

    createEpisode(currentProject.id, newEpisodeTitle.trim(), newEpisodeDescription.trim());
    setNewEpisodeTitle('');
    setNewEpisodeDescription('');
    setIsCreateDialogOpen(false);
    toast.success('Episode created successfully!');
  };

  const handleBatchCreate = () => {
    const episodes = Array.from({ length: batchCount }, (_, index) => ({
      title: `${batchPrefix} ${index + 1}`,
      description: `${batchPrefix} ${index + 1} description`,
      status: 'draft' as EpisodeStatus
    }));

    batchCreateEpisodes(currentProject.id, episodes);
    setIsBatchDialogOpen(false);
    toast.success(`${batchCount} episodes created successfully!`);
  };

  const handleSelectEpisode = (episode: Episode) => {
    setCurrentEpisode(episode);
    setCurrentView('script');
  };

  const handleImportScript = (episode: Episode) => {
    setImportTargetEpisode(episode);
    setIsImportDialogOpen(true);
  };

  const getEpisodeStats = (episode: Episode) => {
    const totalScenes = episode.scenes.length;
    const totalShots = episode.scenes.reduce((acc, scene) => acc + scene.shots.length, 0);
    const shotsWithImages = episode.scenes.reduce((acc, scene) => 
      acc + scene.shots.filter(shot => shot.imageUrl).length, 0
    );
    
    return { totalScenes, totalShots, shotsWithImages };
  };

  const getStatusColor = (status: EpisodeStatus) => {
    switch (status) {
      case 'draft': return 'bg-gray-500';
      case 'pre_production': return 'bg-yellow-500';
      case 'production': return 'bg-blue-500';
      case 'post_production': return 'bg-purple-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: EpisodeStatus) => {
    switch (status) {
      case 'draft': return 'Draft';
      case 'pre_production': return 'Pre-Production';
      case 'production': return 'Production';
      case 'post_production': return 'Post-Production';
      case 'completed': return 'Completed';
      default: return 'Unknown';
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Episodes Manager</h1>
          <p className="text-gray-600">Manage episodes and their production status</p>
        </div>

        <div className="flex items-center space-x-3">
          {/* Script Import Button */}
          <EpisodeScriptImporter />
          
          <Dialog open={isBatchDialogOpen} onOpenChange={setIsBatchDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Upload className="w-4 h-4 mr-2" />
                Batch Create
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Batch Create Episodes</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="batch-count">Number of Episodes</Label>
                  <Input
                    id="batch-count"
                    type="number"
                    min="1"
                    max="50"
                    value={batchCount}
                    onChange={(e) => setBatchCount(parseInt(e.target.value) || 1)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="batch-prefix">Episode Prefix</Label>
                  <Input
                    id="batch-prefix"
                    placeholder="Episode"
                    value={batchPrefix}
                    onChange={(e) => setBatchPrefix(e.target.value)}
                  />
                  <p className="text-sm text-gray-500">
                    Episodes will be named: {batchPrefix} 1, {batchPrefix} 2, etc.
                  </p>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsBatchDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleBatchCreate}>
                    Create {batchCount} Episodes
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                New Episode
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Episode</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="episode-title">Episode Title</Label>
                  <Input
                    id="episode-title"
                    placeholder="Enter episode title..."
                    value={newEpisodeTitle}
                    onChange={(e) => setNewEpisodeTitle(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="episode-description">Description</Label>
                  <Textarea
                    id="episode-description"
                    placeholder="Brief description of the episode..."
                    value={newEpisodeDescription}
                    onChange={(e) => setNewEpisodeDescription(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button 
                    variant="outline" 
                    onClick={() => setIsCreateDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleCreateEpisode} disabled={!newEpisodeTitle.trim()}>
                    Create Episode
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Current Episode */}
      {currentEpisode && (
        <Card className="border-blue-200 bg-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span className="flex items-center">
                <Tv className="w-5 h-5 mr-2 text-blue-600" />
                Current Episode: {currentEpisode.title}
              </span>
              <Badge className={`${getStatusColor(currentEpisode.status)} text-white`}>
                {getStatusLabel(currentEpisode.status)}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">{currentEpisode.description}</p>
            <div className="mt-4 flex items-center space-x-4 text-sm text-gray-600">
              <span className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                {currentEpisode.scenes.length} Scenes
              </span>
              {currentEpisode.targetDuration && (
                <span className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {currentEpisode.targetDuration}min
                </span>
              )}
              <span className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {formatDistanceToNow(new Date(currentEpisode.updatedAt), { addSuffix: true })}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Episodes Grid */}
      {currentProject.episodes.length === 0 ? (
        <div className="text-center py-12">
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center">
              <Tv className="w-8 h-8 text-gray-400" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">No episodes yet</h3>
              <p className="text-gray-600">Create episodes to organize your project into manageable parts</p>
            </div>
            <div className="flex justify-center space-x-3">
              <Button 
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Episode
              </Button>
              <Button 
                variant="outline"
                onClick={() => setIsBatchDialogOpen(true)}
              >
                <Upload className="w-4 h-4 mr-2" />
                Batch Create
              </Button>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {currentProject.episodes.map((episode) => {
            const stats = getEpisodeStats(episode);
            const completionPercentage = stats.totalShots > 0 
              ? Math.round((stats.shotsWithImages / stats.totalShots) * 100) 
              : 0;

            return (
              <Card 
                key={episode.id} 
                className={`hover:shadow-lg transition-shadow cursor-pointer group ${
                  currentEpisode?.id === episode.id ? 'ring-2 ring-blue-500' : ''
                }`}
                onClick={() => handleSelectEpisode(episode)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge variant="outline">Ep {episode.episodeNumber}</Badge>
                        <Badge className={`${getStatusColor(episode.status)} text-white text-xs`}>
                          {getStatusLabel(episode.status)}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg line-clamp-1">{episode.title}</CardTitle>
                      <p className="text-sm text-gray-600 line-clamp-2 mt-1">
                        {episode.description || 'No description'}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1 ml-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          // TODO: Edit episode dialog
                          toast.info('Episode editing coming soon!');
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Edit2 className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteEpisode(episode.id);
                          toast.success('Episode deleted');
                        }}
                        className="opacity-0 group-hover:opacity-100 transition-opacity text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="pb-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Progress</span>
                      <Badge 
                        variant={completionPercentage === 100 ? "default" : "secondary"}
                        className={completionPercentage === 100 ? "bg-green-600" : ""}
                      >
                        {completionPercentage}%
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-gray-600">Scenes</div>
                        <div className="font-semibold">{stats.totalScenes}</div>
                      </div>
                      <div>
                        <div className="text-gray-600">Shots</div>
                        <div className="font-semibold">{stats.totalShots}</div>
                      </div>
                    </div>

                    {episode.targetDuration && (
                      <div className="text-sm">
                        <div className="text-gray-600">Target Duration</div>
                        <div className="font-semibold">{episode.targetDuration}min</div>
                      </div>
                    )}

                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${completionPercentage}%` }}
                      ></div>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="pt-4 border-t">
                  <div className="flex items-center justify-between w-full">
                    <div className="text-sm text-gray-500">
                      Updated {formatDistanceToNow(new Date(episode.updatedAt), { addSuffix: true })}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button 
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleImportScript(episode);
                        }}
                        className="border-green-200 text-green-700 hover:bg-green-50"
                      >
                        <FileText className="w-4 h-4 mr-1" />
                        Import
                      </Button>
                      
                      <Button 
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectEpisode(episode);
                        }}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Open
                      </Button>
                    </div>
                  </div>
                </CardFooter>
              </Card>
            );
          })}
        </div>
      )}

      {/* Import Script Dialog */}
      <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2 text-green-600" />
              Import Script to {importTargetEpisode?.title}
            </DialogTitle>
          </DialogHeader>
          {importTargetEpisode && (
            <EpisodeScriptImporter 
              onImportComplete={(importedEpisodes) => {
                setIsImportDialogOpen(false);
                setImportTargetEpisode(null);
                toast.success(`Script imported successfully to ${importTargetEpisode.title}!`);
              }}
              targetEpisode={importTargetEpisode}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EpisodesManager;
