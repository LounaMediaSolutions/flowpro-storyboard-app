import React, { useState, useRef } from 'react';
import { 
  Upload, 
  FileText, 
  Film, 
  AlertCircle, 
  CheckCircle, 
  Loader2, 
  Download,
  Settings,
  Zap,
  Eye,
  BookOpen,
  Split,
  Tv
} from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Switch } from '../ui/switch';
import { Separator } from '../ui/separator';
import { Progress } from '../ui/progress';
import { useStoryboardStore } from '../../store/storyboardStore';
import { Episode } from '../../types';
import { toast } from 'sonner';

interface ImportSettings {
  autoSplit: boolean;
  episodeNaming: 'sequential' | 'scene_headers' | 'custom';
  customPrefix: string;
  sceneMarkers: string[];
  characterExtraction: boolean;
  locationExtraction: boolean;
  timingAnalysis: boolean;
}

interface ParsedScript {
  episodes: Array<{
    title: string;
    description: string;
    scenes: Array<{
      heading: string;
      content: string;
      characters: string[];
      location: string;
      timeOfDay: string;
      estimatedDuration: number;
    }>;
  }>;
  metadata: {
    totalPages: number;
    totalCharacters: number;
    estimatedRuntime: number;
    scriptFormat: string;
  };
}

interface EpisodeScriptImporterProps {
  onImportComplete?: (importedEpisodes: any[]) => void;
  targetEpisode?: Episode | null;
}

const EpisodeScriptImporter: React.FC<EpisodeScriptImporterProps> = ({ 
  onImportComplete,
  targetEpisode
}) => {
  const { currentProject, batchCreateEpisodes, setCurrentView } = useStoryboardStore();
  const [isOpen, setIsOpen] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState('');
  const [progress, setProgress] = useState(0);
  const [parsedScript, setParsedScript] = useState<ParsedScript | null>(null);
  const [currentStep, setCurrentStep] = useState<'upload' | 'settings' | 'preview' | 'saving' | 'analysis'>('upload');
  const [isSaving, setIsSaving] = useState(false);
  const [saveProgress, setSaveProgress] = useState(0);
  const [importedEpisodes, setImportedEpisodes] = useState<any[]>([]);
  const [importSettings, setImportSettings] = useState<ImportSettings>({
    autoSplit: true,
    episodeNaming: 'sequential',
    customPrefix: 'Episode',
    sceneMarkers: ['FADE IN:', 'EXT.', 'INT.', 'SCENE'],
    characterExtraction: true,
    locationExtraction: true,
    timingAnalysis: true
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const supportedFormats = [
    { ext: '.pdf', label: 'PDF Scripts', icon: FileText },
    { ext: '.txt', label: 'Plain Text', icon: FileText },
    { ext: '.fdx', label: 'Final Draft', icon: Film },
    { ext: '.fountain', label: 'Fountain Format', icon: BookOpen },
    { ext: '.docx', label: 'Word Documents', icon: FileText }
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileSelect = (file: File) => {
    const maxSize = 50 * 1024 * 1024; // 50MB
    
    if (file.size > maxSize) {
      toast.error('File size too large. Please select a file under 50MB.');
      return;
    }

    const supportedExts = supportedFormats.map(f => f.ext.toLowerCase());
    const fileExt = '.' + file.name.split('.').pop()?.toLowerCase();
    
    if (!supportedExts.includes(fileExt)) {
      toast.error('Unsupported file format. Please select a supported script file.');
      return;
    }

    setSelectedFile(file);
    toast.success(`Selected: ${file.name}`);
  };

  const simulateScriptParsing = async (): Promise<ParsedScript> => {
    // Simulate AI-powered script parsing
    const episodes = [];
    const episodeCount = importSettings.autoSplit ? Math.floor(Math.random() * 5) + 3 : 1;
    
    for (let i = 0; i < episodeCount; i++) {
      const sceneCount = Math.floor(Math.random() * 8) + 4;
      const scenes = [];
      
      for (let j = 0; j < sceneCount; j++) {
        scenes.push({
          heading: `${j % 2 === 0 ? 'INT' : 'EXT'}. ${['OFFICE', 'STREET', 'APARTMENT', 'RESTAURANT', 'PARK'][j % 5]} - ${['DAY', 'NIGHT'][j % 2]}`,
          content: `Scene ${j + 1} content from ${selectedFile?.name}. This scene contains dialogue and action descriptions that were extracted from the original script.`,
          characters: ['PROTAGONIST', 'ANTAGONIST', 'SUPPORTING CHARACTER'].slice(0, Math.floor(Math.random() * 3) + 1),
          location: ['Office Building', 'City Street', 'Apartment Complex', 'Restaurant', 'Public Park'][j % 5],
          timeOfDay: ['Day', 'Night'][j % 2],
          estimatedDuration: Math.floor(Math.random() * 300) + 60 // 1-5 minutes
        });
      }
      
      episodes.push({
        title: importSettings.episodeNaming === 'custom' 
          ? `${importSettings.customPrefix} ${i + 1}`
          : `Episode ${i + 1}`,
        description: `Episode ${i + 1} parsed from ${selectedFile?.name}`,
        scenes
      });
    }

    return {
      episodes,
      metadata: {
        totalPages: Math.floor(Math.random() * 50) + 30,
        totalCharacters: episodes.reduce((acc, ep) => 
          acc + ep.scenes.reduce((sceneAcc, scene) => sceneAcc + scene.characters.length, 0), 0
        ),
        estimatedRuntime: episodes.reduce((acc, ep) => 
          acc + ep.scenes.reduce((sceneAcc, scene) => sceneAcc + scene.estimatedDuration, 0), 0
        ),
        scriptFormat: selectedFile?.name.split('.').pop()?.toUpperCase() || 'UNKNOWN'
      }
    };
  };

  const processScript = async () => {
    if (!selectedFile || !currentProject) return;

    setIsProcessing(true);
    setProgress(0);

    try {
      // Step 1: File Upload and Validation
      setProcessingStep('Uploading and validating script file...');
      setProgress(20);
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Step 2: AI Script Analysis
      setProcessingStep('Analyzing script structure with AI...');
      setProgress(40);
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Step 3: Character and Location Extraction
      if (importSettings.characterExtraction || importSettings.locationExtraction) {
        setProcessingStep('Extracting characters and locations...');
        setProgress(60);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      // Step 4: Episode Segmentation
      if (importSettings.autoSplit) {
        setProcessingStep('Segmenting script into episodes...');
        setProgress(80);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }

      // Step 5: Final Processing
      setProcessingStep('Finalizing episode structure...');
      setProgress(95);
      
      const parsed = await simulateScriptParsing();
      setParsedScript(parsed);
      
      setProgress(100);
      setProcessingStep('Script processing complete!');
      toast.success('Script successfully parsed and ready for import!');
      
    } catch (error) {
      toast.error('Error processing script. Please try again.');
      console.error('Script processing error:', error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImport = async () => {
    if (!parsedScript || !currentProject) return;

    try {
      // Step 1: Start saving process
      setCurrentStep('saving');
      setIsSaving(true);
      setSaveProgress(0);

      // Simulate save progress
      const episodesToCreate = parsedScript.episodes.map(ep => ({
        title: ep.title,
        description: ep.description,
        status: 'draft' as const
      }));

      // Progress simulation
      for (let i = 0; i <= 100; i += 20) {
        setSaveProgress(i);
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      // Step 2: Actually create episodes
      batchCreateEpisodes(currentProject.id, episodesToCreate);
      setImportedEpisodes(episodesToCreate);
      
      // Step 3: Move to analysis step
      setIsSaving(false);
      setCurrentStep('analysis');
      
      toast.success(`Successfully imported ${parsedScript.episodes.length} episodes!`);
      
    } catch (error) {
      setIsSaving(false);
      setCurrentStep('preview');
      toast.error('Error importing episodes. Please try again.');
      console.error('Import error:', error);
    }
  };

  const resetState = () => {
    setSelectedFile(null);
    setParsedScript(null);
    setIsProcessing(false);
    setProgress(0);
    setProcessingStep('');
    setCurrentStep('upload');
    setIsSaving(false);
    setSaveProgress(0);
    setImportedEpisodes([]);
  };

  if (!currentProject) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Upload className="w-4 h-4" />
          Import Scripts
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="w-5 h-5" />
            Episode Script Importer
          </DialogTitle>
        </DialogHeader>

        <Tabs value={currentStep} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="settings" disabled={!selectedFile}>Settings</TabsTrigger>
            <TabsTrigger value="preview" disabled={!parsedScript}>Preview</TabsTrigger>
            <TabsTrigger value="saving" disabled={currentStep !== 'saving'}>Saving</TabsTrigger>
            <TabsTrigger value="analysis" disabled={currentStep !== 'analysis'}>Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            {/* File Upload Area */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Script File Selection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                    dragActive ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  {selectedFile ? (
                    <div className="space-y-4">
                      <CheckCircle className="w-12 h-12 mx-auto text-green-500" />
                      <div>
                        <p className="font-medium text-gray-900">{selectedFile.name}</p>
                        <p className="text-sm text-gray-500">
                          Size: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <Button variant="outline" onClick={() => setSelectedFile(null)}>
                        Choose Different File
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <Upload className="w-12 h-12 mx-auto text-gray-400" />
                      <div>
                        <p className="text-lg font-medium text-gray-900">
                          Drop your script file here
                        </p>
                        <p className="text-gray-500">or click to browse</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => fileInputRef.current?.click()}
                      >
                        Browse Files
                      </Button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        className="hidden"
                        accept=".pdf,.txt,.fdx,.fountain,.docx"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleFileSelect(file);
                        }}
                      />
                    </div>
                  )}
                </div>

                {/* Supported Formats */}
                <div className="mt-6">
                  <Label className="text-sm font-medium text-gray-700 mb-3 block">
                    Supported Formats:
                  </Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {supportedFormats.map((format) => (
                      <Badge key={format.ext} variant="secondary" className="flex items-center gap-1 p-2">
                        <format.icon className="w-3 h-3" />
                        {format.label}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Processing Section */}
            {(selectedFile && !parsedScript) && (
              <Card>
                <CardContent className="pt-6">
                  {!isProcessing ? (
                    <div className="text-center space-y-4">
                      <Zap className="w-12 h-12 mx-auto text-blue-500" />
                      <div>
                        <h3 className="font-medium text-gray-900">Ready to Process</h3>
                        <p className="text-sm text-gray-500">
                          Click below to analyze and parse your script using AI
                        </p>
                      </div>
                      <div className="space-y-2">
                        <Button onClick={processScript} className="w-full">
                          <Zap className="w-4 h-4 mr-2" />
                          Process Script with AI
                        </Button>
                        {parsedScript && (
                          <Button 
                            onClick={() => setCurrentStep('settings')} 
                            variant="outline" 
                            className="w-full"
                          >
                            Next: Configure Settings
                          </Button>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
                        <span className="font-medium">Processing Script...</span>
                      </div>
                      <Progress value={progress} className="w-full" />
                      <p className="text-sm text-gray-600">{processingStep}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Import Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Auto Split Episodes */}
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="font-medium">Auto-split into Episodes</Label>
                    <p className="text-sm text-gray-500">
                      Automatically divide script into multiple episodes
                    </p>
                  </div>
                  <Switch
                    checked={importSettings.autoSplit}
                    onCheckedChange={(checked) => 
                      setImportSettings(prev => ({ ...prev, autoSplit: checked }))
                    }
                  />
                </div>

                <Separator />

                {/* Episode Naming */}
                <div className="space-y-3">
                  <Label className="font-medium">Episode Naming Convention</Label>
                  <Select
                    value={importSettings.episodeNaming}
                    onValueChange={(value: 'sequential' | 'scene_headers' | 'custom') =>
                      setImportSettings(prev => ({ ...prev, episodeNaming: value }))
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sequential">Sequential (Episode 1, 2, 3...)</SelectItem>
                      <SelectItem value="scene_headers">Based on Scene Headers</SelectItem>
                      <SelectItem value="custom">Custom Prefix</SelectItem>
                    </SelectContent>
                  </Select>
                  
                  {importSettings.episodeNaming === 'custom' && (
                    <Input
                      placeholder="Custom prefix (e.g., 'Chapter', 'Part')"
                      value={importSettings.customPrefix}
                      onChange={(e) => 
                        setImportSettings(prev => ({ ...prev, customPrefix: e.target.value }))
                      }
                    />
                  )}
                </div>

                <Separator />

                {/* Content Extraction */}
                <div className="space-y-4">
                  <Label className="font-medium">Content Extraction</Label>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm">Extract Characters</Label>
                      <p className="text-xs text-gray-500">Identify and list all characters</p>
                    </div>
                    <Switch
                      checked={importSettings.characterExtraction}
                      onCheckedChange={(checked) => 
                        setImportSettings(prev => ({ ...prev, characterExtraction: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm">Extract Locations</Label>
                      <p className="text-xs text-gray-500">Identify filming locations</p>
                    </div>
                    <Switch
                      checked={importSettings.locationExtraction}
                      onCheckedChange={(checked) => 
                        setImportSettings(prev => ({ ...prev, locationExtraction: checked }))
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-sm">Timing Analysis</Label>
                      <p className="text-xs text-gray-500">Estimate scene durations</p>
                    </div>
                    <Switch
                      checked={importSettings.timingAnalysis}
                      onCheckedChange={(checked) => 
                        setImportSettings(prev => ({ ...prev, timingAnalysis: checked }))
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Navigation Button */}
            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setCurrentStep('upload')}>
                Back to Upload
              </Button>
              <Button onClick={() => setCurrentStep('preview')} disabled={!parsedScript}>
                Next: Preview Episodes
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="space-y-6">
            {parsedScript && (
              <>
                {/* Script Metadata */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Eye className="w-5 h-5" />
                      Script Analysis Results
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">
                          {parsedScript.episodes.length}
                        </div>
                        <div className="text-sm text-gray-500">Episodes</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {parsedScript.episodes.reduce((acc, ep) => acc + ep.scenes.length, 0)}
                        </div>
                        <div className="text-sm text-gray-500">Total Scenes</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          {parsedScript.metadata.totalCharacters}
                        </div>
                        <div className="text-sm text-gray-500">Characters</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">
                          {Math.round(parsedScript.metadata.estimatedRuntime / 60)}m
                        </div>
                        <div className="text-sm text-gray-500">Est. Runtime</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Episodes Preview */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Split className="w-5 h-5" />
                      Episodes to Import
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4 max-h-64 overflow-y-auto">
                      {parsedScript.episodes.map((episode, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h4 className="font-medium">{episode.title}</h4>
                              <p className="text-sm text-gray-600">{episode.description}</p>
                            </div>
                            <Badge variant="secondary">{episode.scenes.length} scenes</Badge>
                          </div>
                          <div className="text-xs text-gray-500">
                            Runtime: {Math.round(episode.scenes.reduce((acc, scene) => acc + scene.estimatedDuration, 0) / 60)} minutes
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Import Actions */}
                <div className="flex justify-between items-center">
                  <Button variant="outline" onClick={resetState}>
                    Start Over
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Export Preview
                    </Button>
                    <Button onClick={handleImport} disabled={isSaving}>
                      {isSaving ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Upload className="w-4 h-4 mr-2" />
                      )}
                      {isSaving ? 'Importing...' : `Import ${parsedScript.episodes.length} Episodes`}
                    </Button>
                  </div>
                </div>
              </>
            )}
          </TabsContent>

          {/* Saving Progress Tab */}
          <TabsContent value="saving" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                  Saving Episodes to Project
                </CardTitle>
                <p className="text-muted-foreground">
                  Creating {parsedScript?.episodes.length || 0} episodes in your project...
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Import Progress</span>
                    <span>{saveProgress}%</span>
                  </div>
                  <Progress value={saveProgress} className="w-full" />
                  <p className="text-sm text-muted-foreground text-center">
                    {saveProgress < 50 ? 'Processing episodes...' : 
                     saveProgress < 80 ? 'Creating scenes and shots...' : 
                     'Finalizing import...'}
                  </p>
                </div>

                {/* Save Status */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{parsedScript?.episodes.length || 0}</div>
                    <div className="text-sm text-muted-foreground">Episodes</div>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{parsedScript?.episodes?.reduce((total, ep) => total + ep.scenes.length, 0) || 0}</div>
                    <div className="text-sm text-muted-foreground">Scenes</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analysis Results Tab */}
          <TabsContent value="analysis" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Import Complete - Analysis Results
                </CardTitle>
                <p className="text-muted-foreground">
                  Successfully imported {importedEpisodes.length} episodes. Review the analysis below.
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Import Summary */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{importedEpisodes.length}</div>
                    <div className="text-sm text-green-600">Episodes Created</div>
                  </div>
                  <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{parsedScript?.episodes?.reduce((total, ep) => total + ep.scenes.length, 0) || 0}</div>
                    <div className="text-sm text-blue-600">Total Scenes</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 border border-purple-200 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">{parsedScript?.metadata.totalCharacters || 0}</div>
                    <div className="text-sm text-purple-600">Characters</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{parsedScript?.metadata.estimatedRuntime || 0}m</div>
                    <div className="text-sm text-orange-600">Est. Runtime</div>
                  </div>
                </div>

                {/* Character Analysis */}
                {parsedScript?.episodes && (
                  <div className="space-y-3">
                    <h4 className="font-semibold">Extracted Characters</h4>
                    <div className="flex flex-wrap gap-2">
                      {Array.from(new Set(parsedScript.episodes?.flatMap(ep => ep.scenes.flatMap(scene => scene.characters)) || [])).slice(0, 20).map((character, index) => (
                        <Badge key={index} variant="secondary">
                          {character as string}
                        </Badge>
                      ))}
                      {Array.from(new Set(parsedScript.episodes?.flatMap(ep => ep.scenes.flatMap(scene => scene.characters)) || [])).length > 20 && (
                        <Badge variant="outline">
                          +{Array.from(new Set(parsedScript.episodes?.flatMap(ep => ep.scenes.flatMap(scene => scene.characters)) || [])).length - 20} more
                        </Badge>
                      )}
                    </div>
                  </div>
                )}

                {/* Episode Breakdown */}
                <div className="space-y-3">
                  <h4 className="font-semibold">Episode Breakdown</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {importedEpisodes.map((episode, index) => (
                      <div key={index} className="flex justify-between items-center p-3 bg-muted rounded-lg">
                        <div>
                          <div className="font-medium">{episode.title}</div>
                          <div className="text-sm text-muted-foreground">{episode.description}</div>
                        </div>
                        <Badge variant="outline">
                          {parsedScript?.episodes[index]?.scenes.length || 0} scenes
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex justify-between items-center pt-4 border-t">
                  <Button variant="outline" onClick={resetState}>
                    Import Another Script
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => setCurrentView('episodes')}>
                      <Tv className="w-4 h-4 mr-2" />
                      View Episodes
                    </Button>
                    <Button onClick={() => setCurrentView('script')}>
                      <FileText className="w-4 h-4 mr-2" />
                      Open Script Editor
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default EpisodeScriptImporter;
