import React, { useState } from 'react';
import { BarChart3, Calendar, Clock, Users, Camera, CheckCircle, AlertTriangle, TrendingUp, Download, Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { useStoryboardStore } from '../../store/storyboardStore';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

const ProductionReports: React.FC = () => {
  const { currentProject, setCurrentView } = useStoryboardStore();
  
  const [isAddReportOpen, setIsAddReportOpen] = useState(false);
  const [newReport, setNewReport] = useState({
    type: 'daily' as const,
    summary: '',
    scenesCompleted: 0,
    shotsCompleted: 0,
    hoursWorked: 8,
    budgetSpent: 0,
    issues: '',
    highlights: '',
    nextSteps: '',
    weather: '',
    attendees: ''
  });

  // Mock data for reports
  const [reports] = useState([
    {
      id: '1',
      projectId: currentProject?.id || '',
      date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      type: 'daily' as const,
      status: 'on_schedule' as const,
      summary: 'Successfully completed Scene 3 with all planned shots. Great performance from cast and crew.',
      details: {
        scenesCompleted: 1,
        shotsCompleted: 8,
        hoursWorked: 10,
        budgetSpent: 2500,
        issues: ['Weather delayed outdoor shots by 1 hour'],
        highlights: ['Exceptional performance by lead actor', 'Camera team efficiency improved'],
        nextSteps: ['Setup for Scene 4 tomorrow', 'Review dailies with director'],
        attendees: ['Director', 'DOP', 'Camera Operator', 'Sound Engineer', 'Gaffer'],
        weather: 'Partly cloudy, 72°F',
        equipment: ['RED Komodo', 'Wireless mics', 'LED panel kit']
      },
      createdBy: 'Production Manager',
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      projectId: currentProject?.id || '',
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      type: 'daily' as const,
      status: 'behind' as const,
      summary: 'Equipment issues caused delays. Only completed 6 of 10 planned shots.',
      details: {
        scenesCompleted: 0,
        shotsCompleted: 6,
        hoursWorked: 12,
        budgetSpent: 3200,
        issues: ['Camera malfunction for 2 hours', 'Late equipment delivery'],
        highlights: ['Quick problem-solving by camera team', 'Excellent backup plan execution'],
        nextSteps: ['Equipment check before call time', 'Make up missed shots'],
        attendees: ['Director', 'DOP', 'Camera Operator', 'Sound Engineer'],
        weather: 'Sunny, 75°F',
        equipment: ['ARRI Alexa backup', 'Additional lighting kit']
      },
      createdBy: 'Production Manager',
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    }
  ]);

  if (!currentProject) {
    return (
      <div className="p-6 flex items-center justify-center h-full">
        <div className="text-center space-y-4">
          <BarChart3 className="w-16 h-16 mx-auto text-gray-400" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">No Project Selected</h3>
            <p className="text-gray-600">Please select a project from the dashboard</p>
          </div>
          <Button onClick={() => setCurrentView('dashboard')}>
            Go to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const handleAddReport = () => {
    // Implementation would save to store
    toast.success('Production report added successfully!');
    setIsAddReportOpen(false);
    setNewReport({
      type: 'daily',
      summary: '',
      scenesCompleted: 0,
      shotsCompleted: 0,
      hoursWorked: 8,
      budgetSpent: 0,
      issues: '',
      highlights: '',
      nextSteps: '',
      weather: '',
      attendees: ''
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'on_schedule': return 'bg-green-500';
      case 'ahead': return 'bg-blue-500';
      case 'behind': return 'bg-red-500';
      case 'on_hold': return 'bg-yellow-500';
      case 'completed': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'on_schedule': return 'On Schedule';
      case 'ahead': return 'Ahead';
      case 'behind': return 'Behind';
      case 'on_hold': return 'On Hold';
      case 'completed': return 'Completed';
      default: return 'Unknown';
    }
  };

  // Calculate project statistics
  const totalScenes = currentProject.episodes.reduce((acc, ep) => acc + ep.scenes.length, 0);
  const totalShots = currentProject.episodes.reduce((acc, ep) => 
    acc + ep.scenes.reduce((sceneAcc, scene) => sceneAcc + scene.shots.length, 0), 0
  );
  const completedShots = reports.reduce((acc, report) => acc + report.details.shotsCompleted, 0);
  const completionPercentage = totalShots > 0 ? (completedShots / totalShots) * 100 : 0;

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col space-y-4 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Production Reports</h1>
          <p className="text-gray-600">Track daily progress and production analytics</p>
        </div>

        <div className="flex items-center space-x-3">
          <Button variant="outline" className="hidden sm:flex">
            <Download className="w-4 h-4 mr-2" />
            Export Reports
          </Button>
          
          <Dialog open={isAddReportOpen} onOpenChange={setIsAddReportOpen}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline">Add Report</span>
                <span className="sm:hidden">Add</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Create Production Report</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Report Type</Label>
                    <Select 
                      value={newReport.type} 
                      onValueChange={(value) => setNewReport({ ...newReport, type: value as any })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily Report</SelectItem>
                        <SelectItem value="weekly">Weekly Summary</SelectItem>
                        <SelectItem value="scene_completion">Scene Completion</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Hours Worked</Label>
                    <Input
                      type="number"
                      value={newReport.hoursWorked}
                      onChange={(e) => setNewReport({ ...newReport, hoursWorked: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Summary</Label>
                  <Textarea
                    placeholder="Brief summary of today's production..."
                    value={newReport.summary}
                    onChange={(e) => setNewReport({ ...newReport, summary: e.target.value })}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label>Scenes Completed</Label>
                    <Input
                      type="number"
                      value={newReport.scenesCompleted}
                      onChange={(e) => setNewReport({ ...newReport, scenesCompleted: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Shots Completed</Label>
                    <Input
                      type="number"
                      value={newReport.shotsCompleted}
                      onChange={(e) => setNewReport({ ...newReport, shotsCompleted: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Budget Spent ($)</Label>
                    <Input
                      type="number"
                      value={newReport.budgetSpent}
                      onChange={(e) => setNewReport({ ...newReport, budgetSpent: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Highlights</Label>
                  <Textarea
                    placeholder="Key achievements and positive moments..."
                    value={newReport.highlights}
                    onChange={(e) => setNewReport({ ...newReport, highlights: e.target.value })}
                    rows={2}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Issues</Label>
                  <Textarea
                    placeholder="Problems encountered and resolutions..."
                    value={newReport.issues}
                    onChange={(e) => setNewReport({ ...newReport, issues: e.target.value })}
                    rows={2}
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-4">
                  <Button variant="outline" onClick={() => setIsAddReportOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddReport}>Create Report</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Progress</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completionPercentage.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              {completedShots} of {totalShots} shots
            </p>
            <Progress value={completionPercentage} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scenes</CardTitle>
            <Camera className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalScenes}</div>
            <p className="text-xs text-muted-foreground">Total scenes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reports</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reports.length}</div>
            <p className="text-xs text-muted-foreground">Production reports</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">On Track</div>
            <p className="text-xs text-muted-foreground">Overall status</p>
          </CardContent>
        </Card>
      </div>

      {/* Reports Section */}
      <Tabs defaultValue="daily" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="daily">Daily Reports</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-6">
          <div className="space-y-4">
            {reports.map((report) => (
              <Card key={report.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between space-y-2 sm:space-y-0">
                    <div className="flex items-center space-x-3">
                      <Badge className={`${getStatusColor(report.status)} text-white`}>
                        {getStatusLabel(report.status)}
                      </Badge>
                      <div>
                        <CardTitle className="text-lg">
                          {report.type === 'daily' ? 'Daily Report' : 
                           report.type === 'weekly' ? 'Weekly Summary' : 'Scene Completion'}
                        </CardTitle>
                        <p className="text-sm text-gray-600">
                          {formatDistanceToNow(report.date, { addSuffix: true })}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Camera className="w-4 h-4" />
                        <span>{report.details.shotsCompleted} shots</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span>{report.details.hoursWorked}h</span>
                      </div>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-gray-700">{report.summary}</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div>
                      <div className="font-medium text-gray-900">Progress</div>
                      <div>Scenes: {report.details.scenesCompleted}</div>
                      <div>Shots: {report.details.shotsCompleted}</div>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">Budget</div>
                      <div>${report.details.budgetSpent.toLocaleString()}</div>
                      <div>Hours: {report.details.hoursWorked}</div>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">Weather</div>
                      <div>{report.details.weather}</div>
                    </div>
                  </div>

                  {report.details.highlights && report.details.highlights.length > 0 && (
                    <div>
                      <div className="font-medium text-gray-900 mb-2">Highlights</div>
                      <ul className="text-sm text-gray-700 space-y-1">
                        {report.details.highlights.map((highlight, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <CheckCircle className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {report.details.issues && report.details.issues.length > 0 && (
                    <div>
                      <div className="font-medium text-gray-900 mb-2">Issues</div>
                      <ul className="text-sm text-gray-700 space-y-1">
                        {report.details.issues.map((issue, index) => (
                          <li key={index} className="flex items-start space-x-2">
                            <AlertTriangle className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                            <span>{issue}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {report.details.attendees && report.details.attendees.length > 0 && (
                    <div>
                      <div className="font-medium text-gray-900 mb-2">Crew Present</div>
                      <div className="flex flex-wrap gap-1">
                        {report.details.attendees.map((attendee, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {attendee}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Production Velocity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Avg. Shots per Day</span>
                    <span className="font-semibold">7.2</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Avg. Hours per Day</span>
                    <span className="font-semibold">10.5</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Budget Efficiency</span>
                    <span className="font-semibold text-green-600">95%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Schedule Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>On Schedule Days</span>
                    <span className="font-semibold text-green-600">80%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Behind Schedule</span>
                    <span className="font-semibold text-red-600">20%</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Avg. Delay</span>
                    <span className="font-semibold">1.5 hours</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">Tomorrow - Scene 4</div>
                    <div className="text-sm text-gray-600">Corporate Office - Interior</div>
                    <div className="text-sm text-gray-600">Call Time: 7:00 AM</div>
                  </div>
                  <Badge>Scheduled</Badge>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">Day 3 - Scene 5 & 6</div>
                    <div className="text-sm text-gray-600">Studio - Multiple setups</div>
                    <div className="text-sm text-gray-600">Call Time: 8:00 AM</div>
                  </div>
                  <Badge variant="outline">Planned</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProductionReports;
