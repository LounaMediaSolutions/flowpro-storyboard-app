import { useEffect, useCallback } from 'react';
import { ScriptElementType } from '../components/script/EnhancedScriptEditor';

interface KeyboardShortcutsProps {
  onElementSelect: (elementType: ScriptElementType, template?: string) => void;
  onAction: (action: string) => void;
  onTabPress?: (currentType: ScriptElementType) => void;
  onEnterPress?: (currentType: ScriptElementType) => void;
  isEnabled?: boolean;
}

export const useKeyboardShortcuts = ({ 
  onElementSelect, 
  onAction,
  onTabPress,
  onEnterPress,
  isEnabled = true 
}: KeyboardShortcutsProps) => {
  
  const handleKeyDown = useCallback((event: KeyboardEvent) => {
    if (!isEnabled) return;
    
    // Handle Tab key (Final Draft behavior)
    if (event.key === 'Tab' && !event.ctrlKey && !event.metaKey) {
      event.preventDefault();
      if (onTabPress) {
        // Get current element type from focused element or use 'action' as default
        onTabPress('action'); // This should be passed from the editor with current element type
      }
      return;
    }
    
    // Handle Enter key (Final Draft behavior)
    if (event.key === 'Enter' && !event.ctrlKey && !event.metaKey) {
      // Don't prevent default for Enter - let it create new lines
      if (onEnterPress) {
        // This will be handled by the editor based on current element type
        onEnterPress('action');
      }
      return;
    }
    
    // Final Draft Element Creation Shortcuts (Ctrl/Cmd + Numbers)
    if (event.ctrlKey || event.metaKey) {
      const shouldPreventDefault = true;
      
      switch (event.key) {
        // Final Draft Standard Element Shortcuts
        case '0':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('general');
          break;
          
        case '1':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('scene_heading', 'INT. LOCATION - DAY');
          break;
          
        case '2':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('action');
          break;
          
        case '3':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('character', 'CHARACTER');
          break;
          
        case '4':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('parenthetical', '(continuing)');
          break;
          
        case '5':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('dialogue');
          break;
          
        case '6':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('transition', 'CUT TO:');
          break;
          
        case '7':
          if (shouldPreventDefault) event.preventDefault();
          onElementSelect('shot', 'CLOSE-UP ON');
          break;
      }
      
      // Handle Ctrl+Shift combinations for advanced elements
      if (event.shiftKey) {
        switch (event.key) {
          case 'D':
            event.preventDefault();
            onAction('duplicate');
            break;
            
          case 'A':
            event.preventDefault();
            onAction('selectScene');
            break;
            
          case 'T':
            event.preventDefault();
            onAction('tagsMode');
            break;
        }
      }
      
      // Standard editing shortcuts
      switch (event.key.toLowerCase()) {
        case 'a':
          if (!event.shiftKey) {
            // Ctrl+A is handled by browser for Select All
            return;
          }
          break;
          
        case 'z':
          // Undo/Redo handled by browser
          return;
          
        case 'c':
        case 'v':
        case 'x':
          // Copy/Paste/Cut handled by browser
          return;
          
        case 's':
          if (!event.shiftKey) {
            // Save - let it through to browser/app
            return;
          }
          break;
          
        case 'f':
          // Find - let it through to browser
          return;
          
        case 'g':
          if (shouldPreventDefault) event.preventDefault();
          onAction('goTo');
          break;
          
        case 'b':
          if (shouldPreventDefault) event.preventDefault();
          onAction('bold');
          break;
          
        case 'i':
          if (shouldPreventDefault) event.preventDefault();
          onAction('italic');
          break;
          
        case 'u':
          if (shouldPreventDefault) event.preventDefault();
          onAction('underline');
          break;
          
        case 'd':
          if (!event.shiftKey) {
            if (shouldPreventDefault) event.preventDefault();
            onAction('dualDialogue');
          }
          break;
      }
    }
    
    // Arrow keys for navigation
    if (event.ctrlKey || event.metaKey) {
      switch (event.key) {
        case 'ArrowUp':
          if (event.shiftKey) {
            event.preventDefault();
            onAction('moveUp');
          }
          break;
          
        case 'ArrowDown':
          if (event.shiftKey) {
            event.preventDefault();
            onAction('moveDown');
          }
          break;
      }
    }
    
  }, [isEnabled, onElementSelect, onAction, onTabPress, onEnterPress]);

  useEffect(() => {
    if (isEnabled) {
      document.addEventListener('keydown', handleKeyDown);
      return () => document.removeEventListener('keydown', handleKeyDown);
    }
  }, [handleKeyDown, isEnabled]);

  // Return Final Draft shortcuts info for display
  return {
    shortcuts: [
      // Element Creation (Final Draft Standard)
      { keys: 'Ctrl/Cmd+0', action: 'General' },
      { keys: 'Ctrl/Cmd+1', action: 'Scene Heading' },
      { keys: 'Ctrl/Cmd+2', action: 'Action' },
      { keys: 'Ctrl/Cmd+3', action: 'Character' },
      { keys: 'Ctrl/Cmd+4', action: 'Parenthetical' },
      { keys: 'Ctrl/Cmd+5', action: 'Dialogue' },
      { keys: 'Ctrl/Cmd+6', action: 'Transition' },
      { keys: 'Ctrl/Cmd+7', action: 'Shot' },
      
      // Navigation & Flow
      { keys: 'Tab', action: 'Next Element (Smart Flow)' },
      { keys: 'Enter', action: 'Logical Next Element' },
      
      // Formatting
      { keys: 'Ctrl/Cmd+B', action: 'Bold' },
      { keys: 'Ctrl/Cmd+I', action: 'Italic' },
      { keys: 'Ctrl/Cmd+U', action: 'Underline' },
      { keys: 'Ctrl/Cmd+D', action: 'Dual Dialogue' },
      
      // Quick Actions
      { keys: 'Ctrl/Cmd+Shift+D', action: 'Duplicate Element' },
      { keys: 'Ctrl/Cmd+Shift+A', action: 'Select Current Scene' },
      { keys: 'Ctrl/Cmd+G', action: 'Go To Page/Scene' },
      
      // Movement
      { keys: 'Ctrl/Cmd+Shift+↑', action: 'Move Element Up' },
      { keys: 'Ctrl/Cmd+Shift+↓', action: 'Move Element Down' }
    ]
  };
};
