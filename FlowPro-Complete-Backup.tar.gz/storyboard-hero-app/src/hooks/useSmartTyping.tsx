import { useCallback } from 'react';
import { ScriptElementType } from '../components/script/EnhancedScriptEditor';

interface SmartTypingProps {
  onElementSelect: (elementType: ScriptElementType, template?: string) => void;
  currentElementType: ScriptElementType;
  currentContent: string;
  savedCharacters: string[];
}

export const useSmartTyping = ({
  onElementSelect,
  currentElementType,
  currentContent,
  savedCharacters
}: SmartTypingProps) => {

  // Final Draft Tab Key Logic
  const handleTabPress = useCallback(() => {
    switch (currentElementType) {
      case 'scene_heading':
        // From scene heading -> Action
        onElementSelect('action');
        break;
        
      case 'action':
        // From action -> Character
        onElementSelect('character');
        break;
        
      case 'character':
        if (!currentContent.trim()) {
          // Empty character -> Transition
          onElementSelect('transition', 'CUT TO:');
        } else {
          // Character with content -> Parenthetical
          onElementSelect('parenthetical', '(continuing)');
        }
        break;
        
      case 'dialogue':
        // From dialogue -> Parenthetical
        onElementSelect('parenthetical');
        break;
        
      case 'parenthetical':
        // From parenthetical -> Dialogue
        onElementSelect('dialogue');
        break;
        
      case 'transition':
        // From transition -> Scene Heading
        onElementSelect('scene_heading', 'INT. LOCATION - DAY');
        break;
        
      case 'shot':
        // From shot -> Action
        onElementSelect('action');
        break;
        
      default:
        // Default -> Action
        onElementSelect('action');
        break;
    }
  }, [currentElementType, currentContent, onElementSelect]);

  // Final Draft Enter Key Logic
  const handleEnterPress = useCallback(() => {
    switch (currentElementType) {
      case 'scene_heading':
        // Scene Heading -> Action
        onElementSelect('action');
        break;
        
      case 'action':
        // Action -> Action (new action paragraph)
        onElementSelect('action');
        break;
        
      case 'character':
        // Character -> Dialogue
        onElementSelect('dialogue');
        break;
        
      case 'dialogue':
        // Dialogue -> Action
        onElementSelect('action');
        break;
        
      case 'parenthetical':
        // Parenthetical -> Dialogue
        onElementSelect('dialogue');
        break;
        
      case 'transition':
        // Transition -> Scene Heading
        onElementSelect('scene_heading', 'INT. LOCATION - DAY');
        break;
        
      case 'shot':
        // Shot -> Action
        onElementSelect('action');
        break;
        
      default:
        // Default -> same element type
        onElementSelect(currentElementType);
        break;
    }
  }, [currentElementType, onElementSelect]);

  // Smart Auto-Conversion (like Final Draft)
  const handleContentChange = useCallback((content: string) => {
    const trimmedContent = content.trim().toLowerCase();
    
    // Auto Scene Heading Detection
    if (currentElementType === 'action' && (
      trimmedContent === 'int.' || 
      trimmedContent === 'ext.' ||
      trimmedContent.startsWith('int. ') ||
      trimmedContent.startsWith('ext. ')
    )) {
      // Convert to scene heading and format properly
      const formatted = content.toUpperCase().replace(/\.$/, '. ');
      onElementSelect('scene_heading', formatted);
      return true; // Indicates conversion happened
    }

    // Auto Character Detection (if content matches saved character)
    if (currentElementType === 'action') {
      const upperContent = content.toUpperCase().trim();
      const matchedCharacter = savedCharacters.find(char => 
        char.toUpperCase() === upperContent
      );
      
      if (matchedCharacter && content.length > 2) {
        onElementSelect('character', matchedCharacter.toUpperCase());
        return true;
      }
    }

    // Auto Transition Detection
    if (currentElementType === 'action') {
      const transitions = [
        'CUT TO:', 'FADE IN:', 'FADE OUT.', 'FADE TO BLACK.', 
        'DISSOLVE TO:', 'SMASH CUT TO:', 'MATCH CUT TO:'
      ];
      
      const upperContent = content.toUpperCase().trim();
      if (transitions.some(trans => upperContent === trans.replace(':', '').replace('.', ''))) {
        onElementSelect('transition', upperContent.includes(':') ? upperContent : upperContent + ':');
        return true;
      }
    }

    return false; // No conversion
  }, [currentElementType, savedCharacters, onElementSelect]);

  // Scene Heading Smart Completion
  const getSceneHeadingCompletion = useCallback((content: string) => {
    const parts = content.split(/\s+/);
    
    if (parts.length === 1 && (parts[0].toLowerCase() === 'int' || parts[0].toLowerCase() === 'ext')) {
      return parts[0].toUpperCase() + '. ';
    }
    
    if (parts.length >= 2 && !content.includes(' - ')) {
      // Add time separator
      return content + ' - ';
    }
    
    return content;
  }, []);

  // Character Name Suggestions
  const getCharacterSuggestions = useCallback((content: string) => {
    if (!content.trim()) return [];
    
    const upperContent = content.toUpperCase();
    return savedCharacters
      .filter(char => char.toUpperCase().startsWith(upperContent))
      .slice(0, 5);
  }, [savedCharacters]);

  // Common Character Variations
  const getCharacterVariations = useCallback((characterName: string) => {
    return [
      characterName,
      `${characterName} (V.O.)`,
      `${characterName} (O.S.)`,
      `${characterName} (CONT'D)`,
      `${characterName} (FILTERED)`
    ];
  }, []);

  // Smart Location Suggestions
  const getLocationSuggestions = useCallback(() => {
    return [
      'LIVING ROOM', 'KITCHEN', 'BEDROOM', 'BATHROOM', 'OFFICE',
      'RESTAURANT', 'COFFEE SHOP', 'PARK', 'STREET', 'CAR',
      'SCHOOL', 'HOSPITAL', 'STORE', 'AIRPORT', 'HOTEL ROOM'
    ];
  }, []);

  // Time of Day Suggestions
  const getTimeOfDaySuggestions = useCallback(() => {
    return [
      'DAY', 'NIGHT', 'MORNING', 'AFTERNOON', 'EVENING',
      'DAWN', 'DUSK', 'SUNSET', 'SUNRISE', 'LATER',
      'CONTINUOUS', 'MOMENTS LATER', 'SAME TIME'
    ];
  }, []);

  return {
    handleTabPress,
    handleEnterPress,
    handleContentChange,
    getSceneHeadingCompletion,
    getCharacterSuggestions,
    getCharacterVariations,
    getLocationSuggestions,
    getTimeOfDaySuggestions,
    
    // Final Draft Element Flow Rules
    elementFlowRules: {
      'scene_heading': { tab: 'action', enter: 'action' },
      'action': { tab: 'character', enter: 'action' },
      'character': { tab: 'parenthetical', enter: 'dialogue' },
      'dialogue': { tab: 'parenthetical', enter: 'action' },
      'parenthetical': { tab: 'dialogue', enter: 'dialogue' },
      'transition': { tab: 'scene_heading', enter: 'scene_heading' },
      'shot': { tab: 'action', enter: 'action' }
    }
  };
};