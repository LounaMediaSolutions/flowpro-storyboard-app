export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          company: string | null
          role: 'admin' | 'editor' | 'viewer'
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          company?: string | null
          role?: 'admin' | 'editor' | 'viewer'
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          company?: string | null
          role?: 'admin' | 'editor' | 'viewer'
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      organizations: {
        Row: {
          id: string
          name: string
          description: string | null
          owner_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          owner_id: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          owner_id?: string
          created_at?: string
          updated_at?: string
        }
      }
      projects: {
        Row: {
          id: string
          title: string
          description: string
          project_type: 'series' | 'movie' | 'commercial' | 'documentary' | 'animation' | 'music_video'
          total_episodes: number | null
          target_duration: number | null
          estimated_duration: number | null
          visual_style: string
          thumbnail_url: string | null
          user_id: string
          organization_id: string | null
          status: 'draft' | 'in_progress' | 'review' | 'completed'
          created_at: string
          updated_at: string
          production_settings: Json | null
        }
        Insert: {
          id?: string
          title: string
          description: string
          project_type?: 'series' | 'movie' | 'commercial' | 'documentary' | 'animation' | 'music_video'
          total_episodes?: number | null
          target_duration?: number | null
          estimated_duration?: number | null
          visual_style?: string
          thumbnail_url?: string | null
          user_id: string
          organization_id?: string | null
          status?: 'draft' | 'in_progress' | 'review' | 'completed'
          created_at?: string
          updated_at?: string
          production_settings?: Json | null
        }
        Update: {
          id?: string
          title?: string
          description?: string
          project_type?: 'series' | 'movie' | 'commercial' | 'documentary' | 'animation' | 'music_video'
          total_episodes?: number | null
          target_duration?: number | null
          estimated_duration?: number | null
          visual_style?: string
          thumbnail_url?: string | null
          user_id?: string
          organization_id?: string | null
          status?: 'draft' | 'in_progress' | 'review' | 'completed'
          created_at?: string
          updated_at?: string
          production_settings?: Json | null
        }
      }
      episodes: {
        Row: {
          id: string
          project_id: string
          episode_number: number
          title: string
          description: string
          target_duration: number | null
          estimated_duration: number | null
          actual_duration: number | null
          status: 'draft' | 'script' | 'storyboard' | 'production' | 'post' | 'completed'
          script_content: string | null
          script_analysis: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          project_id: string
          episode_number: number
          title: string
          description: string
          target_duration?: number | null
          estimated_duration?: number | null
          actual_duration?: number | null
          status?: 'draft' | 'script' | 'storyboard' | 'production' | 'post' | 'completed'
          script_content?: string | null
          script_analysis?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          episode_number?: number
          title?: string
          description?: string
          target_duration?: number | null
          estimated_duration?: number | null
          actual_duration?: number | null
          status?: 'draft' | 'script' | 'storyboard' | 'production' | 'post' | 'completed'
          script_content?: string | null
          script_analysis?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      scenes: {
        Row: {
          id: string
          episode_id: string
          scene_number: number
          title: string
          description: string
          location: string | null
          time_of_day: 'day' | 'night' | 'dawn' | 'dusk' | 'morning' | 'afternoon' | 'evening' | 'continuous' | 'later' | 'same_time'
          is_interior: boolean
          characters: string[]
          estimated_duration: number | null
          shooting_day: number | null
          shooting_order: number | null
          weather: string | null
          props: string[]
          wardrobe: Json | null
          equipment: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          episode_id: string
          scene_number: number
          title: string
          description: string
          location?: string | null
          time_of_day?: 'day' | 'night' | 'dawn' | 'dusk' | 'morning' | 'afternoon' | 'evening' | 'continuous' | 'later' | 'same_time'
          is_interior?: boolean
          characters?: string[]
          estimated_duration?: number | null
          shooting_day?: number | null
          shooting_order?: number | null
          weather?: string | null
          props?: string[]
          wardrobe?: Json | null
          equipment?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          episode_id?: string
          scene_number?: number
          title?: string
          description?: string
          location?: string | null
          time_of_day?: 'day' | 'night' | 'dawn' | 'dusk' | 'morning' | 'afternoon' | 'evening' | 'continuous' | 'later' | 'same_time'
          is_interior?: boolean
          characters?: string[]
          estimated_duration?: number | null
          shooting_day?: number | null
          shooting_order?: number | null
          weather?: string | null
          props?: string[]
          wardrobe?: Json | null
          equipment?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      shots: {
        Row: {
          id: string
          scene_id: string
          shot_number: number
          description: string
          dialogue: string | null
          voice_over: string | null
          characters: string[]
          estimated_duration: number | null
          camera_angle: 'wide_shot' | 'medium_shot' | 'close_up' | 'extreme_close_up' | 'over_shoulder' | 'two_shot'
          camera_movement: 'static' | 'pan_left' | 'pan_right' | 'tilt_up' | 'tilt_down' | 'zoom_in' | 'zoom_out' | 'dolly_in' | 'dolly_out' | 'tracking'
          perspective: 'eye_level' | 'high_angle' | 'low_angle' | 'birds_eye' | 'worms_eye'
          focus: 'shallow_focus' | 'deep_focus' | 'rack_focus'
          lighting: 'soft_light' | 'hard_light' | 'backlight' | 'side_light' | 'key_light' | 'fill_light'
          focal_length: string | null
          transition: string
          image_url: string | null
          image_prompt: string | null
          shooting_notes: string | null
          camera_equipment: Json | null
          audio_equipment: Json | null
          lighting_equipment: Json | null
          technical_specs: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          scene_id: string
          shot_number: number
          description: string
          dialogue?: string | null
          voice_over?: string | null
          characters?: string[]
          estimated_duration?: number | null
          camera_angle?: 'wide_shot' | 'medium_shot' | 'close_up' | 'extreme_close_up' | 'over_shoulder' | 'two_shot'
          camera_movement?: 'static' | 'pan_left' | 'pan_right' | 'tilt_up' | 'tilt_down' | 'zoom_in' | 'zoom_out' | 'dolly_in' | 'dolly_out' | 'tracking'
          perspective?: 'eye_level' | 'high_angle' | 'low_angle' | 'birds_eye' | 'worms_eye'
          focus?: 'shallow_focus' | 'deep_focus' | 'rack_focus'
          lighting?: 'soft_light' | 'hard_light' | 'backlight' | 'side_light' | 'key_light' | 'fill_light'
          focal_length?: string | null
          transition?: string
          image_url?: string | null
          image_prompt?: string | null
          shooting_notes?: string | null
          camera_equipment?: Json | null
          audio_equipment?: Json | null
          lighting_equipment?: Json | null
          technical_specs?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          scene_id?: string
          shot_number?: number
          description?: string
          dialogue?: string | null
          voice_over?: string | null
          characters?: string[]
          estimated_duration?: number | null
          camera_angle?: 'wide_shot' | 'medium_shot' | 'close_up' | 'extreme_close_up' | 'over_shoulder' | 'two_shot'
          camera_movement?: 'static' | 'pan_left' | 'pan_right' | 'tilt_up' | 'tilt_down' | 'zoom_in' | 'zoom_out' | 'dolly_in' | 'dolly_out' | 'tracking'
          perspective?: 'eye_level' | 'high_angle' | 'low_angle' | 'birds_eye' | 'worms_eye'
          focus?: 'shallow_focus' | 'deep_focus' | 'rack_focus'
          lighting?: 'soft_light' | 'hard_light' | 'backlight' | 'side_light' | 'key_light' | 'fill_light'
          focal_length?: string | null
          transition?: string
          image_url?: string | null
          image_prompt?: string | null
          shooting_notes?: string | null
          camera_equipment?: Json | null
          audio_equipment?: Json | null
          lighting_equipment?: Json | null
          technical_specs?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      characters: {
        Row: {
          id: string
          project_id: string
          name: string
          description: string | null
          age: string | null
          appearance: string | null
          personality: string | null
          character_type: 'premium' | 'standard'
          reference_image_url: string | null
          traits: string[]
          costumes: Json | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          project_id: string
          name: string
          description?: string | null
          age?: string | null
          appearance?: string | null
          personality?: string | null
          character_type?: 'premium' | 'standard'
          reference_image_url?: string | null
          traits?: string[]
          costumes?: Json | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          name?: string
          description?: string | null
          age?: string | null
          appearance?: string | null
          personality?: string | null
          character_type?: 'premium' | 'standard'
          reference_image_url?: string | null
          traits?: string[]
          costumes?: Json | null
          created_at?: string
          updated_at?: string
        }
      }
      locations: {
        Row: {
          id: string
          project_id: string
          name: string
          description: string | null
          location_type: 'interior' | 'exterior'
          address: string | null
          is_studio: boolean
          contact: string | null
          notes: string | null
          requirements: string[]
          reference_images: string[]
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          project_id: string
          name: string
          description?: string | null
          location_type?: 'interior' | 'exterior'
          address?: string | null
          is_studio?: boolean
          contact?: string | null
          notes?: string | null
          requirements?: string[]
          reference_images?: string[]
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          name?: string
          description?: string | null
          location_type?: 'interior' | 'exterior'
          address?: string | null
          is_studio?: boolean
          contact?: string | null
          notes?: string | null
          requirements?: string[]
          reference_images?: string[]
          created_at?: string
          updated_at?: string
        }
      }
      project_collaborators: {
        Row: {
          id: string
          project_id: string
          user_id: string
          role: 'owner' | 'director' | 'producer' | 'editor' | 'viewer'
          permissions: Json | null
          invited_at: string
          joined_at: string | null
        }
        Insert: {
          id?: string
          project_id: string
          user_id: string
          role?: 'owner' | 'director' | 'producer' | 'editor' | 'viewer'
          permissions?: Json | null
          invited_at?: string
          joined_at?: string | null
        }
        Update: {
          id?: string
          project_id?: string
          user_id?: string
          role?: 'owner' | 'director' | 'producer' | 'editor' | 'viewer'
          permissions?: Json | null
          invited_at?: string
          joined_at?: string | null
        }
      }
      script_elements: {
        Row: {
          id: string
          episode_id: string
          element_type: 'scene_heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition' | 'shot' | 'general'
          content: string
          order_index: number
          character_name: string | null
          location: string | null
          time_of_day: string | null
          is_interior: boolean | null
          shot_details: Json | null
          formatting: Json | null
          ai_generated: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          episode_id: string
          element_type: 'scene_heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition' | 'shot' | 'general'
          content: string
          order_index: number
          character_name?: string | null
          location?: string | null
          time_of_day?: string | null
          is_interior?: boolean | null
          shot_details?: Json | null
          formatting?: Json | null
          ai_generated?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          episode_id?: string
          element_type?: 'scene_heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition' | 'shot' | 'general'
          content?: string
          order_index?: number
          character_name?: string | null
          location?: string | null
          time_of_day?: string | null
          is_interior?: boolean | null
          shot_details?: Json | null
          formatting?: Json | null
          ai_generated?: boolean
          created_at?: string
          updated_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}
