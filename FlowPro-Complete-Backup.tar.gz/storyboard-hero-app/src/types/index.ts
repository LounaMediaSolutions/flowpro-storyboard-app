export interface ScriptElement {
  id: string;
  type: 'scene_heading' | 'action' | 'character' | 'dialogue' | 'parenthetical' | 'transition' | 'shot';
  content: string;
  character?: string;
  location?: string;
  timeOfDay?: string;
  sceneNumber?: number;
  order: number;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  thumbnail?: string;
  projectType: ProjectType;
  genre?: string;
  targetDuration?: number; // in minutes
  estimatedDuration?: number; // calculated from script
  totalEpisodes?: number;
  createdAt: Date;
  updatedAt: Date;
  episodes: Episode[];
  characters: Character[];
  locations: Location[];
  visualStyle: VisualStyle;
  budget?: ProjectBudget;
  productionSettings: ProductionSettings;
}

export interface Episode {
  id: string;
  projectId: string;
  episodeNumber: number;
  title: string;
  description: string;
  scenes: Scene[];
  scriptContent?: ScriptElement[]; // Store actual script content
  targetDuration?: number; // in minutes
  estimatedDuration?: number; // calculated from script
  actualDuration?: number; // final edit duration
  scriptAnalysis?: ScriptAnalysis;
  status: EpisodeStatus;
  createdAt: Date;
  updatedAt: Date;
}

export interface Scene {
  id: string;
  episodeId: string;
  sceneNumber: number;
  title: string;
  description: string;
  location?: string;
  timeOfDay: TimeOfDay;
  shots: Shot[];
  budget?: SceneBudget;
  shootingDay?: number;
  shootingOrder?: number;
  estimatedDuration?: number; // in minutes
  characters: string[]; // character IDs appearing in this scene
  isInterior: boolean;
  weather?: string;
  props?: string[];
  wardrobe?: string[];
  equipment?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Shot {
  id: string;
  sceneId: string;
  shotNumber: number;
  description: string;
  voiceOver?: string;
  dialogue?: string;
  cameraAngle: CameraAngle;
  cameraMovement: CameraMovement;
  characters: string[]; // character IDs in this shot
  estimatedDuration?: number; // in seconds
  shootingNotes?: string;
  cameraEquipment?: string[];
  transition: Transition;
  imageUrl?: string;
  imagePrompt?: string;
  duration?: number;
  technicalSpecs: TechnicalSpecs;
  vfxNotes?: VFXNote[];
  audioNotes?: AudioNote[];
  budget?: ShotBudget;
  createdAt: Date;
  updatedAt: Date;
}

export interface Character {
  id: string;
  projectId: string;
  name: string;
  description: string;
  appearance: string;
  referenceImageUrl?: string;
  traits: string[];
}

export type VisualStyle = 
  | 'photorealistic'
  | 'sketch'
  | 'watercolor'
  | 'comic'
  | 'anime'
  | 'cinematic'
  | 'painterly'
  | 'minimalist'
  | 'noir'
  | 'vintage'
  | 'digital_art'
  | 'concept_art'
  | 'hand_drawn'
  | 'children_book'
  | 'graphic_novel';

export type CameraAngle = 
  | 'wide_shot'
  | 'medium_shot'
  | 'close_up'
  | 'extreme_close_up'
  | 'bird_eye_view'
  | 'worm_eye_view'
  | 'over_shoulder'
  | 'point_of_view'
  | 'dutch_angle';

export type CameraMovement = 
  | 'static'
  | 'pan_left'
  | 'pan_right'
  | 'tilt_up'
  | 'tilt_down'
  | 'zoom_in'
  | 'zoom_out'
  | 'dolly_in'
  | 'dolly_out'
  | 'tracking'
  | 'handheld';

export type Transition = 
  | 'cut'
  | 'fade_in'
  | 'fade_out'
  | 'dissolve'
  | 'wipe'
  | 'iris'
  | 'slide'
  | 'zoom'
  | 'flip';

export type ProjectType = 
  | 'series'
  | 'movie'
  | 'commercial'
  | 'documentary'
  | 'animation'
  | 'music_video'
  | 'short_film'
  | 'web_series'
  | 'tv_pilot'
  | 'promotional';

export interface ScriptAnalysis {
  totalPages: number;
  estimatedDuration: number; // in minutes (1 page = ~1 minute rule)
  sceneCount: number;
  dialoguePercentage: number;
  actionPercentage: number;
  characterCount: number;
  pacing: ScriptPacing;
  warnings: string[];
  suggestions: string[];
}

export type ScriptPacing = 'very_fast' | 'fast' | 'normal' | 'slow' | 'very_slow';

export type ImportMode = 'single_episode' | 'batch_episodes' | 'entire_series' | 'merge_existing';

export interface ExportOptions {
  format: 'pdf' | 'images' | 'screenplay';
  includeScript: boolean;
  includeBranding: boolean;
  logoUrl?: string;
  companyName?: string;
  watermark?: boolean;
  resolution: 'low' | 'medium' | 'high';
  organizationMethod: StoryboardOrganization;
  includeShootingSchedule?: boolean;
  includeCastList?: boolean;
  includeLocationDetails?: boolean;
  filterByEpisode?: string[];
  filterByCharacter?: string[];
  filterByLocation?: string[];
  filterByShootingDay?: number[];
}

export type StoryboardOrganization = 
  | 'by_scene'
  | 'by_episode'
  | 'by_shooting_day'
  | 'by_location'
  | 'by_character'
  | 'by_chronological'
  | 'by_production_order';

export interface ImportOptions {
  importMode: ImportMode;
  targetEpisodes?: string[]; // specific episode IDs to import to
  createNewEpisodes?: boolean;
  episodeStartNumber?: number;
  analyzeScript?: boolean;
  validateTiming?: boolean;
  autoGenerateShots?: boolean;
}

export interface ScriptGenerationRequest {
  brief: string;
  genre?: string;
  tone?: string;
  duration?: number;
  targetAudience?: string;
  style?: string;
}

export interface ImageGenerationRequest {
  prompt: string;
  style: VisualStyle;
  aspectRatio: '16:9' | '4:3' | '1:1' | '9:16';
  quality: 'standard' | 'hd';
  characterContext?: Character[];
}

// Professional Film Production Types
export type EpisodeStatus = 'draft' | 'pre_production' | 'production' | 'post_production' | 'completed';
export type TimeOfDay = 'dawn' | 'morning' | 'day' | 'afternoon' | 'golden_hour' | 'dusk' | 'night';

export interface Location {
  id: string;
  projectId: string;
  name: string;
  address?: string;
  description: string;
  type: LocationType;
  availability: string[];
  cost?: number;
  contact?: string;
  notes?: string;
}

export type LocationType = 'interior' | 'exterior' | 'studio' | 'greenscreen' | 'location';

export interface TechnicalSpecs {
  focalLength?: string;
  aperture?: string;
  iso?: string;
  frameRate?: number;
  resolution?: string;
  colorProfile?: string;
  lens?: string;
  equipment?: string[];
}

export interface VFXNote {
  id: string;
  shotId: string;
  type: VFXType;
  description: string;
  complexity: VFXComplexity;
  reference?: string;
  estimatedCost?: number;
  assignee?: string;
  status: VFXStatus;
  createdAt: Date;
}

export type VFXType = 'compositing' | 'greenscreen' | 'cgi' | 'color_grading' | 'motion_graphics' | 'cleanup' | 'enhancement';
export type VFXComplexity = 'simple' | 'medium' | 'complex' | 'hero';
export type VFXStatus = 'pending' | 'in_progress' | 'review' | 'completed';

export interface AudioNote {
  id: string;
  shotId: string;
  type: AudioType;
  description: string;
  track?: string;
  volume?: number;
  fadeIn?: number;
  fadeOut?: number;
  effects?: string[];
  reference?: string;
}

export type AudioType = 'dialogue' | 'voiceover' | 'sfx' | 'music' | 'ambient' | 'foley';

export interface ProjectBudget {
  totalBudget: number;
  categories: BudgetCategory[];
  spent: number;
  remaining: number;
}

export interface BudgetCategory {
  id: string;
  name: string;
  allocated: number;
  spent: number;
  items: BudgetItem[];
}

export interface BudgetItem {
  id: string;
  categoryId: string;
  name: string;
  description?: string;
  unitCost: number;
  quantity: number;
  totalCost: number;
  vendor?: string;
  status: BudgetStatus;
}

export type BudgetStatus = 'planned' | 'approved' | 'ordered' | 'received' | 'paid';

export interface SceneBudget {
  sceneId: string;
  location: number;
  cast: number;
  crew: number;
  equipment: number;
  props: number;
  wardrobe: number;
  makeup: number;
  catering: number;
  transport: number;
  misc: number;
  total: number;
}

export interface ShotBudget {
  shotId: string;
  vfx: number;
  equipment: number;
  talent: number;
  location: number;
  post: number;
  total: number;
}

export interface ProductionSettings {
  defaultFrameRate: number;
  defaultResolution: string;
  workingColorSpace: string;
  deliverySpecs: DeliverySpecs;
  workflow: WorkflowSettings;
}

export interface DeliverySpecs {
  formats: string[];
  resolutions: string[];
  frameRates: number[];
  colorSpaces: string[];
  audioSpecs: AudioSpecs;
}

export interface AudioSpecs {
  sampleRate: number;
  bitDepth: number;
  channels: number;
  format: string;
}

export interface WorkflowSettings {
  backupEnabled: boolean;
  versionControl: boolean;
  collaborationMode: boolean;
  autoSave: boolean;
  notifications: boolean;
}

export interface CrewMember {
  id: string;
  name: string;
  role: string;
  department: string;
  contact: string;
  rate?: number;
  availability: string[];
}

export interface CastMember {
  id: string;
  characterId: string;
  name: string;
  role: string;
  contact: string;
  rate?: number;
  wardrobe?: string[];
  makeup?: string[];
  availability: string[];
}

export interface Equipment {
  id: string;
  name: string;
  category: EquipmentCategory;
  description?: string;
  specifications?: string[];
  rental?: boolean;
  cost?: number;
  vendor?: string;
  availability: string[];
}

export type EquipmentCategory = 'camera' | 'lens' | 'lighting' | 'audio' | 'grip' | 'electric' | 'post' | 'transport';

export interface XMLExportOptions extends ExportOptions {
  targetNLE: 'premiere' | 'davinci' | 'avid' | 'fcpx';
  includeMedia: boolean;
  includeAudio: boolean;
  includeEffects: boolean;
  timecodeStart: string;
  frameRate: number;
}

export interface AdvancedExportOptions extends ExportOptions {
  filterBy: ExportFilter;
  customLayout: boolean;
  includeNotes: boolean;
  includeVFX: boolean;
  includeBudget: boolean;
  includeSchedule: boolean;
  pageOrientation: 'portrait' | 'landscape';
  paperSize: 'A4' | 'Letter' | 'Tabloid';
}

export interface ExportFilter {
  episodes?: string[];
  scenes?: string[];
  locations?: string[];
  characters?: string[];
  vfxOnly?: boolean;
  dateRange?: {
    start: Date;
    end: Date;
  };
}

// User Management and Authentication
export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department?: string;
  permissions: Permission[];
  avatar?: string;
  isActive: boolean;
  lastLogin?: Date;
  createdAt: Date;
}

export type UserRole = 'admin' | 'director' | 'producer' | 'cinematographer' | 'editor' | 'actor' | 'crew';

export type Permission = 
  | 'project_create' 
  | 'project_edit' 
  | 'project_delete'
  | 'episode_create'
  | 'episode_edit'
  | 'script_import'
  | 'script_edit'
  | 'storyboard_create'
  | 'storyboard_edit'
  | 'budget_view'
  | 'budget_edit'
  | 'production_manage'
  | 'reports_view'
  | 'users_manage'
  | 'export_all';

// Production Reports and Tracking
export interface ProductionReport {
  id: string;
  projectId: string;
  episodeId?: string;
  date: Date;
  type: ReportType;
  status: ProductionStatus;
  summary: string;
  details: ReportDetails;
  createdBy: string;
  createdAt: Date;
}

export type ReportType = 'daily' | 'weekly' | 'scene_completion' | 'episode_wrap' | 'project_summary';
export type ProductionStatus = 'on_schedule' | 'ahead' | 'behind' | 'on_hold' | 'completed';

export interface ReportDetails {
  scenesCompleted: number;
  shotsCompleted: number;
  hoursWorked: number;
  budgetSpent: number;
  issues?: string[];
  highlights?: string[];
  nextSteps?: string[];
  attendees?: string[];
  weather?: string;
  equipment?: string[];
  locations?: string[];
}

// Production Scheduling and Tasks
export interface ProductionSchedule {
  id: string;
  projectId: string;
  date: Date;
  scenes: ScheduledScene[];
  crew: ScheduledCrew[];
  equipment: ScheduledEquipment[];
  locations: string[];
  callTime: string;
  wrapTime?: string;
  notes?: string;
}

export interface ScheduledScene {
  sceneId: string;
  episodeId: string;
  estimatedDuration: number;
  priority: 'high' | 'medium' | 'low';
  requirements: string[];
  status: 'scheduled' | 'in_progress' | 'completed' | 'postponed';
}

export interface ScheduledCrew {
  userId: string;
  role: string;
  callTime: string;
  department: string;
  isRequired: boolean;
}

export interface ScheduledEquipment {
  equipmentId: string;
  quantity: number;
  pickupTime: string;
  returnTime: string;
  operator?: string;
}

// Task Management
export interface Task {
  id: string;
  title: string;
  description: string;
  type: TaskType;
  priority: TaskPriority;
  status: TaskStatus;
  assignedTo: string[];
  projectId: string;
  episodeId?: string;
  sceneId?: string;
  dueDate?: Date;
  completedAt?: Date;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export type TaskType = 'pre_production' | 'production' | 'post_production' | 'admin' | 'creative';
export type TaskPriority = 'critical' | 'high' | 'medium' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'review' | 'completed' | 'cancelled';

// Checklist System
export interface Checklist {
  id: string;
  name: string;
  description: string;
  type: ChecklistType;
  items: ChecklistItem[];
  projectId: string;
  episodeId?: string;
  assignedTo?: string[];
  isTemplate: boolean;
  createdAt: Date;
}

export type ChecklistType = 'pre_production' | 'shoot_day' | 'post_production' | 'equipment' | 'location';

export interface ChecklistItem {
  id: string;
  title: string;
  description?: string;
  isRequired: boolean;
  isCompleted: boolean;
  completedBy?: string;
  completedAt?: Date;
  order: number;
}

// Notifications and Comments
export interface Comment {
  id: string;
  content: string;
  authorId: string;
  targetType: 'project' | 'episode' | 'scene' | 'shot' | 'task';
  targetId: string;
  parentId?: string; // For replies
  isResolved: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Notification {
  id: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  data?: any;
  isRead: boolean;
  createdAt: Date;
}

export type NotificationType = 
  | 'task_assigned' 
  | 'scene_completed' 
  | 'budget_alert' 
  | 'schedule_change' 
  | 'comment_mention'
  | 'report_ready'
  | 'approval_needed';

// Mobile and Responsive Features
export interface MobileConfig {
  enableOfflineMode: boolean;
  syncInterval: number;
  cacheImages: boolean;
  lowDataMode: boolean;
  pushNotifications: boolean;
}

// Analytics and Insights
export interface ProjectAnalytics {
  projectId: string;
  totalScenes: number;
  completedScenes: number;
  totalShots: number;
  completedShots: number;
  budgetUtilization: number;
  schedulePerformance: number;
  teamProductivity: number;
  qualityScore: number;
  generatedAt: Date;
}

// AI Image Generation System
export interface AIService {
  id: string;
  name: string;
  type: AIServiceType;
  apiEndpoint?: string;
  isConnected: boolean;
  accountInfo?: AIAccountInfo;
  pricing?: AIPricing;
  capabilities: AICapability[];
  promptTemplates: AIPromptTemplate[];
}

export type AIServiceType = 'midjourney' | 'openart' | 'dalle' | 'stable_diffusion' | 'firefly' | 'internal';

export interface AIAccountInfo {
  userId?: string;
  planType: 'free' | 'basic' | 'pro' | 'enterprise';
  creditsRemaining?: number;
  monthlyLimit?: number;
  subscriptionStatus: 'active' | 'inactive' | 'expired' | 'trial';
  billingCycle?: 'monthly' | 'yearly';
  lastUsed?: Date;
}

export interface AIPricing {
  costPerGeneration: number;
  currency: 'USD' | 'EUR' | 'GBP';
  bulkDiscounts?: BulkDiscount[];
  subscriptionPlans?: SubscriptionPlan[];
}

export interface BulkDiscount {
  minimumGenerations: number;
  discountPercentage: number;
}

export interface SubscriptionPlan {
  name: string;
  monthlyPrice: number;
  generationsIncluded: number;
  additionalFeatures: string[];
}

export type AICapability = 
  | 'text_to_image'
  | 'image_to_image'
  | 'style_transfer'
  | 'upscaling'
  | 'inpainting'
  | 'background_removal'
  | 'face_enhancement'
  | 'lighting_control'
  | 'camera_control'
  | 'technical_prompts';

export interface AIPromptTemplate {
  id: string;
  name: string;
  serviceType: AIServiceType;
  category: PromptCategory;
  template: string;
  requiredFields: string[];
  optionalFields: string[];
  examples: string[];
}

export type PromptCategory = 
  | 'cinematic'
  | 'portrait'
  | 'landscape'
  | 'action'
  | 'macro'
  | 'aerial'
  | 'interior'
  | 'exterior'
  | 'product'
  | 'technical';

export interface AIGenerationRequest {
  id: string;
  shotId: string;
  serviceType: AIServiceType;
  prompt: string;
  technicalPrompt: string;
  parameters: AIGenerationParameters;
  status: GenerationStatus;
  createdAt: Date;
  completedAt?: Date;
  resultUrls?: string[];
  error?: string;
  cost?: number;
  metadata?: Record<string, any>;
}

export type GenerationStatus = 
  | 'pending'
  | 'queued'
  | 'processing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface AIGenerationParameters {
  aspectRatio: string;
  quality: 'draft' | 'standard' | 'high' | 'ultra';
  styleIntensity: number; // 0-100
  creativityLevel: number; // 0-100
  seed?: number;
  variations?: number;
  upscale?: boolean;
  negativePrompt?: string;
  customParameters?: Record<string, any>;
}

export interface TechnicalPromptBuilder {
  shotId: string;
  baseDescription: string;
  cameraSpecs: CameraSpecifications;
  lightingSpecs: LightingSpecifications;
  locationSpecs: LocationSpecifications;
  characterSpecs: CharacterSpecifications[];
  visualStyle: DetailedVisualStyle;
  additionalNotes?: string;
}

export interface CameraSpecifications {
  cameraType: string; // 'RED Komodo', 'ARRI Alexa', 'Canon C300', etc.
  lens: string; // '50mm prime', '24-70mm f/2.8', etc.
  focalLength: string;
  aperture: string; // 'f/2.8', 'f/5.6', etc.
  shutterSpeed?: string;
  iso?: string;
  filterUsed?: string; // 'ND filter', 'polarizer', etc.
  mountType?: string; // 'tripod', 'handheld', 'gimbal', 'crane', etc.
  movement: CameraMovement;
  height: string; // 'eye level', 'low angle', 'high angle', etc.
  distance: string; // 'close-up', 'medium shot', 'wide shot', etc.
}

export interface LightingSpecifications {
  primaryLight: LightSource;
  fillLight?: LightSource;
  backLight?: LightSource;
  practicalLights?: LightSource[];
  ambientLighting: string; // 'natural', 'artificial', 'mixed'
  colorTemperature: string; // '3200K', '5600K', 'daylight', etc.
  lightingRatio?: string; // '2:1', '3:1', '4:1', etc.
  mood: LightingMood;
  timeOfDay: DetailedTimeOfDay;
  weather?: WeatherCondition;
}

export interface LightSource {
  type: string; // 'softbox', 'key light', 'LED panel', 'natural window', etc.
  intensity: string; // 'bright', 'medium', 'dim', 'subtle'
  direction: string; // 'front', 'side', 'back', 'top', 'bottom'
  color?: string; // 'warm', 'cool', 'neutral', specific color
  diffusion?: string; // 'soft', 'hard', 'diffused'
}

export type LightingMood = 
  | 'dramatic'
  | 'soft'
  | 'harsh'
  | 'mysterious'
  | 'romantic'
  | 'clinical'
  | 'warm'
  | 'cool'
  | 'natural'
  | 'artificial';

export type DetailedTimeOfDay = 
  | 'early_morning'
  | 'morning'
  | 'late_morning'
  | 'noon'
  | 'afternoon'
  | 'late_afternoon'
  | 'golden_hour'
  | 'dusk'
  | 'blue_hour'
  | 'night'
  | 'late_night'
  | 'dawn';

export type WeatherCondition = 
  | 'clear'
  | 'cloudy'
  | 'overcast'
  | 'foggy'
  | 'rainy'
  | 'stormy'
  | 'snowy'
  | 'windy'
  | 'hazy';

export interface LocationSpecifications {
  setting: string; // 'modern office', 'vintage cafe', 'forest clearing', etc.
  architecture?: string; // 'contemporary', 'classical', 'industrial', etc.
  interiorStyle?: string; // 'minimalist', 'ornate', 'rustic', etc.
  materials: string[]; // ['wood', 'glass', 'concrete', 'fabric']
  colors: string[]; // ['warm browns', 'cool blues', 'neutral grays']
  textures: string[]; // ['smooth', 'rough', 'polished', 'worn']
  props?: string[]; // ['vintage furniture', 'modern art', 'plants']
  atmosphere: string; // 'professional', 'cozy', 'intimidating', etc.
}

export interface CharacterSpecifications {
  characterId: string;
  name: string;
  description: string;
  wardrobe: WardrobeDetails;
  makeup?: MakeupDetails;
  pose?: string;
  expression?: string;
  eyeline?: string; // 'camera', 'off-camera', 'down', 'up'
  position?: string; // 'center frame', 'left third', 'background'
}

export interface WardrobeDetails {
  outfit: string; // 'business suit', 'casual wear', 'period costume'
  colors: string[];
  style: string; // 'contemporary', 'vintage', 'futuristic'
  accessories?: string[]; // ['watch', 'jewelry', 'hat']
  condition?: string; // 'pristine', 'worn', 'distressed'
}

export interface MakeupDetails {
  style: string; // 'natural', 'dramatic', 'period-appropriate'
  emphasis?: string; // 'eyes', 'lips', 'contour'
  specialEffects?: string[]; // ['aging', 'bruising', 'fantasy']
}

export interface DetailedVisualStyle {
  overallMood: string;
  colorPalette: string[];
  visualReferences?: string[]; // Film/photography references
  grading: ColorGrading;
  composition: CompositionRules;
  texture?: string; // 'smooth', 'gritty', 'organic'
  contrast: string; // 'high', 'low', 'medium'
  saturation: string; // 'vibrant', 'muted', 'desaturated'
}

export interface ColorGrading {
  highlights: string; // 'warm', 'cool', 'neutral'
  shadows: string;
  midtones: string;
  overall: string; // 'cinematic', 'natural', 'stylized'
}

export interface CompositionRules {
  ruleOfThirds: boolean;
  leadingLines?: string[];
  symmetry?: string; // 'horizontal', 'vertical', 'radial'
  depth: string; // 'shallow', 'deep', 'compressed'
  framing?: string; // 'tight', 'loose', 'natural'
}

export interface AIPromptGenerator {
  generateTechnicalPrompt(builder: TechnicalPromptBuilder, serviceType: AIServiceType): string;
  generateStylePrompt(visualStyle: DetailedVisualStyle, serviceType: AIServiceType): string;
  generateCameraPrompt(specs: CameraSpecifications, serviceType: AIServiceType): string;
  generateLightingPrompt(specs: LightingSpecifications, serviceType: AIServiceType): string;
  optimizePrompt(prompt: string, serviceType: AIServiceType): string;
}

export interface AIImageManagement {
  generateImage(request: AIGenerationRequest): Promise<AIGenerationResult>;
  importExternalImage(shotId: string, imageUrl: string, metadata?: Record<string, any>): Promise<void>;
  exportPrompt(shotId: string, serviceType: AIServiceType): Promise<string>;
  batchGenerate(requests: AIGenerationRequest[]): Promise<AIGenerationResult[]>;
  manageQueue(): Promise<void>;
}

export interface AIGenerationResult {
  requestId: string;
  success: boolean;
  imageUrls?: string[];
  error?: string;
  cost?: number;
  generationTime?: number;
  metadata?: Record<string, any>;
}
