import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { 
  Project, Episode, Scene, Shot, Character, Location, 
  VisualStyle, VFXNote, AudioNote, CrewMember, CastMember, 
  Equipment, ProjectBudget, SceneBudget, ShotBudget,
  EpisodeStatus, TimeOfDay
} from '../types';

interface StoryboardState {
  // Project management
  projects: Project[];
  currentProject: Project | null;
  currentEpisode: Episode | null;
  
  // User management
  currentUser: any | null; // Simplified for demo
  users: any[];
  
  // UI state
  isGenerating: boolean;
  currentView: 'dashboard' | 'episodes' | 'script' | 'script-import' | 'storyboard' | 'ai-services' | 'settings' | 'production' | 'budget' | 'reports' | 'users' | 'export';
  selectedShot: Shot | null;
  selectedScene: Scene | null;
  
  // Mobile and responsive state
  isMobile: boolean;
  sidebarCollapsed: boolean;
  
  // Actions
  createProject: (title: string, description: string) => void;
  updateProject: (projectId: string, updates: Partial<Project>) => void;
  deleteProject: (projectId: string) => void;
  setCurrentProject: (project: Project | null) => void;
  
  // Episode management
  createEpisode: (projectId: string, title: string, description: string) => Episode | null;
  updateEpisode: (episodeId: string, updates: Partial<Episode>) => void;
  deleteEpisode: (episodeId: string) => void;
  setCurrentEpisode: (episode: Episode | null) => void;
  batchCreateEpisodes: (projectId: string, episodes: Partial<Episode>[]) => void;
  
  // Scene management
  addScene: (episodeId: string, title: string, description: string, location?: string) => Scene | null;
  updateScene: (sceneId: string, updates: Partial<Scene>) => void;
  deleteScene: (sceneId: string) => void;
  reorderScenes: (episodeId: string, fromIndex: number, toIndex: number) => void;
  setSelectedScene: (scene: Scene | null) => void;
  
  // Shot management
  addShot: (sceneId: string, description: string, voiceOver?: string) => void;
  updateShot: (shotId: string, updates: Partial<Shot>) => void;
  deleteShot: (shotId: string) => void;
  reorderShots: (sceneId: string, fromIndex: number, toIndex: number) => void;
  setSelectedShot: (shot: Shot | null) => void;
  
  // Character management
  addCharacter: (projectId: string, name: string, description: string, appearance: string) => void;
  updateCharacter: (characterId: string, updates: Partial<Character>) => void;
  deleteCharacter: (characterId: string) => void;
  
  // Location management
  addLocation: (projectId: string, location: Omit<Location, 'id' | 'projectId'>) => void;
  updateLocation: (locationId: string, updates: Partial<Location>) => void;
  deleteLocation: (locationId: string) => void;
  
  // VFX management
  addVFXNote: (shotId: string, vfxNote: Omit<VFXNote, 'id' | 'shotId' | 'createdAt'>) => void;
  updateVFXNote: (vfxNoteId: string, updates: Partial<VFXNote>) => void;
  deleteVFXNote: (vfxNoteId: string) => void;
  
  // Audio management
  addAudioNote: (shotId: string, audioNote: Omit<AudioNote, 'id' | 'shotId'>) => void;
  updateAudioNote: (audioNoteId: string, updates: Partial<AudioNote>) => void;
  deleteAudioNote: (audioNoteId: string) => void;
  
  // Budget management
  updateProjectBudget: (projectId: string, budget: Partial<ProjectBudget>) => void;
  updateSceneBudget: (sceneId: string, budget: Partial<SceneBudget>) => void;
  updateShotBudget: (shotId: string, budget: Partial<ShotBudget>) => void;
  
  // AI generation
  generateScript: (projectId: string, brief: string) => Promise<void>;
  generateImage: (shotId: string, prompt: string, style: VisualStyle) => Promise<void>;
  regenerateImage: (shotId: string) => Promise<void>;
  
  // User management
  setCurrentUser: (user: any) => void;
  updateUserSettings: (settings: any) => void;
  
  // Mobile and UI state
  setIsMobile: (isMobile: boolean) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  
  // Helper functions
  findShot: (shotId: string) => { shot: Shot; scene: Scene; episode: Episode; project: Project } | null;
  
  // UI actions
  setCurrentView: (view: 'dashboard' | 'episodes' | 'script' | 'script-import' | 'storyboard' | 'ai-services' | 'settings' | 'production' | 'budget' | 'reports' | 'users' | 'export') => void;
  setIsGenerating: (isGenerating: boolean) => void;
}

export const useStoryboardStore = create<StoryboardState>()((set, get) => ({
      // Initial state
      projects: [],
      currentProject: null,
      currentEpisode: null,
      currentUser: null,
      users: [],
      isGenerating: false,
      currentView: 'dashboard',
      selectedShot: null,
      selectedScene: null,
      isMobile: false,
      sidebarCollapsed: false,
      
      // Project actions
      createProject: (title: string, description: string) => {
        const newProject: Project = {
          id: uuidv4(),
          title,
          description,
          projectType: 'series',
          createdAt: new Date(),
          updatedAt: new Date(),
          episodes: [],
          characters: [],
          locations: [],
          visualStyle: 'cinematic',
          productionSettings: {
            defaultFrameRate: 24,
            defaultResolution: '1920x1080',
            workingColorSpace: 'Rec.709',
            deliverySpecs: {
              formats: ['MP4', 'MOV'],
              resolutions: ['1920x1080', '3840x2160'],
              frameRates: [24, 25, 30, 60],
              colorSpaces: ['Rec.709', 'Rec.2020'],
              audioSpecs: {
                sampleRate: 48000,
                bitDepth: 24,
                channels: 2,
                format: 'WAV'
              }
            },
            workflow: {
              backupEnabled: true,
              versionControl: true,
              collaborationMode: false,
              autoSave: true,
              notifications: true
            }
          }
        };
        
        set(state => ({
          projects: [...state.projects, newProject],
          currentProject: newProject
        }));
      },
      
      updateProject: (projectId: string, updates: Partial<Project>) => {
        set(state => ({
          projects: state.projects.map(project =>
            project.id === projectId
              ? { ...project, ...updates, updatedAt: new Date() }
              : project
          ),
          currentProject: state.currentProject?.id === projectId
            ? { ...state.currentProject, ...updates, updatedAt: new Date() }
            : state.currentProject
        }));
      },
      
      deleteProject: (projectId: string) => {
        set(state => ({
          projects: state.projects.filter(project => project.id !== projectId),
          currentProject: state.currentProject?.id === projectId ? null : state.currentProject
        }));
      },
      
      setCurrentProject: (project: Project | null) => {
        set({ currentProject: project, currentEpisode: null });
      },
      
      // Episode actions
      createEpisode: (projectId: string, title: string, description: string) => {
        const project = get().projects.find(p => p.id === projectId);
        if (!project) return null;
        
        const newEpisode: Episode = {
          id: uuidv4(),
          projectId,
          episodeNumber: project.episodes.length + 1,
          title,
          description,
          scenes: [],
          status: 'draft',
          createdAt: new Date(),
          updatedAt: new Date()
        };
        
        get().updateProject(projectId, {
          episodes: [...project.episodes, newEpisode]
        });
        
        return newEpisode;
      },
      
      updateEpisode: (episodeId: string, updates: Partial<Episode>) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.id === episodeId)
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.map(episode =>
          episode.id === episodeId
            ? { ...episode, ...updates, updatedAt: new Date() }
            : episode
        );
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Update current episode if it's the one being updated
        if (state.currentEpisode?.id === episodeId) {
          set({ currentEpisode: { ...state.currentEpisode, ...updates } });
        }
      },
      
      deleteEpisode: (episodeId: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.id === episodeId)
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.filter(episode => episode.id !== episodeId);
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Clear current episode if it was deleted
        if (state.currentEpisode?.id === episodeId) {
          set({ currentEpisode: null });
        }
      },
      
      setCurrentEpisode: (episode: Episode | null) => {
        set({ currentEpisode: episode });
      },
      
      batchCreateEpisodes: (projectId: string, episodeData: Partial<Episode>[]) => {
        const project = get().projects.find(p => p.id === projectId);
        if (!project) return;
        
        const newEpisodes = episodeData.map((data, index) => ({
          id: uuidv4(),
          projectId,
          episodeNumber: project.episodes.length + index + 1,
          title: data.title || `Episode ${project.episodes.length + index + 1}`,
          description: data.description || '',
          scenes: [],
          status: data.status || 'draft' as EpisodeStatus,
          createdAt: new Date(),
          updatedAt: new Date(),
          ...data
        }));
        
        get().updateProject(projectId, {
          episodes: [...project.episodes, ...newEpisodes]
        });
      },
      
      // Scene actions
      addScene: (episodeId: string, title: string, description: string, location?: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.id === episodeId)
        );
        
        if (!project) return null;
        
        const episode = project.episodes.find(e => e.id === episodeId);
        if (!episode) return null;
        
        const newScene: Scene = {
          id: uuidv4(),
          episodeId,
          sceneNumber: episode.scenes.length + 1,
          title,
          description,
          location,
          timeOfDay: 'day',
          characters: [],
          isInterior: false,
          shots: [],
          createdAt: new Date(),
          updatedAt: new Date()
        };
        
        const updatedEpisodes = project.episodes.map(ep =>
          ep.id === episodeId
            ? { ...ep, scenes: [...ep.scenes, newScene], updatedAt: new Date() }
            : ep
        );
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        return newScene;
      },
      
      updateScene: (sceneId: string, updates: Partial<Scene>) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.scenes.some(s => s.id === sceneId))
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.map(episode => ({
          ...episode,
          scenes: episode.scenes.map(scene =>
            scene.id === sceneId
              ? { ...scene, ...updates, updatedAt: new Date() }
              : scene
          )
        }));
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Update selected scene if it's the current one
        if (state.selectedScene?.id === sceneId) {
          set({ selectedScene: { ...state.selectedScene, ...updates } });
        }
      },
      
      deleteScene: (sceneId: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.scenes.some(s => s.id === sceneId))
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.map(episode => ({
          ...episode,
          scenes: episode.scenes.filter(scene => scene.id !== sceneId)
        }));
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Clear selected scene if it was deleted
        if (state.selectedScene?.id === sceneId) {
          set({ selectedScene: null });
        }
      },
      
      reorderScenes: (episodeId: string, fromIndex: number, toIndex: number) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.id === episodeId)
        );
        
        if (!project) return;
        
        const episode = project.episodes.find(e => e.id === episodeId);
        if (!episode) return;
        
        const scenes = [...episode.scenes];
        const [removed] = scenes.splice(fromIndex, 1);
        scenes.splice(toIndex, 0, removed);
        
        // Update scene numbers
        const updatedScenes = scenes.map((scene, index) => ({
          ...scene,
          sceneNumber: index + 1
        }));
        
        const updatedEpisodes = project.episodes.map(ep =>
          ep.id === episodeId
            ? { ...ep, scenes: updatedScenes }
            : ep
        );
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
      },
      
      setSelectedScene: (scene: Scene | null) => {
        set({ selectedScene: scene });
      },
      
      // Shot actions
      addShot: (sceneId: string, description: string, voiceOver?: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.scenes.some(s => s.id === sceneId))
        );
        
        if (!project) return;
        
        const episode = project.episodes.find(e => 
          e.scenes.some(s => s.id === sceneId)
        );
        if (!episode) return;
        
        const scene = episode.scenes.find(s => s.id === sceneId);
        if (!scene) return;
        
        const newShot: Shot = {
          id: uuidv4(),
          sceneId,
          shotNumber: scene.shots.length + 1,
          description,
          voiceOver,
          characters: [],
          cameraAngle: 'medium_shot',
          cameraMovement: 'static',
          transition: 'cut',
          technicalSpecs: {
            frameRate: project.productionSettings.defaultFrameRate,
            resolution: project.productionSettings.defaultResolution,
            colorProfile: project.productionSettings.workingColorSpace
          },
          createdAt: new Date(),
          updatedAt: new Date()
        };
        
        const updatedEpisodes = project.episodes.map(ep =>
          ep.id === episode.id
            ? {
                ...ep,
                scenes: ep.scenes.map(s =>
                  s.id === sceneId
                    ? { ...s, shots: [...s.shots, newShot], updatedAt: new Date() }
                    : s
                )
              }
            : ep
        );
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
      },
      
      updateShot: (shotId: string, updates: Partial<Shot>) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.scenes.some(s => s.shots.some(shot => shot.id === shotId)))
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.map(episode => ({
          ...episode,
          scenes: episode.scenes.map(scene => ({
            ...scene,
            shots: scene.shots.map(shot =>
              shot.id === shotId
                ? { ...shot, ...updates, updatedAt: new Date() }
                : shot
            )
          }))
        }));
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Update selected shot if it's the current one
        if (state.selectedShot?.id === shotId) {
          set({ selectedShot: { ...state.selectedShot, ...updates } });
        }
      },
      
      deleteShot: (shotId: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.episodes.some(e => e.scenes.some(s => s.shots.some(shot => shot.id === shotId)))
        );
        
        if (!project) return;
        
        const updatedEpisodes = project.episodes.map(episode => ({
          ...episode,
          scenes: episode.scenes.map(scene => ({
            ...scene,
            shots: scene.shots.filter(shot => shot.id !== shotId)
          }))
        }));
        
        get().updateProject(project.id, { episodes: updatedEpisodes });
        
        // Clear selected shot if it was deleted
        if (state.selectedShot?.id === shotId) {
          set({ selectedShot: null });
        }
      },
      
      reorderShots: (sceneId: string, fromIndex: number, toIndex: number) => {
        const state = get();
        let targetScene: Scene | null = null;
        let targetEpisode: Episode | null = null;
        let targetProject: Project | null = null;
        
        // Find the scene, episode, and project
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            const scene = episode.scenes.find(s => s.id === sceneId);
            if (scene) {
              targetScene = scene;
              targetEpisode = episode;
              targetProject = project;
              break;
            }
          }
          if (targetScene) break;
        }
        
        if (!targetProject || !targetEpisode || !targetScene) return;
        
        const shots = [...targetScene.shots];
        const [removed] = shots.splice(fromIndex, 1);
        shots.splice(toIndex, 0, removed);
        
        // Update shot numbers
        const updatedShots = shots.map((shot, index) => ({
          ...shot,
          shotNumber: index + 1
        }));
        
        const updatedEpisodes = targetProject.episodes.map(episode =>
          episode.id === targetEpisode.id
            ? {
                ...episode,
                scenes: episode.scenes.map(s =>
                  s.id === sceneId
                    ? { ...s, shots: updatedShots }
                    : s
                )
              }
            : episode
        );
        
        get().updateProject(targetProject.id, { episodes: updatedEpisodes });
      },
      
      setSelectedShot: (shot: Shot | null) => {
        set({ selectedShot: shot });
      },
      
      // Character actions
      addCharacter: (projectId: string, name: string, description: string, appearance: string) => {
        const project = get().projects.find(p => p.id === projectId);
        if (!project) return;
        
        const newCharacter: Character = {
          id: uuidv4(),
          projectId,
          name,
          description,
          appearance,
          traits: []
        };
        
        get().updateProject(projectId, {
          characters: [...project.characters, newCharacter]
        });
      },
      
      updateCharacter: (characterId: string, updates: Partial<Character>) => {
        const state = get();
        const project = state.projects.find(p => 
          p.characters.some(c => c.id === characterId)
        );
        
        if (!project) return;
        
        const updatedCharacters = project.characters.map(character =>
          character.id === characterId
            ? { ...character, ...updates }
            : character
        );
        
        get().updateProject(project.id, { characters: updatedCharacters });
      },
      
      deleteCharacter: (characterId: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.characters.some(c => c.id === characterId)
        );
        
        if (!project) return;
        
        const updatedCharacters = project.characters.filter(
          character => character.id !== characterId
        );
        
        get().updateProject(project.id, { characters: updatedCharacters });
      },
      
      // Location management
      addLocation: (projectId: string, location: Omit<Location, 'id' | 'projectId'>) => {
        const project = get().projects.find(p => p.id === projectId);
        if (!project) return;
        
        const newLocation: Location = {
          id: uuidv4(),
          projectId,
          ...location
        };
        
        get().updateProject(projectId, {
          locations: [...project.locations, newLocation]
        });
      },
      
      updateLocation: (locationId: string, updates: Partial<Location>) => {
        const state = get();
        const project = state.projects.find(p => 
          p.locations.some(l => l.id === locationId)
        );
        
        if (!project) return;
        
        const updatedLocations = project.locations.map(location =>
          location.id === locationId
            ? { ...location, ...updates }
            : location
        );
        
        get().updateProject(project.id, { locations: updatedLocations });
      },
      
      deleteLocation: (locationId: string) => {
        const state = get();
        const project = state.projects.find(p => 
          p.locations.some(l => l.id === locationId)
        );
        
        if (!project) return;
        
        const updatedLocations = project.locations.filter(
          location => location.id !== locationId
        );
        
        get().updateProject(project.id, { locations: updatedLocations });
      },
      
      // VFX management
      addVFXNote: (shotId: string, vfxNote: Omit<VFXNote, 'id' | 'shotId' | 'createdAt'>) => {
        const state = get();
        const result = get().findShot(shotId);
        if (!result) return;
        
        const newVFXNote: VFXNote = {
          id: uuidv4(),
          shotId,
          createdAt: new Date(),
          ...vfxNote
        };
        
        const currentVFXNotes = result.shot.vfxNotes || [];
        get().updateShot(shotId, {
          vfxNotes: [...currentVFXNotes, newVFXNote]
        });
      },
      
      updateVFXNote: (vfxNoteId: string, updates: Partial<VFXNote>) => {
        const state = get();
        // Find the shot containing this VFX note
        let targetShot: Shot | null = null;
        
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            for (const scene of episode.scenes) {
              for (const shot of scene.shots) {
                if (shot.vfxNotes?.some(note => note.id === vfxNoteId)) {
                  targetShot = shot;
                  break;
                }
              }
              if (targetShot) break;
            }
            if (targetShot) break;
          }
          if (targetShot) break;
        }
        
        if (!targetShot) return;
        
        const updatedVFXNotes = (targetShot.vfxNotes || []).map(note =>
          note.id === vfxNoteId ? { ...note, ...updates } : note
        );
        
        get().updateShot(targetShot.id, { vfxNotes: updatedVFXNotes });
      },
      
      deleteVFXNote: (vfxNoteId: string) => {
        const state = get();
        // Find the shot containing this VFX note
        let targetShot: Shot | null = null;
        
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            for (const scene of episode.scenes) {
              for (const shot of scene.shots) {
                if (shot.vfxNotes?.some(note => note.id === vfxNoteId)) {
                  targetShot = shot;
                  break;
                }
              }
              if (targetShot) break;
            }
            if (targetShot) break;
          }
          if (targetShot) break;
        }
        
        if (!targetShot) return;
        
        const updatedVFXNotes = (targetShot.vfxNotes || []).filter(
          note => note.id !== vfxNoteId
        );
        
        get().updateShot(targetShot.id, { vfxNotes: updatedVFXNotes });
      },
      
      // Audio management
      addAudioNote: (shotId: string, audioNote: Omit<AudioNote, 'id' | 'shotId'>) => {
        const result = get().findShot(shotId);
        if (!result) return;
        
        const newAudioNote: AudioNote = {
          id: uuidv4(),
          shotId,
          ...audioNote
        };
        
        const currentAudioNotes = result.shot.audioNotes || [];
        get().updateShot(shotId, {
          audioNotes: [...currentAudioNotes, newAudioNote]
        });
      },
      
      updateAudioNote: (audioNoteId: string, updates: Partial<AudioNote>) => {
        const state = get();
        // Find the shot containing this audio note
        let targetShot: Shot | null = null;
        
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            for (const scene of episode.scenes) {
              for (const shot of scene.shots) {
                if (shot.audioNotes?.some(note => note.id === audioNoteId)) {
                  targetShot = shot;
                  break;
                }
              }
              if (targetShot) break;
            }
            if (targetShot) break;
          }
          if (targetShot) break;
        }
        
        if (!targetShot) return;
        
        const updatedAudioNotes = (targetShot.audioNotes || []).map(note =>
          note.id === audioNoteId ? { ...note, ...updates } : note
        );
        
        get().updateShot(targetShot.id, { audioNotes: updatedAudioNotes });
      },
      
      deleteAudioNote: (audioNoteId: string) => {
        const state = get();
        // Find the shot containing this audio note
        let targetShot: Shot | null = null;
        
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            for (const scene of episode.scenes) {
              for (const shot of scene.shots) {
                if (shot.audioNotes?.some(note => note.id === audioNoteId)) {
                  targetShot = shot;
                  break;
                }
              }
              if (targetShot) break;
            }
            if (targetShot) break;
          }
          if (targetShot) break;
        }
        
        if (!targetShot) return;
        
        const updatedAudioNotes = (targetShot.audioNotes || []).filter(
          note => note.id !== audioNoteId
        );
        
        get().updateShot(targetShot.id, { audioNotes: updatedAudioNotes });
      },
      
      // Budget management
      updateProjectBudget: (projectId: string, budget: Partial<ProjectBudget>) => {
        const state = get();
        const project = state.projects.find(p => p.id === projectId);
        if (project) {
          const updatedBudget = { ...project.budget, ...budget } as ProjectBudget;
          get().updateProject(projectId, { budget: updatedBudget });
        }
      },
      
      updateSceneBudget: (sceneId: string, budget: Partial<SceneBudget>) => {
        // For now, we'll just update the scene without budget
        // In a real implementation, you'd merge with existing budget
        get().updateScene(sceneId, { budget: budget as SceneBudget });
      },
      
      updateShotBudget: (shotId: string, budget: Partial<ShotBudget>) => {
        // For now, we'll just update the shot without budget
        // In a real implementation, you'd merge with existing budget
        get().updateShot(shotId, { budget: budget as ShotBudget });
      },
      

      
      // AI generation (placeholder implementations)
      generateScript: async (episodeId: string, brief: string) => {
        set({ isGenerating: true });
        
        try {
          // Simulate AI script generation
          await new Promise(resolve => setTimeout(resolve, 2000));
          
          // Generate sample scenes based on brief
          const scenes = [
            {
              title: "Opening Scene",
              description: "Establishing shot of the main setting",
              location: "Office Building - Exterior",
              shots: [
                { description: "Wide shot of the location", voiceOver: "Our story begins..." },
                { description: "Medium shot introducing main character", voiceOver: "Meet our protagonist..." }
              ]
            },
            {
              title: "Development",
              description: "Building tension and character development",
              location: "Office Building - Interior",
              shots: [
                { description: "Close-up reaction shot", voiceOver: "The challenge emerges..." },
                { description: "Action sequence", voiceOver: "Now the real adventure begins..." }
              ]
            },
            {
              title: "Resolution",
              description: "Climax and conclusion",
              location: "Conference Room",
              shots: [
                { description: "Dramatic confrontation", voiceOver: "The moment of truth..." },
                { description: "Final resolution shot", voiceOver: "And so our story concludes..." }
              ]
            }
          ];
          
          scenes.forEach((sceneData, index) => {
            get().addScene(episodeId, sceneData.title, sceneData.description, sceneData.location);
            
            // Get the newly created scene
            const state = get();
            const project = state.projects.find(p => 
              p.episodes.some(e => e.id === episodeId)
            );
            const episode = project?.episodes.find(e => e.id === episodeId);
            const scene = episode?.scenes[episode.scenes.length - 1];
            
            if (scene) {
              sceneData.shots.forEach(shotData => {
                get().addShot(scene.id, shotData.description, shotData.voiceOver);
              });
            }
          });
          
        } catch (error) {
          console.error('Error generating script:', error);
        } finally {
          set({ isGenerating: false });
        }
      },
      
      generateImage: async (shotId: string, prompt: string, style: VisualStyle) => {
        set({ isGenerating: true });
        
        try {
          // Simulate AI image generation
          await new Promise(resolve => setTimeout(resolve, 3000));
          
          // For now, use a placeholder image
          const imageUrl = `https://picsum.photos/800/450?random=${shotId}`;
          
          get().updateShot(shotId, {
            imageUrl,
            imagePrompt: prompt
          });
          
        } catch (error) {
          console.error('Error generating image:', error);
        } finally {
          set({ isGenerating: false });
        }
      },
      
      regenerateImage: async (shotId: string) => {
        const result = get().findShot(shotId);
        if (!result) return;
        
        const { shot, project } = result;
        if (!shot.imagePrompt) return;
        
        await get().generateImage(shotId, shot.imagePrompt, project.visualStyle);
      },
      
      // UI actions
      setCurrentView: (view: 'dashboard' | 'episodes' | 'script' | 'script-import' | 'storyboard' | 'ai-services' | 'settings' | 'production' | 'budget' | 'reports' | 'users' | 'export') => {
        set({ currentView: view });
      },
      
      setIsGenerating: (isGenerating: boolean) => {
        set({ isGenerating });
      },
      
      // User management actions
      setCurrentUser: (user: any) => {
        set({ currentUser: user });
      },
      
      updateUserSettings: (settings: any) => {
        set(state => ({
          currentUser: state.currentUser ? { ...state.currentUser, ...settings } : null
        }));
      },
      
      // Mobile and UI state actions
      setIsMobile: (isMobile: boolean) => {
        set({ isMobile });
      },
      
      setSidebarCollapsed: (collapsed: boolean) => {
        set({ sidebarCollapsed: collapsed });
      },
      
      // Helper function to find a shot across all episodes and scenes
      findShot: (shotId: string) => {
        const state = get();
        for (const project of state.projects) {
          for (const episode of project.episodes) {
            for (const scene of episode.scenes) {
              const shot = scene.shots.find(s => s.id === shotId);
              if (shot) return { shot, scene, episode, project };
            }
          }
        }
        return null;
      }
    }));
