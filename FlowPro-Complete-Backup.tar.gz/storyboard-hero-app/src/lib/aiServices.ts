import { GoogleGenerativeAI } from '@google/generative-ai';

// Google AI Studio Integration
const googleAI = new GoogleGenerativeAI(import.meta.env.VITE_GOOGLE_AI_KEY || 'demo-key');

export interface ScriptAnalysis {
  characters: {
    name: string;
    description: string;
    appearances: number;
    characterType: 'main' | 'supporting' | 'background';
    traits: string[];
  }[];
  locations: {
    name: string;
    type: 'interior' | 'exterior';
    description: string;
    scenes: number[];
  }[];
  scenes: {
    sceneNumber: number;
    heading: string;
    location: string;
    timeOfDay: string;
    isInterior: boolean;
    estimatedDuration: number;
    characters: string[];
    keyActions: string[];
    mood: string;
    visualStyle: string;
  }[];
  shots: {
    sceneNumber: number;
    shotNumber: number;
    description: string;
    shotType: string;
    movement: string;
    characters: string[];
    dialogue?: string;
    visualPrompt: string;
  }[];
  metadata: {
    genre: string;
    tone: string;
    targetAudience: string;
    estimatedDuration: number;
    complexity: 'simple' | 'medium' | 'complex';
    productionCost: 'low' | 'medium' | 'high';
  };
  recommendations: {
    visualStyle: string;
    colorPalette: string[];
    lightingStyle: string;
    musicStyle: string;
    pacing: string;
  };
}

// Google AI Studio Script Analysis
export const analyzeScript = async (scriptContent: string): Promise<ScriptAnalysis> => {
  try {
    const model = googleAI.getGenerativeModel({ model: 'gemini-pro' });
    
    const prompt = `
    You are a professional film script analyst. Analyze this screenplay and provide a comprehensive breakdown in JSON format.

    SCRIPT:
    ${scriptContent}

    Please provide analysis in this exact JSON structure:
    {
      "characters": [
        {
          "name": "character name",
          "description": "character description",
          "appearances": number_of_appearances,
          "characterType": "main|supporting|background",
          "traits": ["trait1", "trait2"]
        }
      ],
      "locations": [
        {
          "name": "location name", 
          "type": "interior|exterior",
          "description": "location description",
          "scenes": [scene_numbers]
        }
      ],
      "scenes": [
        {
          "sceneNumber": number,
          "heading": "scene heading",
          "location": "location name",
          "timeOfDay": "day|night|etc",
          "isInterior": boolean,
          "estimatedDuration": minutes,
          "characters": ["character1", "character2"],
          "keyActions": ["action1", "action2"],
          "mood": "mood description",
          "visualStyle": "style description"
        }
      ],
      "shots": [
        {
          "sceneNumber": number,
          "shotNumber": number, 
          "description": "shot description",
          "shotType": "wide|medium|close|etc",
          "movement": "static|pan|etc",
          "characters": ["character1"],
          "dialogue": "dialogue if any",
          "visualPrompt": "AI image generation prompt"
        }
      ],
      "metadata": {
        "genre": "genre",
        "tone": "tone description", 
        "targetAudience": "audience",
        "estimatedDuration": total_minutes,
        "complexity": "simple|medium|complex",
        "productionCost": "low|medium|high"
      },
      "recommendations": {
        "visualStyle": "recommended style",
        "colorPalette": ["#color1", "#color2"],
        "lightingStyle": "lighting style",
        "musicStyle": "music style", 
        "pacing": "pacing recommendation"
      }
    }

    Focus on professional film production insights. Be thorough and accurate.
    `;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    // Extract JSON from response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      return JSON.parse(jsonMatch[0]);
    }
    
    throw new Error('Failed to parse AI response');
  } catch (error) {
    console.error('Script analysis error:', error);
    throw error;
  }
};

// Bubble.ai API Integration
export const bubbleAPI = {
  // Workflow automation
  triggerWorkflow: async (workflowName: string, data: any) => {
    const bubbleUrl = import.meta.env.VITE_BUBBLE_API_URL;
    const bubbleToken = import.meta.env.VITE_BUBBLE_API_TOKEN;
    
    if (!bubbleUrl || !bubbleToken) {
      throw new Error('Bubble.ai credentials not configured');
    }

    const response = await fetch(`${bubbleUrl}/api/1.1/wf/${workflowName}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${bubbleToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    return response.json();
  },

  // Data operations
  createData: async (type: string, data: any) => {
    const bubbleUrl = import.meta.env.VITE_BUBBLE_API_URL;
    const bubbleToken = import.meta.env.VITE_BUBBLE_API_TOKEN;

    const response = await fetch(`${bubbleUrl}/api/1.1/obj/${type}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${bubbleToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data)
    });

    return response.json();
  },

  // Get data
  getData: async (type: string, constraints?: any) => {
    const bubbleUrl = import.meta.env.VITE_BUBBLE_API_URL;
    const bubbleToken = import.meta.env.VITE_BUBBLE_API_TOKEN;

    let url = `${bubbleUrl}/api/1.1/obj/${type}`;
    if (constraints) {
      const params = new URLSearchParams();
      Object.entries(constraints).forEach(([key, value]) => {
        params.append(`constraints[${key}]`, String(value));
      });
      url += `?${params.toString()}`;
    }

    const response = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${bubbleToken}`
      }
    });

    return response.json();
  }
};

// Lovable.ai API Integration  
export const lovableAPI = {
  // Generate code components
  generateComponent: async (description: string, requirements: any) => {
    const lovableUrl = import.meta.env.VITE_LOVABLE_API_URL;
    const lovableToken = import.meta.env.VITE_LOVABLE_API_TOKEN;

    if (!lovableUrl || !lovableToken) {
      throw new Error('Lovable.ai credentials not configured');
    }

    const response = await fetch(`${lovableUrl}/api/generate/component`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description,
        requirements,
        framework: 'react',
        language: 'typescript'
      })
    });

    return response.json();
  },

  // Generate UI from description
  generateUI: async (description: string, style?: string) => {
    const lovableUrl = import.meta.env.VITE_LOVABLE_API_URL;
    const lovableToken = import.meta.env.VITE_LOVABLE_API_TOKEN;

    const response = await fetch(`${lovableUrl}/api/generate/ui`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        description,
        style: style || 'modern',
        framework: 'react'
      })
    });

    return response.json();
  },

  // Optimize existing code
  optimizeCode: async (code: string, optimization: string) => {
    const lovableUrl = import.meta.env.VITE_LOVABLE_API_URL;
    const lovableToken = import.meta.env.VITE_LOVABLE_API_TOKEN;

    const response = await fetch(`${lovableUrl}/api/optimize/code`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${lovableToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        code,
        optimization,
        language: 'typescript'
      })
    });

    return response.json();
  }
};

// Image Generation Integration (combining multiple sources)
export const imageGeneration = {
  // MiniMax Image Generation (existing)
  generateWithMiniMax: async (prompt: string, style: 'standard' | 'premium' = 'standard') => {
    // Use existing MiniMax integration
    return { success: true, imageUrl: '', prompt };
  },

  // Google AI Studio Image Analysis
  analyzeImage: async (imageUrl: string) => {
    try {
      const model = googleAI.getGenerativeModel({ model: 'gemini-pro-vision' });
      
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      
      const prompt = `Analyze this storyboard image and provide:
      1. Shot type (wide, medium, close-up, etc.)
      2. Characters visible
      3. Setting/location
      4. Mood and atmosphere
      5. Lighting conditions
      6. Camera angle
      7. Composition notes
      8. Production recommendations
      
      Provide response in JSON format.`;

      const result = await model.generateContent([
        prompt,
        {
          inlineData: {
            data: await blobToBase64(blob),
            mimeType: blob.type
          }
        }
      ]);

      const responseText = await result.response.text();
      return JSON.parse(responseText);
    } catch (error) {
      console.error('Image analysis error:', error);
      throw error;
    }
  },

  // Bubble.ai workflow for image processing
  processImageWorkflow: async (imageUrl: string, operations: string[]) => {
    return bubbleAPI.triggerWorkflow('process-image', {
      imageUrl,
      operations
    });
  }
};

// Voice and Audio Integration
export const audioServices = {
  // Google AI Studio Text-to-Speech
  generateVoiceOver: async (text: string, voice: string, language: string = 'en') => {
    // This would integrate with Google Cloud Text-to-Speech
    // For now, return a placeholder
    return {
      success: true,
      audioUrl: '',
      duration: 0,
      text,
      voice,
      language
    };
  },

  // Analyze audio content
  analyzeAudio: async (audioUrl: string) => {
    try {
      const model = googleAI.getGenerativeModel({ model: 'gemini-pro' });
      
      const prompt = `Analyze this audio file and provide:
      1. Speech clarity and quality
      2. Background noise level
      3. Emotional tone
      4. Pacing and rhythm
      5. Technical specifications
      6. Recommendations for improvement
      
      Provide response in JSON format.`;

      // Note: This would need actual audio processing capabilities
      // For now, return a structured response
      return {
        quality: 'high',
        clarity: 'excellent',
        backgroundNoise: 'minimal',
        tone: 'professional',
        pacing: 'appropriate',
        recommendations: []
      };
    } catch (error) {
      console.error('Audio analysis error:', error);
      throw error;
    }
  }
};

// Utility functions
const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = (reader.result as string).split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// Export main AI services object
export const aiServices = {
  script: {
    analyze: analyzeScript
  },
  image: imageGeneration,
  audio: audioServices,
  bubble: bubbleAPI,
  lovable: lovableAPI
};

export default aiServices;
