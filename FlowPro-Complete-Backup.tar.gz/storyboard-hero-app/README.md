# 🎬 FlowPro - AI-Powered Film Production Platform

> **Professional storyboard creation and film production management with integrated AI services**

[![Live Demo](https://img.shields.io/badge/🚀_Live_Demo-FlowPro-blue?style=for-the-badge)](https://srp3opy99g.space.minimax.io)
[![React](https://img.shields.io/badge/React-18.3.1-61DAFB?style=flat&logo=react)](https://reactjs.org/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.6.3-3178C6?style=flat&logo=typescript)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-6.2.6-646CFF?style=flat&logo=vite)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-3.4.16-38B2AC?style=flat&logo=tailwind-css)](https://tailwindcss.com/)

## 🌟 Overview

FlowPro is a comprehensive AI-powered film production platform that rivals commercial solutions like StoryboardHero.ai while providing **85-90% cost savings** and additional features. Built with modern web technologies and integrated with multiple AI services for professional film production workflows.

### ✨ Key Features

- 🎯 **Professional Storyboard Creation** - Cinematic quality storyboards with AI assistance
- 🤖 **Multi-AI Integration** - 5 AI services working together seamlessly
- 📝 **Comprehensive Script Analysis** - Intelligent script breakdown and character extraction
- 🎨 **Visual Content Generation** - AI-powered images, videos, and audio creation
- 💰 **Cost-Effective** - 98% cost reduction with DeepSeek integration
- 📊 **Production Management** - Complete project tracking and budget management
- 👥 **Team Collaboration** - Real-time collaboration with Supabase integration
- 📱 **Responsive Design** - Works perfectly on desktop, tablet, and mobile

## 🚀 Live Demo

**Experience FlowPro**: [https://srp3opy99g.space.minimax.io](https://srp3opy99g.space.minimax.io)

## 🧠 AI Services Integration

| Service | Purpose | Cost | Features |
|---------|---------|------|----------|
| **🧠 Google AI Studio** | Script analysis & content intelligence | FREE | Character extraction, scene breakdown, script analysis |
| **⚡ DeepSeek** | Advanced reasoning & analysis | Ultra-low ($0.01/1M tokens) | Story logic analysis, production feasibility, market positioning |
| **🤖 OpenAI/ChatGPT** | Content enhancement & creative writing | Pay-per-use | Dialogue enhancement, script polish, creative problem-solving |
| **🎨 MiniMax** | Visual, video & audio generation | Pay-per-use | Storyboard images, concept art, video previews, voice-over |
| **🗄️ Supabase** | Data storage & real-time collaboration | FREE tier | Project storage, user management, real-time sync |

## 📚 Comprehensive Prompt Library

**20+ Professional Prompts** across 10 categories:
- Script Analysis & Planning (5 prompts)
- Visual Content Generation (6 prompts)
- Advanced Reasoning & Analysis (4 prompts)
- Creative Content Enhancement (5 prompts)

Each prompt includes:
- ✅ Difficulty levels (Beginner → Advanced)
- ✅ Time estimates (2-60 minutes)
- ✅ Smart categorization and search
- ✅ Variable validation and testing

## 🛠️ Technology Stack

### Frontend
- **React 18.3.1** - Modern React with hooks and functional components
- **TypeScript 5.6.3** - Type-safe development
- **Vite 6.2.6** - Lightning-fast build tool
- **Tailwind CSS 3.4.16** - Utility-first CSS framework

### UI Components
- **Radix UI** - Accessible, customizable components
- **Lucide React** - Beautiful icons
- **Recharts** - Data visualization
- **React Hook Form** - Form management

### State Management
- **Zustand** - Lightweight state management
- **React Router** - Client-side routing

### Backend Integration
- **Supabase** - PostgreSQL database, authentication, real-time subscriptions
- **Multiple AI APIs** - Google AI, DeepSeek, OpenAI, MiniMax

## 📁 Project Structure

```
storyboard-hero-app/
├── src/
│   ├── components/          # React components
│   │   ├── ai/             # AI services components
│   │   ├── dashboard/      # Dashboard and project management
│   │   ├── script/         # Script editor and importer
│   │   ├── storyboard/     # Storyboard editor
│   │   └── ui/             # Reusable UI components
│   ├── hooks/              # Custom React hooks
│   ├── lib/                # Utility libraries
│   ├── store/              # State management
│   ├── types/              # TypeScript type definitions
│   └── utils/              # Helper functions and prompts
├── public/                 # Static assets
├── docs/                   # Documentation
└── dist/                   # Production build
```

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and pnpm
- Modern web browser
- API keys for desired services (see setup guide)

### Installation

1. **Clone the repository**
```bash
git clone https://github.com/yourusername/flowpro-storyboard-app.git
cd flowpro-storyboard-app
```

2. **Install dependencies**
```bash
pnpm install
```

3. **Start development server**
```bash
pnpm dev
```

4. **Open in browser**
```
http://localhost:5173
```

### Production Build

```bash
pnpm build
pnpm preview
```

## ⚙️ Configuration

### API Keys Setup

FlowPro requires API keys for full functionality. See `COMPLETE_API_SETUP_GUIDE.md` for detailed instructions.

**Quick Setup:**
1. **Essential**: Supabase (data storage) + Google AI Studio (script analysis)
2. **Recommended**: DeepSeek (ultra cost-effective reasoning)
3. **Optional**: OpenAI + MiniMax (enhanced content generation)

**In-App Configuration:**
1. Navigate to **AI Services** → **Settings**
2. Enter your API keys
3. Test connections
4. Start creating projects!

## 💰 Cost Comparison

| Feature | FlowPro | StoryboardHero.ai | Savings |
|---------|---------|-------------------|---------|
| **Monthly Cost** | $10-25 | $79-199 | **85-90%** |
| **AI Services** | 5 integrated | Limited | **More features** |
| **Custom Prompts** | 20+ professional | Basic | **More flexibility** |
| **Data Storage** | Your own Supabase | Vendor lock-in | **Full control** |
| **Source Code** | Full access | Proprietary | **Complete ownership** |

## 🎯 Use Cases

### 🎬 Film Production
- **Feature Films**: Complete pre-production planning
- **TV Series**: Multi-episode project management
- **Short Films**: Quick storyboard creation
- **Commercials**: Client presentation materials

### 🏢 Professional Applications
- **Film Studios**: Cost-effective pre-production
- **Advertising Agencies**: Campaign visualization
- **Educational**: Film school projects
- **Independent Creators**: Professional-quality output

## 📖 Documentation

- **[Complete API Setup Guide](./COMPLETE_API_SETUP_GUIDE.md)** - Step-by-step API configuration
- **[Comprehensive Prompt Library](./docs/comprehensive-prompt-library.md)** - AI prompt documentation
- **[Technical Architecture](./docs/technical-plan.md)** - System design and architecture

## 🤝 Contributing

We welcome contributions! Please see our contributing guidelines:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](./LICENSE) file for details.

## 🙏 Acknowledgments

- **AI Services**: Google AI Studio, DeepSeek, OpenAI, MiniMax, Supabase
- **UI Components**: Radix UI, Tailwind CSS, Lucide React
- **Inspiration**: StoryboardHero.ai and professional film production workflows

## 📞 Support

- **Live Demo**: [https://srp3opy99g.space.minimax.io](https://srp3opy99g.space.minimax.io)
- **Issues**: Please report bugs and feature requests via GitHub Issues
- **Documentation**: See `docs/` directory for detailed guides

---

**Transform your film production workflow with AI-powered storyboarding!** 🎬✨

Built with ❤️ using modern web technologies and professional AI services.
