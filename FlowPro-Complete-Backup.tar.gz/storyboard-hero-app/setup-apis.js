#!/usr/bin/env node

/**
 * FlowPro API Setup Script
 * This script helps you configure all API connections for FlowPro
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(prompt) {
  return new Promise((resolve) => {
    rl.question(prompt, resolve);
  });
}

function isValidSupabaseUrl(url) {
  return url.startsWith('https://') && url.includes('.supabase.co');
}

function isValidSupabaseKey(key) {
  return key.startsWith('eyJ') && key.length > 50;
}

function isValidGoogleAIKey(key) {
  return key.startsWith('AIza') && key.length > 30;
}

async function main() {
  console.log('\n🎬 FlowPro API Setup Wizard\n');
  console.log('This wizard will help you configure all API connections for FlowPro.\n');

  const config = {};

  // Supabase Configuration
  console.log('📦 SUPABASE CONFIGURATION');
  console.log('1. Go to https://supabase.com and create a new project');
  console.log('2. Get your Project URL and anon key from Settings → API\n');

  config.supabaseUrl = await question('Enter your Supabase Project URL: ');
  while (!isValidSupabaseUrl(config.supabaseUrl)) {
    console.log('❌ Invalid Supabase URL. Should start with https:// and contain .supabase.co');
    config.supabaseUrl = await question('Enter your Supabase Project URL: ');
  }

  config.supabaseKey = await question('Enter your Supabase anon key: ');
  while (!isValidSupabaseKey(config.supabaseKey)) {
    console.log('❌ Invalid Supabase key. Should start with eyJ and be quite long');
    config.supabaseKey = await question('Enter your Supabase anon key: ');
  }

  // Google AI Studio Configuration
  console.log('\n🧠 GOOGLE AI STUDIO CONFIGURATION');
  console.log('1. Go to https://aistudio.google.com');
  console.log('2. Sign in and create an API key');
  console.log('3. Copy the API key (starts with AIza...)\n');

  config.googleAIKey = await question('Enter your Google AI Studio API key: ');
  while (!isValidGoogleAIKey(config.googleAIKey)) {
    console.log('❌ Invalid Google AI key. Should start with AIza');
    config.googleAIKey = await question('Enter your Google AI Studio API key: ');
  }

  // Optional APIs
  console.log('\n🔧 OPTIONAL API CONFIGURATIONS');
  console.log('You can add these later or skip for now:\n');

  const addBubble = await question('Do you have a Bubble.io API key? (y/n): ');
  if (addBubble.toLowerCase() === 'y') {
    config.bubbleKey = await question('Enter your Bubble.io API key: ');
    config.bubbleAppId = await question('Enter your Bubble.io App ID: ');
  }

  const addLovable = await question('Do you have a Lovable.ai API key? (y/n): ');
  if (addLovable.toLowerCase() === 'y') {
    config.lovableKey = await question('Enter your Lovable.ai API key: ');
  }

  const addMiniMax = await question('Do you have a MiniMax API key? (y/n): ');
  if (addMiniMax.toLowerCase() === 'y') {
    config.minimaxKey = await question('Enter your MiniMax API key: ');
  }

  // Create .env file
  const envContent = `# FlowPro API Configuration
# Generated on ${new Date().toISOString()}

# Supabase Configuration (Required)
VITE_SUPABASE_URL=${config.supabaseUrl}
VITE_SUPABASE_ANON_KEY=${config.supabaseKey}

# Google AI Studio Configuration (Required)
VITE_GOOGLE_AI_KEY=${config.googleAIKey}

# Bubble.io Configuration (Optional)
${config.bubbleKey ? `VITE_BUBBLE_API_KEY=${config.bubbleKey}` : '# VITE_BUBBLE_API_KEY=your-bubble-api-key'}
${config.bubbleAppId ? `VITE_BUBBLE_APP_ID=${config.bubbleAppId}` : '# VITE_BUBBLE_APP_ID=your-bubble-app-id'}

# Lovable.ai Configuration (Optional)
${config.lovableKey ? `VITE_LOVABLE_API_KEY=${config.lovableKey}` : '# VITE_LOVABLE_API_KEY=your-lovable-api-key'}

# MiniMax Configuration (Optional)
${config.minimaxKey ? `VITE_MINIMAX_API_KEY=${config.minimaxKey}` : '# VITE_MINIMAX_API_KEY=your-minimax-api-key'}

# Application Configuration
VITE_APP_NAME=FlowPro
VITE_APP_VERSION=2.0.0
VITE_ENVIRONMENT=production
`;

  const envPath = path.join(__dirname, '.env');
  fs.writeFileSync(envPath, envContent);

  console.log('\n✅ Configuration Complete!');
  console.log(`📁 Created .env file at: ${envPath}`);
  
  console.log('\n🚀 NEXT STEPS:');
  console.log('1. Set up your Supabase database schema:');
  console.log('   - Copy the SQL from docs/supabase_setup_guide.md');
  console.log('   - Run it in your Supabase SQL Editor');
  console.log('');
  console.log('2. Build and deploy FlowPro:');
  console.log('   - pnpm build');
  console.log('   - Test the connections in the AI Services section');
  console.log('');
  console.log('3. Disable demo mode:');
  console.log('   - Edit src/components/auth/AuthProvider.tsx');
  console.log('   - Set demoMode = false for production');

  rl.close();
}

main().catch(console.error);
