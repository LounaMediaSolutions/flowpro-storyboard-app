# 🚀 FlowPro Complete API Setup Guide

**Your FlowPro App URL**: https://srp3opy99g.space.minimax.io

This guide will help you set up all the API keys needed to make FlowPro fully functional with data storage and AI capabilities.

## 📋 Required Services Overview

| Service | Purpose | Cost | Priority |
|---------|---------|------|----------|
| **Supabase** | Data storage & user management | Free tier available | ⭐ ESSENTIAL |
| **Google AI Studio** | Script analysis & content intelligence | Free tier available | ⭐ ESSENTIAL |
| **DeepSeek** | Advanced reasoning (98% cost reduction) | Ultra-low cost | ⭐ HIGHLY RECOMMENDED |
| **OpenAI/ChatGPT** | Content enhancement | Pay-per-use | ⭐ RECOMMENDED |
| **MiniMax** | Visual/audio generation | Pay-per-use | ⭐ RECOMMENDED |

---

## 1. 🗄️ SUPABASE SETUP (Data Storage - ESSENTIAL)

### Step 1: Create Supabase Account
1. Go to **https://supabase.com/**
2. Click **"Start your project"**
3. Sign up with GitHub, Google, or email

### Step 2: Create New Project
1. Click **"New project"**
2. Choose your organization (or create one)
3. Fill in project details:
   - **Name**: `flowpro-production` (or your preferred name)
   - **Database Password**: Create a strong password (save this!)
   - **Region**: Choose closest to you
4. Click **"Create new project"**

### Step 3: Get Your Supabase Credentials
1. Wait for project creation (2-3 minutes)
2. Go to **Settings** → **API**
3. Copy these values:
   - **Project URL**: `https://your-project-id.supabase.co`
   - **anon public key**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### Step 4: Set Up Database Schema (Optional - Auto-created)
FlowPro will automatically create the necessary tables when you first use it.

---

## 2. 🧠 GOOGLE AI STUDIO SETUP (Script Analysis - ESSENTIAL)

### Step 1: Get Google AI Studio API Key
1. Go to **https://aistudio.google.com/**
2. Sign in with your Google account
3. Click **"Get API key"** in the left sidebar
4. Click **"Create API key"**
5. Choose **"Create API key in new project"** (recommended)
6. Copy your API key: `AIzaSyC...` (starts with AIzaSy)

### Note: Google AI Studio is FREE
- No payment method required
- Generous free tier for development and testing

---

## 3. ⚡ DEEPSEEK SETUP (Advanced Reasoning - 98% Cost Savings)

### Step 1: Create DeepSeek Account
1. Go to **https://platform.deepseek.com/**
2. Sign up with email
3. Verify your email address

### Step 2: Get API Key
1. Go to **API Keys** section
2. Click **"Create API Key"**
3. Give it a name: `flowpro-production`
4. Copy your API key: `sk-...`

### Step 3: Add Credits (Ultra Low Cost)
1. Go to **Billing**
2. Add minimum $5 (will last months due to ultra-low pricing)
3. DeepSeek costs: **$0.01 per 1M tokens** (vs $30 for competitors)

---

## 4. 🤖 OPENAI/CHATGPT SETUP (Content Enhancement)

### Step 1: Create OpenAI Account
1. Go to **https://platform.openai.com/**
2. Sign up or sign in
3. Verify your phone number

### Step 2: Get API Key
1. Go to **API Keys** section
2. Click **"Create new secret key"**
3. Name it: `flowpro-production`
4. Copy your API key: `sk-...`

### Step 3: Add Billing (Required)
1. Go to **Billing** → **Payment methods**
2. Add a payment method
3. Add $5-10 to start (pay-per-use)

---

## 5. 🎨 MINIMAX SETUP (Visual/Audio Generation)

### Step 1: Create MiniMax Account
1. Go to **https://platform.minimax.chat/**
2. Sign up with email or social login
3. Complete verification

### Step 2: Get API Key
1. Navigate to **API Management**
2. Create new API key
3. Copy your API key

### Step 3: Add Credits
1. Go to **Billing**
2. Purchase credits for image/video generation
3. Recommended: Start with $10-20

---

## 📝 ADDING API KEYS TO FLOWPRO

### Method 1: Through FlowPro Interface (Recommended)
1. Open your FlowPro app: **https://srp3opy99g.space.minimax.io**
2. Click **"AI Services"** in the sidebar
3. Click **"Settings"** tab
4. Fill in your API keys:

```
┌─ Supabase Configuration ─────────────────┐
│ Project URL: https://your-id.supabase.co │
│ Anon Key: eyJhbGciOiJIUzI1NiIs...        │
└─────────────────────────────────────────┘

┌─ Google AI Studio ───────────────────────┐
│ API Key: AIzaSyC...                      │
└─────────────────────────────────────────┘

┌─ DeepSeek API ───────────────────────────┐
│ API Key: sk-...                          │
└─────────────────────────────────────────┘

┌─ OpenAI/ChatGPT ─────────────────────────┐
│ API Key: sk-...                          │
└─────────────────────────────────────────┘

┌─ MiniMax ────────────────────────────────┐
│ API Key: your-minimax-key                │
└─────────────────────────────────────────┘
```

5. Click **"Save Configuration"**
6. Test each service using the **"Test"** buttons

### Method 2: Browser Local Storage (Advanced)
You can also set these in your browser's developer console:
```javascript
// Open browser console (F12) and run:
localStorage.setItem('supabase_url', 'https://your-project-id.supabase.co');
localStorage.setItem('supabase_key', 'your-anon-key');
localStorage.setItem('google_ai_key', 'AIzaSyC...');
localStorage.setItem('deepseek_key', 'sk-...');
localStorage.setItem('openai_key', 'sk-...');
localStorage.setItem('minimax_key', 'your-minimax-key');
```

---

## ✅ TESTING YOUR SETUP

### 1. Test Project Creation
1. Go to FlowPro dashboard
2. Click **"Create New Project"**
3. Fill in project details
4. If Supabase is configured correctly, the project will be saved

### 2. Test AI Services
1. Go to **AI Services** → **Test Prompts**
2. Test each service with the provided sample prompts
3. Verify responses are generated correctly

### 3. Test Each Service Individually
- **Google AI**: Script analysis should return JSON format
- **DeepSeek**: Advanced reasoning should provide detailed analysis
- **OpenAI**: Content enhancement should improve text
- **MiniMax**: Image/video generation should process requests

---

## 💰 COST BREAKDOWN

### Free Tier Usage (Getting Started)
- **Supabase**: 500MB database, 5GB bandwidth/month - FREE
- **Google AI Studio**: Generous free tier - FREE
- **DeepSeek**: $5 = ~500M tokens (months of usage)
- **OpenAI**: $5 = moderate usage for content enhancement
- **MiniMax**: $10 = 100+ image generations

### Monthly Estimate for Regular Use
- **Total Cost**: $10-25/month for comprehensive film production
- **Compare to**: StoryboardHero.ai ($79-199/month)
- **Savings**: 85-90% cost reduction with more features

---

## 🔧 TROUBLESHOOTING

### Common Issues:

**"Demo Mode" Message**
- ✅ **Solution**: Add Supabase credentials in Settings

**API Test Failures**
- ✅ **Check**: API key format (remove extra spaces)
- ✅ **Verify**: Account has credits/active billing
- ✅ **Confirm**: API key permissions are correct

**Project Creation Not Working**
- ✅ **Ensure**: Supabase is configured first
- ✅ **Check**: Browser console for error messages
- ✅ **Try**: Refresh page and retry

**AI Services Not Responding**
- ✅ **Verify**: Each API key is valid and active
- ✅ **Check**: Account billing status
- ✅ **Test**: One service at a time to isolate issues

---

## 🎯 QUICK START CHECKLIST

```
□ 1. Create Supabase project and get URL + key
□ 2. Get Google AI Studio API key (free)
□ 3. Create DeepSeek account and add $5 credits
□ 4. (Optional) Set up OpenAI account with billing
□ 5. (Optional) Set up MiniMax account with credits
□ 6. Add all keys to FlowPro Settings
□ 7. Test project creation
□ 8. Test AI services with sample prompts
□ 9. Create your first film project!
```

---

## 🆘 NEED HELP?

**Priority Setup Order:**
1. **Supabase** (Essential for data storage)
2. **Google AI** (Essential for script analysis)  
3. **DeepSeek** (Highly recommended for advanced reasoning)
4. **OpenAI** (Good for content enhancement)
5. **MiniMax** (Great for visual generation)

**Start with Steps 1-3 to get core functionality working, then add the others as needed.**

Ready to transform your film production workflow with AI! 🎬✨
